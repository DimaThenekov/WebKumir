var MD5 = function (r) {
	function i(r, n) {
		return r << n | r >>> 32 - n
	}
	function c(r, n) {
		var t,
		o,
		e,
		u,
		a;
		return e = 2147483648 & r,
		u = 2147483648 & n,
		a = (1073741823 & r) + (1073741823 & n),
		(t = 1073741824 & r) & (o = 1073741824 & n) ? 2147483648 ^ a ^ e ^ u : t | o ? 1073741824 & a ? 3221225472 ^ a ^ e ^ u : 1073741824 ^ a ^ e ^ u : a ^ e ^ u
	}
	function n(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c((f = n) & t | ~f & o, e), a)),
		c(i(r, u), n)
	}
	function t(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c(n & (f = o) | t & ~f, e), a)),
		c(i(r, u), n)
	}
	function o(r, n, t, o, e, u, a) {
		return r = c(r, c(c(n ^ t ^ o, e), a)),
		c(i(r, u), n)
	}
	function e(r, n, t, o, e, u, a) {
		return r = c(r, c(c(t ^ (n | ~o), e), a)),
		c(i(r, u), n)
	}
	function u(r) {
		var n,
		t = "",
		o = "";
		for (n = 0; n <= 3; n++)
			t += (o = "0" + (r >>> 8 * n & 255).toString(16)).substr(o.length - 2, 2);
		return t
	}
	var a,
	f,
	C,
	g,
	h,
	v,
	d,
	S,
	l,
	m = Array();
	for (m = function (r) {
		for (var n, t = r.length, o = t + 8, e = 16 * (1 + (o - o % 64) / 64), u = Array(e - 1), a = 0, f = 0; f < t; )
			a = f % 4 * 8, u[n = (f - f % 4) / 4] = u[n] | r.charCodeAt(f) << a, f++;
		return a = f % 4 * 8,
		u[n = (f - f % 4) / 4] = u[n] | 128 << a,
		u[e - 2] = t << 3,
		u[e - 1] = t >>> 29,
		u
	}
		(r = function (r) {
			r = r.replace(/\r\n/g, "\n");
			for (var n = "", t = 0; t < r.length; t++) {
				var o = r.charCodeAt(t);
				o < 128 ? n += String.fromCharCode(o) : (127 < o && o < 2048 ? n += String.fromCharCode(o >> 6 | 192) : (n += String.fromCharCode(o >> 12 | 224), n += String.fromCharCode(o >> 6 & 63 | 128)), n += String.fromCharCode(63 & o | 128))
			}
			return n
		}
			(r)), v = 1732584193, d = 4023233417, S = 2562383102, l = 271733878, a = 0; a < m.length; a += 16)
		v = n(f = v, C = d, g = S, h = l, m[a + 0], 7, 3614090360), l = n(l, v, d, S, m[a + 1], 12, 3905402710), S = n(S, l, v, d, m[a + 2], 17, 606105819), d = n(d, S, l, v, m[a + 3], 22, 3250441966), v = n(v, d, S, l, m[a + 4], 7, 4118548399), l = n(l, v, d, S, m[a + 5], 12, 1200080426), S = n(S, l, v, d, m[a + 6], 17, 2821735955), d = n(d, S, l, v, m[a + 7], 22, 4249261313), v = n(v, d, S, l, m[a + 8], 7, 1770035416), l = n(l, v, d, S, m[a + 9], 12, 2336552879), S = n(S, l, v, d, m[a + 10], 17, 4294925233), d = n(d, S, l, v, m[a + 11], 22, 2304563134), v = n(v, d, S, l, m[a + 12], 7, 1804603682), l = n(l, v, d, S, m[a + 13], 12, 4254626195), S = n(S, l, v, d, m[a + 14], 17, 2792965006), v = t(v, d = n(d, S, l, v, m[a + 15], 22, 1236535329), S, l, m[a + 1], 5, 4129170786), l = t(l, v, d, S, m[a + 6], 9, 3225465664), S = t(S, l, v, d, m[a + 11], 14, 643717713), d = t(d, S, l, v, m[a + 0], 20, 3921069994), v = t(v, d, S, l, m[a + 5], 5, 3593408605), l = t(l, v, d, S, m[a + 10], 9, 38016083), S = t(S, l, v, d, m[a + 15], 14, 3634488961), d = t(d, S, l, v, m[a + 4], 20, 3889429448), v = t(v, d, S, l, m[a + 9], 5, 568446438), l = t(l, v, d, S, m[a + 14], 9, 3275163606), S = t(S, l, v, d, m[a + 3], 14, 4107603335), d = t(d, S, l, v, m[a + 8], 20, 1163531501), v = t(v, d, S, l, m[a + 13], 5, 2850285829), l = t(l, v, d, S, m[a + 2], 9, 4243563512), S = t(S, l, v, d, m[a + 7], 14, 1735328473), v = o(v, d = t(d, S, l, v, m[a + 12], 20, 2368359562), S, l, m[a + 5], 4, 4294588738), l = o(l, v, d, S, m[a + 8], 11, 2272392833), S = o(S, l, v, d, m[a + 11], 16, 1839030562), d = o(d, S, l, v, m[a + 14], 23, 4259657740), v = o(v, d, S, l, m[a + 1], 4, 2763975236), l = o(l, v, d, S, m[a + 4], 11, 1272893353), S = o(S, l, v, d, m[a + 7], 16, 4139469664), d = o(d, S, l, v, m[a + 10], 23, 3200236656), v = o(v, d, S, l, m[a + 13], 4, 681279174), l = o(l, v, d, S, m[a + 0], 11, 3936430074), S = o(S, l, v, d, m[a + 3], 16, 3572445317), d = o(d, S, l, v, m[a + 6], 23, 76029189), v = o(v, d, S, l, m[a + 9], 4, 3654602809), l = o(l, v, d, S, m[a + 12], 11, 3873151461), S = o(S, l, v, d, m[a + 15], 16, 530742520), v = e(v, d = o(d, S, l, v, m[a + 2], 23, 3299628645), S, l, m[a + 0], 6, 4096336452), l = e(l, v, d, S, m[a + 7], 10, 1126891415), S = e(S, l, v, d, m[a + 14], 15, 2878612391), d = e(d, S, l, v, m[a + 5], 21, 4237533241), v = e(v, d, S, l, m[a + 12], 6, 1700485571), l = e(l, v, d, S, m[a + 3], 10, 2399980690), S = e(S, l, v, d, m[a + 10], 15, 4293915773), d = e(d, S, l, v, m[a + 1], 21, 2240044497), v = e(v, d, S, l, m[a + 8], 6, 1873313359), l = e(l, v, d, S, m[a + 15], 10, 4264355552), S = e(S, l, v, d, m[a + 6], 15, 2734768916), d = e(d, S, l, v, m[a + 13], 21, 1309151649), v = e(v, d, S, l, m[a + 4], 6, 4149444226), l = e(l, v, d, S, m[a + 11], 10, 3174756917), S = e(S, l, v, d, m[a + 2], 15, 718787259), d = e(d, S, l, v, m[a + 9], 21, 3951481745), v = c(v, f), d = c(d, C), S = c(S, g), l = c(l, h);
	return (u(v) + u(d) + u(S) + u(l)).toLowerCase()
};
var RegistrationHash = function (h, p) {
	return MD5('Hash:' + h + ';Password:' + p + ';');
};
if (!String.prototype.repeat) {
	String.prototype.repeat = function (count) {
		'use strict';
		if (this == null) {
			throw new TypeError('can\'t convert ' + this + ' to object');
		}
		var str = '' + this;
		count = +count;
		if (count != count) {
			count = 0;
		}
		if (count < 0) {
			throw new RangeError('repeat count must be non-negative');
		}
		if (count == Infinity) {
			throw new RangeError('repeat count must be less than infinity');
		}
		count = Math.floor(count);
		if (str.length == 0 || count == 0) {
			return '';
		}
		// Ensuring count is a 31-bit integer allows us to heavily optimize the
		// main part. But anyway, most current (August 2014) browsers can't handle
		// strings 1 << 28 chars or longer, so:
		if (str.length * count >= 1 << 28) {
			throw new RangeError('repeat count must not overflow maximum string size');
		}
		var rpt = '';
		for (; ; ) {
			if ((count & 1) == 1) {
				rpt += str;
			}
			count >>>= 1;
			if (count == 0) {
				break;
			}
			str += str;
		}
		// Could we try:
		// return Array(count + 1).join(this);
		return rpt;
	}
}

var arr = [[['ExpWK', 'Эксперементальный тур по Вебкумиру 1.0', 'бла бла бла', '<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Добавить</button>'], ['WK2021', '4-я командная олимпиада', 'бла бла бла', '<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Добавить</button>']], [['Эксперементальный тур по Вебкумиру 1.0', '<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 12px;" name="text"></textarea>', 'ГруппыГруппыГруппыГруппыГруппы', 'Завтра', '1 час', '2 часа', '<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Удалить</button>', '7239482', '7239482']]];

function format(str, n, str_id, h) {
	var char_set = [',', ' ', ':', ';'];
	var arr_str = str.split(/[ \n]/);
	for (var i = 0; i < arr_str.length; i++) {
		if (arr_str[i].length > n) {
			arr_str = arr_str.slice(0, i).concat(arr_str[i].slice(0, n)).concat(arr_str[i].slice(n)).concat(arr_str.slice(i + 1));
		} else {
			while ((i < arr_str.length - 1) && (arr_str[i].length + arr_str[i + 1].length + 1 <= n)) {
				arr_str = arr_str.slice(0, i).concat(arr_str[i] + ' ' + arr_str[i + 1]).concat(arr_str.slice(i + 2));

			}
		}
	}
	for (var i = 0; i < arr_str.length; i++) {
		arr_str[i] = arr_str[i] + ' '.repeat(n - arr_str[i].length);

	}
	if (str_id == undefined)
		str_id = '';
	if (str != '' && str[0] == '<')
		return [str.replace(/%%wid%%/g, Math.floor(n * 7) + '').replace(/%%id%%/g, str_id).replace(/%%hei%%/g, h) + ' '.repeat(n)];
	else
		return arr_str;
}

function render() {
	var s = '';
	s += '╔═══════════╤═══ Проекты ═══╤═════════════╤═════════════╕\n';
	s += '║ Название  │               │             │             │\n';
	s += '║   папки   │      Имя      │   Задания   │ Добавление  │\n';
	s += '╠═══════════╪═══════════════╪═════════════╪═════════════╡\n';
	for (var i = 0; i < arr[0].length; i++) {
		var arr_slice = [format(arr[0][i][0], 9), format(arr[0][i][1], 13), format(arr[0][i][2], 11), format(arr[0][i][3], 11, 'add_proj(' + i + ');')];
		for (var j = 0; j < Math.max(Math.max(Math.max(arr_slice[0].length, arr_slice[1].length), arr_slice[2].length), arr_slice[3].length); j++) {
			if (j < arr_slice[0].length)
				s += '║ ' + arr_slice[0][j];
			else
				s += '║          ';
			if (j < arr_slice[1].length)
				s += ' │ ' + arr_slice[1][j];
			else
				s += ' │              ';
			if (j < arr_slice[2].length)
				s += ' │ ' + arr_slice[2][j];
			else
				s += ' │            ';
			if (j < arr_slice[3].length)
				s += ' │ ' + arr_slice[3][j];
			else
				s += ' │            ';
			s += ' │\n';
		}
		if (i != arr[0].length - 1)
			s += '╟───────────┼───────────────┼─────────────┼─────────────┤\n';
		//else
		0 //	s+='╚═══════════╧═══════════════╧═════════════╛\n';
	}
	var s2 = '';
	s2 += '╒═══════════════╤═ Проекты, запущенные на сервере ═╤═══════════════════╤═══════════════════╤═══════════════════╤═══════════════════╤════════════╤═════════════╗\n';
	s2 += '│      Имя      │           Отображаемое           │                   │       Дата        │ За сколько заморо │ Продолжительность │            │             ║\n';
	s2 += '│   родителя    │               имя                │       Группы      │      Старта       │ зить(мин до кон.) │    (в минутах)    │  Удаление  │    uniID    ║\n';
	s2 += '╞═══════════════╪══════════════════════════════════╪═══════════════════╪═══════════════════╪═══════════════════╪═══════════════════╪════════════╪═════════════╣\n';
	for (var i = 0; i < arr[1].length; i++) {
		var arr_slice = [format(arr[1][i][0], 13), format(arr[1][i][1], 32, 'editname' + (arr[1][i][7]), format(arr[1][i][0], 13).length * 12 + ''), format(arr[1][i][2], 17, 'editgroup' + (arr[1][i][7]), format(arr[1][i][0], 13).length * 12 + ''), format(arr[1][i][3], 17, 'editdate' + (arr[1][i][7])), format(arr[1][i][4], 17, 'editdatefrz' + (arr[1][i][7])), format(arr[1][i][5], 17, 'editdateend' + (arr[1][i][7])), format(arr[1][i][6], 10, 'del_proj(\'' + arr[1][i][7] + '\')'), format(arr[1][i][8], 11, 'gen_proj(\'' + arr[1][i][7] + '\')', 32)];
		var max_el = 2;
		for (var j = 0; j < arr_slice.length; j++)
			max_el = Math.max(max_el, arr_slice[j].length);

		for (var j = 0; j < max_el; j++) {
			if (j < arr_slice[0].length)
				s2 += '│ ' + arr_slice[0][j];
			else
				s2 += '│ ' + ' '.repeat(13);
			if (j < arr_slice[1].length)
				s2 += ' │ ' + arr_slice[1][j];
			else
				s2 += ' │ ' + ' '.repeat(32);
			if (j < arr_slice[2].length)
				s2 += ' │ ' + arr_slice[2][j];
			else
				s2 += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[3].length)
				s2 += ' │ ' + arr_slice[3][j];
			else
				s2 += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[4].length)
				s2 += ' │ ' + arr_slice[4][j];
			else
				s2 += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[5].length)
				s2 += ' │ ' + arr_slice[5][j];
			else
				s2 += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[6].length)
				s2 += ' │ ' + arr_slice[6][j];
			else
				s2 += ' │ ' + ' '.repeat(10);
			if (j < arr_slice[7].length)
				s2 += ' │ ' + arr_slice[7][j];
			else
				s2 += ' │ ' + ' '.repeat(11);
			s2 += ' ║\n';
		}
		if (i != arr[1].length - 1)
			s2 += '├───────────────┼──────────────────────────────────┼───────────────────┼───────────────────┼───────────────────┼───────────────────┼────────────┼─────────────╢\n';
		//else
		//	s+='╚═══════════╧═══════════════╧═════════════╛\n';
	}
	s = s.split('\n');
	s2 = s2.split('\n');
	var s3 = '';
	for (var j = 0; j < Math.max(s.length - 1, s2.length - 1); j++) {
		if (j < s.length - 1) {
			s3 += s[j];
		} else
			s3 += '║           │               │             │             │';

		if (j < s2.length - 1) {
			s3 += s2[j];
		} else
			s3 += '│               │                                  │                   │                   │                   │                   │            │             ║';
		s3 += '\n';
	}
	s3 += '╚═══════════╧═══════════════╧═════════════╧═════════════╛╘═══════════════╧══════════════════════════════════╧═══════════════════╧═══════════════════╧═══════════════════╧═══════════════════╧════════════╧═════════════╝';
	document.getElementById('prog_pre').innerHTML = s3;
	return (s3.split('\n'));
}
var ok = 0;
function ParseData(s, n) {
	function getISOStringWithoutSecsAndMillisecs1(date) {
		const dateAndTime = (new Date(date - (new Date().getTimezoneOffset()) * 60000)).toISOString().split('T')
		const time = dateAndTime[1].split(':')
		return dateAndTime[0] + 'T' + time[0] + ':' + time[1]
	}
	ok++;

	if (n == 1) {
		arr[0] = [];
		for (var i = 1; i < s.split('\n').length - 1; i++) {
			arr[0][i - 1] = [s.split('\n')[i].split(';')[0], s.split('\n')[i].split(';')[1], /*   */ s.split('\n')[i].split(';')[2].split('\', \'').splice(0, s.split('\n')[i].split(';')[2].split('\', \'').length - 1).join('\', \'') + '\'' /*   */, '<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Добавить</button>'];
		}
	}
	if (n == 2) {
		arr[1] = [];
		//['Эксперементальный тур по Вебкумиру 1.0','<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 12px;" name="text"></textarea>','ГруппыГруппыГруппыГруппыГруппы','Завтра','2 часа','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Удалить</button>','7239482'
		for (var i = 1; i < s.split('\n').length - 1; i++) {
			arr[1][i - 1] = [s.split('\n')[i].split(';')[0], '<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: %%hei%%px;" id="%%id%%">' + s.split('\n')[i].split(';')[1] + '</textarea>', '<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: %%hei%%px;" id="%%id%%">' + s.split('\n')[i].split(';')[2] + '</textarea>', '<input style="position: absolute;width: %%wid%%px;" type="datetime-local" id="%%id%%" value="' + getISOStringWithoutSecsAndMillisecs1(parseInt(s.split('\n')[i].split(';')[3]) * 1000).split('.')[0] + '">', '<input type="number" style="position: absolute;width: %%wid%%px;" id="%%id%%" value="' + (parseInt(s.split('\n')[i].split(';')[5]) - parseInt(s.split('\n')[i].split(';')[4])) / 60 + '">', '<input type="number" style="position: absolute;width: %%wid%%px;" id="%%id%%" value="' + (parseInt(s.split('\n')[i].split(';')[5]) - parseInt(s.split('\n')[i].split(';')[3])) / 60 + '">', '<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Удалить</button>', s.split('\n')[i].split(';')[6], '<button style="position: absolute; width: %%wid%%px; height: %%hei%%px;padding: 2px;" onclick="%%id%%">' + s.split('\n')[i].split(';')[6] + '<br>Ген. новый</button>'];
		}
	}
	if (ok == 2)
		render()
}
function GetServerData() {
	ok = 0;
	Serv_Command('get_prj', ParseData, 1);
	Serv_Command('get_run_prj', ParseData, 2);
}
function add_proj_acc(s) {
	if (s != 'OK')
		alert(s);
	GetServerData();
}
function add_proj(i) {
	if (confirm('Вы уверены?')) {
		Serv_Command('create_proj_' + i + '_' + MD5(Math.random() + '').slice(0, 10) + '_', add_proj_acc);
		//GetServerData();
	}
}
function del_proj_acc(s) {
	if (s != 'OK')
		alert(s);
	GetServerData();
}
function del_proj(uniID) {
	if (confirm('Вы уверены?')) {
		Serv_Command('del_proj_' + uniID + '_', del_proj_acc);
		//GetServerData();
	}
}
function gen_proj(uniID) {
	if (confirm('Вы уверены? Все данные о счёте и посылках игроков будут утеряны.')) {
		Serv_Command('new_ID_' + uniID + '_' + MD5(Math.random() + '').slice(0, 10) + '_', del_proj_acc);
		//GetServerData();
	}
}
function save_prog() {
	if (confirm('Вы уверены?')) {
		//name group time_start time_freeze time_end
		var save_data = [];
		for (var i = 0; i < arr[1].length; i++) {
			save_data[i] = [];
			save_data[i][0] = document.getElementById('editname' + arr[1][i][7]).value.replace(/\r/g, '').replace(/\n/g, ' ');
			save_data[i][1] = document.getElementById('editgroup' + arr[1][i][7]).value.replace(/\r/g, '').replace(/\n/g, ' ');
			save_data[i][2] = ((new Date(document.getElementById('editdate' + arr[1][i][7]).value) - 1) + 1 + ''); //-(new Date().getTimezoneOffset())*60000)+'';
			save_data[i][4] = (parseInt(save_data[i][2]) + parseInt(document.getElementById('editdateend' + arr[1][i][7]).value) * 60000) + '';
			save_data[i][3] = (-parseInt(document.getElementById('editdatefrz' + arr[1][i][7]).value) * 60000 + parseInt(save_data[i][4])) + '';
			save_data[i][5] = arr[1][i][7];
		}
		var s = '';
		for (var i = 0; i < save_data.length; i++) {
			s = s + save_data[i][0] + ',s_p_l_i_t,' + save_data[i][1] + ',s_p_l_i_t,' + Math.floor(parseInt(save_data[i][2]) / 1000) + ',s_p_l_i_t,' + Math.floor(parseInt(save_data[i][3]) / 1000) + ',s_p_l_i_t,' + Math.floor(parseInt(save_data[i][4]) / 1000) + ',s_p_l_i_t,' + save_data[i][5] + '\n';
		}
		if (encodeURI(s).length <= 25000)
			Serv_SendPost(s, 'save_dat', GetServerData);
		else {
			alert('Невозможно сохранить. Слишком много создано проектов. Удалите ненужные.');
		}
	}
}

function myonload()
{
	GetServerData();
	reg_reqvest();
	getperses();
	Serv_Command('rps',function f(s){document.getElementById('rps_dat').innerHTML=s});
}
function reg_reqvest()
{
	Serv_LoadFile('_can_i_register_.txt',reg_render);
}
function reg_render(s)
{
	if (s.trim()=='NO')
	{
		document.getElementById('reg_but').innerText='Включить регистрацию';
	}else{
		document.getElementById('reg_but').innerText='Выключить регистрацию';
	}
}
function reg_on_or_of()
{
	Serv_Command("reg_on_or_of", reg_reqvest);
}

function testing_run() {
	document.getElementById('run_but').disabled=true;
	if (testing_is_run==-1)
	{
		
		testing_is_run=1;
		is_work=1;
		document.getElementById('run_but').innerText='starting';
		Serv_Command("GetTests", testing_ParseTabs);
	}else
	{
		if (testing_is_run==0)
		{
			testing_is_run=1;
			is_work=1;
			document.getElementById('run_but').innerText='starting';
			isall(0);
		}
		else
		{
			testing_is_run=0;
			document.getElementById('run_but').innerText='Остановка...';
		}
	}
}
var all_tests = [];
var max_v = 0;
var v = 0;
var v_length = 0;

function testing_ParseTabs(s) {
	var all_json = JSON.parse(s);
	all_tests = [];
	for (var i = 0; i < all_json.length; i++) {
		all_tests[i]={};
		Object.keys(all_json[i]).forEach(function f8687(key) {
			var name_task = key;
			all_tests[i][key] = [];
			max_v+=all_json[i][key].length;
			for (var k = 0; k < all_json[i][key].length; k++) {
				Serv_Command('GetFile' + all_json[i][key][k].replace(new RegExp('/', 'gi'), '$').replace(new RegExp('\\\\', 'gi'), '$'), function f32092342(s, ii, keykey, kk) {
					v_length+=s.length+182+214;
					all_tests[ii][keykey][kk] = s;
					v++;
					isall(1);
				}, i, key, k);
			}
		});
	}
}
var is_work=1;
var testing_is_run=-1;
function is_work_test() {
	if (is_work==0 && testing_is_run==1)
	{
		
		document.getElementById('run_pre').innerHTML+=('server is not work!!!!<br>');
		setTimeout(is_work_test, 30000);
	}
	else
	{
		is_work=0;
		setTimeout(is_work_test, 10000);
		//Serv_Command("gettab", ParseTabs);
	}
	if (testing_is_run==1)
	{
		var aud = new Audio();
		aud.addEventListener('loadeddata', function() {
				aud.muted = false;
				aud.play();
		 }, false);
		aud.src = '/tileset/01034.mp3';
	}
};
function isall(vvv) {
	document.getElementById('run_but').innerText='Прогресс: '+Math.floor(v / max_v*100)+'% ('+v+' файла из '+max_v+') ('+Math.floor(v_length/1024)+' kbyte)';
	is_work=1;
	if (max_v == v) {
		if (vvv==1)
		{
			setTimeout(function f234234(){document.getElementById('run_pre').innerHTML+=('watchdog start<br>');is_work_test();}, 200);
		}
		document.getElementById('run_but').innerText='Запуск ('+Math.floor(v_length/1024)+' byte)';
		setTimeout(function f(){testing(true);}, 1000);
	}
}
var programs = [];
function testing(flag)
{
	is_work=1;
	if (flag)
		document.getElementById('run_but').innerText='Проверка программ';
	for (var j = 0; j < programs.length; j++) 
	if (programs[j][2]!=''){
		//if (programs[j][3]!='')
		//{
		//}else{
		var index_k = programs[j][2].trim();
		var otv_pler = 0;
		var rez = 0;
		var out_text = ''; //programs[j][2].trim()+'\r\n; log:\r\n';
		for (var k in all_tests[programs[j][1]][index_k])
		{
				RunKumir(programs[j][3], all_tests[programs[j][1]][index_k][k]);
				otv_pler++;
				if (ErrorKumir.length > 0) {
					rez++;
					if (out_text == '')
						out_text += '\r\n; log:\r\n';
					out_text += '; index:' + index_k + '.' + k + '\r\n';
					out_text += '; error: ' + JSON.stringify(ErrorKumir, null, '\t');
				}
		}
		programs[j][4] = ' ' + out_text;
		if (otv_pler == 0)
			programs[j][5] = 1234;
		else
			programs[j][5] = Math.floor((otv_pler - rez) / (otv_pler) * 100);
		//debugger;
		//Serv_Command('GetPrograms', testprog);
		//if (flag)
		document.getElementById('run_pre').innerHTML+= ('for '+programs[j][0]+' res is <br><pre>'+programs[j][3].trim().replace(/[\n]/g, '<br>')+''+ programs[j][4].trim().replace(/[\n]/g, '<br>')+'</pre><br>');
		Serv_SendProgramm(programs[j][4].trim(), programs[j][0], SendRes, 'res', programs[j][5]); // SendRes(programs[j][0],programs[j][3]);
		if (flag)
		{
			setTimeout(function f(){Serv_Command('GetPrograms', testprog);}, 3000);
			document.getElementById('run_but').innerText='Ждём 3 секунды (2)';
		}
		programs.splice(j, 1);
		//testing();
		return;
		//}
	}
	if (flag)
	{
		setTimeout(function f(){document.getElementById('run_but').innerText='Запрос на программы';Serv_Command('GetPrograms', testprog);}, 3000);
		document.getElementById('run_but').innerText='Ждём 3 секунды';
	}
}
function SendRes(s) {
	if (s = 'OK') {
		//setTimeout(function f(){Serv_Command('GetPrograms', testprog)}, 3000);
	} else
		alert(s);
}
function testprog(s) {
	document.getElementById('run_but').disabled=false;
	if (testing_is_run==0)
	{
		programs = [];
		document.getElementById('run_but').innerText='Запустить тестирующую систему';
		return;
	}
	document.getElementById('run_but').innerText='Обрабатываем программы';
	if (s.length > 0) {
		for (var k = 0; k < s.split(';').length; k++)
			if (s.split(';')[k].length > 0) {
				var prog_num = parseInt(s.split(';')[k]);
				var inarr = false
					for (var m = 0; m < programs.length; m++)
						if (programs[m][0] == prog_num)
							inarr = true;
					if (!inarr) {
						programs.push([prog_num, 0, "","", "", 0]);
						document.getElementById('run_pre').innerHTML+=('testing..'+prog_num+'<br>');
						Serv_Command('GetProgram' + prog_num, function f32092342(s, prog_num2) {
							for (var m = 0; m < programs.length; m++)
								if (programs[m][0] == prog_num2) {
									s = s.trim();
									programs[m][1] = parseInt(s.split('\n')[0].trim());
									programs[m][2] = GetIn(s, "\n", "").split('\n')[0];
									programs[m][3] = GetIn(GetIn(s, "\n", ""), "\n", "");
									break;
								}
							testing(false);
						}, prog_num);
					}
			}

	}
	testing(true);
}
var pers_arr=[['admin','Дмитрий','local12345','admin','Да',['ab03237d51',1,1620377993,'OK','program']]]
var select_pers_arr=[];
var select_pers_login;
function render2() {
	var s = '';
	s += '╔═════════════════╤═ Все игроки и админы ═╤═══════════════════╤═══════════════════╤═══════════════════╤═══════════════╗\n';
	s += '║      Логин      │          Имя          │       Пароль      │      Группа       │      Выбрать      │ Администратор ║\n';
	s += '╠═════════════════╪═══════════════════════╪═══════════════════╪═══════════════════╪═══════════════════╪═══════════════╣\n';
	for (var i = 0; i < pers_arr.length; i++) {
		var arr_slice = [format(pers_arr[i][0], 15), format(pers_arr[i][1], 21), format(pers_arr[i][2], 17), format(pers_arr[i][3], 17), format('<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Выбрать</button>', 17,'sel_it(\''+i+'\')'), format(pers_arr[i][4]+'', 13)];
		var max_el = 1;
		for (var j = 0; j < arr_slice.length; j++)
			max_el = Math.max(max_el, arr_slice[j].length);
		for (var j = 0; j < max_el; j++) {
			if (j < arr_slice[0].length)
				s += '║ ' + arr_slice[0][j];
			else
				s += '║ ' + ' '.repeat(15);
			if (j < arr_slice[1].length)
				s += ' │ ' + arr_slice[1][j];
			else
				s += ' │ ' + ' '.repeat(21);
			if (j < arr_slice[2].length)
				s += ' │ ' + arr_slice[2][j];
			else
				s += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[3].length)
				s += ' │ ' + arr_slice[3][j];
			else
				s += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[4].length)
				s += ' │ ' + arr_slice[4][j];
			else
				s += ' │ ' + ' '.repeat(17);
			if (j < arr_slice[5].length)
				s += ' │ ' + arr_slice[5][j];
			else
				s += ' │ ' + ' '.repeat(13);
			s += ' ║\n';
		}
		if (i != pers_arr.length - 1)
			s += '╟─────────────────┼───────────────────────┼───────────────────┼───────────────────┼───────────────────┼───────────────╢\n';
		//else
		0 //	s+='╚═══════════╧═══════════════╧═════════════╛\n';
	}
	s += '╚═════════════════╧═══════════════════════╧═══════════════════╧═══════════════════╧═══════════════════╧═══════════════╝\n';
	
	var s2 = '';
	if (select_pers_arr.length>0)
	{
	s2 += '╔══════════════╤══ Выбранный игрок или админ ══╤═════════════╗\n';
	s2 += '║   Свойство   │            Значение           │  Применить  ║\n';
	s2 += '╠══════════════╪═══════════════════════════════╪═════════════╣\n';
	for (var i = 0; i < select_pers_arr.length; i++) {
		var help_id=MD5(Math.random()+'').slice(0,8);
		var arr_slice = [format(select_pers_arr[i][0], 12), format(select_pers_arr[i][1], 29, help_id), format(select_pers_arr[i][2],11,'save_it(\''+select_pers_arr[i][3]+'\',\''+help_id+'\')')];
		var max_el = select_pers_arr[i][4];
		for (var j = 0; j < arr_slice.length; j++)
			max_el = Math.max(max_el, arr_slice[j].length);

		for (var j = 0; j < max_el; j++) {
			if (j < arr_slice[0].length)
				s2 += '║ ' + arr_slice[0][j];
			else
				s2 += '║ ' + ' '.repeat(12);
			if (j < arr_slice[1].length)
				s2 += ' │ ' + arr_slice[1][j];
			else
				s2 += ' │ ' + ' '.repeat(29);
			if (j < arr_slice[2].length)
				s2 += ' │ ' + arr_slice[2][j];
			else
				s2 += ' │ ' + ' '.repeat(11);
			s2 += ' ║\n';
		}
		if (i != select_pers_arr.length - 1)
			s2 += '╟──────────────┼───────────────────────────────┼─────────────╢\n';
		//else
		//	s+='╚═══════════╧═══════════════╧═════════════╛\n';
	}
	s2 += '╚══════════════╧═══════════════════════════════╧═════════════╝\n';
	}
	document.getElementById('perses_pre').innerHTML = s;
	document.getElementById('pers_pre').innerHTML = s2;
	return '';
}


function sel_it(i)
{
	Serv_Command('get_player_data_'+pers_arr[i][0],parse_player_data);
}
function parse_player_data(s)
{
	//['name','admin','<b>','name',1]
	select_pers_arr=[];
	for (var i=0;i<s.split('\n').length;i++)
	if (s.split('\n')[i].trim()!='')
	{
		var s2=s.split('\n')[i].trim();
		if (s2.indexOf(';login:')==0)
		{
			select_pers_arr.push(['Логин','<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 20px;" id="%%id%%">'+s2.split(';login:')[1] + '</textarea>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','login',2]);
			select_pers_login=s2.split(';login:')[1];
		}
		if (s2.indexOf(';name:')==0)
			select_pers_arr.push(['Имя','<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 20px;" id="%%id%%">'+s2.split(';name:')[1] + '</textarea>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','name',2]);
		if (s2.indexOf(';password:')==0)
			select_pers_arr.push(['Пароль','<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 20px;" id="%%id%%">'+s2.split(';password:')[1] + '</textarea>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','password',2]);
		if (s2.indexOf(';pos:')==0)
		{
			i++;
			var ii=0;
			while (s.split('\n')[i].trim().indexOf(';pos:')==0)
			{
				ii++;
				select_pers_arr.push(['Позиция №'+ii,'<pre style="position: absolute;margin: 0px;display: inline;" id="%%id%%">uniID: '+s.split('\n')[i].trim().split(':uniID:')[1]+'<br>X: '+s.split('\n')[i+1].trim().split(':posx:')[1]+'<br>Y: '+s.split('\n')[i+2].trim().split(':posy:')[1]+'</pre>','<button style="position: absolute;width: %%wid%%px;" onclick="if (confirm(\'Вы уверены?\')) {%%id%%}">Удалить</button>','pos',3]);
				i+=3;
			}
			i--;
		}
		if (s2.indexOf(';group:')==0)
			select_pers_arr.push(['Группа','<textarea style="position: absolute;resize: vertical;width: %%wid%%px; height: 20px;" id="%%id%%">' + s2.split(';group:')[1] + '</textarea>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','group',2]);
		if (s2.indexOf(';dollars:')==0)
		{
			i++;
			var ii=0;
			while (s.split('\n')[i].trim().indexOf(';dollars:')==0)
			{
				ii++;
				select_pers_arr.push(['Доллар №'+ii,'<pre style="position: absolute;margin: 0px;display: inline;">uniID: '+s.split('\n')[i].trim().split(':uniID:')[1]+'<br>pos: '+s.split('\n')[i+1].trim().split(':pos:')[1]+'</pre>','<button style="position: absolute;width: %%wid%%px;" onclick="if (confirm(\'Вы уверены?\')) {%%id%%}">Удалить</button>','dollars',2]);
				i+=2;
			}
			i--;
		}
		if (s2.indexOf(';isAdmin:')==0)
			if (s2.indexOf(';isAdmin:0')==0)
				select_pers_arr.push(['Админ','<select size="1" id="%%id%%" style="position: absolute;margin: 0px;display: inline;"><option value="1">Да</option><option value="0" selected>Нет</option></select>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','isAdmin',1]);
			else
				select_pers_arr.push(['Админ','<select size="1" id="%%id%%" style="position: absolute;margin: 0px;display: inline;"><option value="1" selected>Да</option><option value="0">Нет</option></select>','<button style="position: absolute;width: %%wid%%px;" onclick="%%id%%">Применить</button>','isAdmin',1]);
		if (s2.indexOf(';Dors:')==0)
		{
			i++;
			var ii=0;
			while (s.split('\n')[i].trim().indexOf(';Dors:')==0)
			{
				ii++;
				select_pers_arr.push(['Дверь №'+ii,'<pre style="position: absolute;margin: 0px;display: inline;" id="%%id%%">uniID: '+s.split('\n')[i].trim().split(':uniID:')[1]+'<br>pos: '+s.split('\n')[i+1].trim().split(':pos:')[1]+'</pre>','<button style="position: absolute;width: %%wid%%px;" onclick="if (confirm(\'Вы уверены?\')) {%%id%%}">Удалить</button>','Dors',2]);
				i+=2;
			}
			i--;
		}
		if (s2.indexOf(';IsAccess:')==0)
		{
			i++;
			var ii=0;
			while (s.split('\n')[i].trim().indexOf(';IsAccess:')==0)
			{
				ii++;
				select_pers_arr.push(['Доступ №'+ii,'<pre style="position: absolute;margin: 0px;display: inline;" id="%%id%%">uniID: '+s.split('\n')[i].trim().split(':uniID:')[1]+'<br>pos: '+s.split('\n')[i+1].trim().split(':pos:')[1]+'</pre><div style="display: none;" id="%%id%%">'+ii+'</div>','<button style="position: absolute;width: %%wid%%px;" onclick="if (confirm(\'Вы уверены?\')) {%%id%%}">Удалить</button>','IsAccess',2]);
				i+=2;
			}
			i--;
		}
		if (s2.indexOf(';programs:')==0)
		{
			i++;
			var ii=0;
			while (s.split('\n')[i].trim().indexOf(';programs:')==0)
			{
				ii++;
				select_pers_arr.push(['Программа №'+ii,'<pre style="position: absolute;margin: 0px;display: inline;">uniID: '+s.split('\n')[i].trim().split(':uniID:')[1]+'<br>Задача: №'+s.split('\n')[i+1].trim().split(':task:')[1]+'<br>Время сдачи: '+s.split('\n')[i+2].trim().split(':date:')[1]+'<br>Результат сдачи: '+s.split('\n')[i+3].trim().split(':res:')[1]+'<br>Программа:<br><textarea style="resize: none;width: %%wid%%px; height: 78px;" id="%%id%%">'+s.split('\n')[i+4].trim().split(':programm:')[1].replace(/_return_/g,'\r').replace(/_return2_/g,'\n')+'</textarea></pre>','','programs',11]);
				i+=5;
			}
			i--;
		}
	}
	select_pers_arr.push(['Удалить игрока','','<button style="position: absolute;width: %%wid%%px;background-color:rgba(128,0,0,1)" onclick="if (confirm(\'Вы уверены?\')) {%%id%%}">Удалить</button>','Delete',1]);
	render2();
}
function save_it(_com, _id)
{
	if (select_pers_arr == undefined || select_pers_arr.length == 0)
		return;
	
	console.log([_com, _id]);
	if (_com=='login')
	{
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_re_login_'+document.getElementById(_id).value,'exestrings',console.log)
		select_pers_arr=[];
	}
	if (_com=='name')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_re_name_'+document.getElementById(_id).value,'exestrings',console.log)
	if (_com=='password')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_set_pas_'+document.getElementById(_id).value,'exestrings',console.log)
	if (_com=='isAdmin')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_op_or_deop '+document.getElementById(_id).value,'exestrings',console.log)
	if (_com=='group')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_set_group_'+document.getElementById(_id).value.replace(/\r/g, '').replace(/\n/g, ' '),'exestrings',console.log)
	if (_com=='pos')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_select_serv '+document.getElementById(_id).innerHTML.split('<br>')[0].split(' ')[1]+'\r\n'+'comand_pos_del','exestrings',console.log)
	if (_com=='Dors')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_select_serv '+document.getElementById(_id).innerHTML.split('<br>')[0].split(' ')[1]+'\r\n'+'comand_dor_del_'+document.getElementById(_id).innerHTML.split('<br>')[1].split(' ')[1],'exestrings',console.log)
	if (_com=='IsAccess')
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_select_serv '+document.getElementById(_id).innerHTML.split('<br>')[0].split(' ')[1]+'\r\n'+'comand_access_del_'+document.getElementById(_id).innerHTML.split('<br>')[1].split(' ')[1],'exestrings',console.log)
	if (_com=='Delete')
	{
		Serv_SendPost('comand_select_player '+select_pers_login+'\r\n'+'comand_del','exestrings',console.log);
		select_pers_arr=[];
	}
	if (!(select_pers_arr == undefined || select_pers_arr.length == 0))
	{
		Serv_Command('get_player_data_'+select_pers_login,parse_player_data);
	}
	Serv_Command('get_list_players',parse_pers);
}


function getperses()
{
	Serv_Command('get_list_players',parse_pers);
}
function parse_pers(s)
{
	pers_arr=[];
	var i2=-1;
	for (var i=0;i<s.split('\n').length;i++)
	if (s.split('\n')[i].trim()!='')
	{
		var s2=s.split('\n')[i].trim();
		i2++;
		pers_arr[i2]=[];
		pers_arr[i2][0]=s2.split(';login:')[1].split(';name:')[0];
		pers_arr[i2][1]=s2.split(';name:')[1].split(';password:')[0];
		pers_arr[i2][2]=s2.split(';password:')[1].split(';isAdmin:')[0];
		pers_arr[i2][4]=s2.split(';isAdmin:')[1].split(';group:')[0];
		if (pers_arr[i2][4]=='0')
			pers_arr[i2][4]='Нет';
		else
			pers_arr[i2][4]='Да';
		pers_arr[i2][3]=s2.split(';group:')[1];
	}
	render2();
}





function SaveVal(a, b) {
	localStorage.setItem(a, b);
}
function GetVal(a, b) {
	if (null != localStorage.getItem(a))
		return localStorage.getItem(a);
	else
		return b;
}

var GameLogin = GetVal("login", '');
var GamePassword = GetVal("password", '');
function logunup(g) {
	if (g != 2) {
		localStorage.clear();
		document.location.href = "/login.html";
	} else
		myonload();
}

var Serv_iswork = false;
var get_errors = 0;
function Serv_Command(a /*string*/, f, iii, jjj, kkk) {
	if (GameLogin != '') {
		if (Serv_iswork == true) {
			if (a != "getpos")
				var timerId3546356 = setTimeout(function f567567() {
					Serv_Command(a, f, iii, jjj, kkk)
				}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/' + a + '.txt', true);
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				var xhr2 = new XHR2();
				xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				xhr2.onload = function () {
					if (xhr2.status == 200) {
						Serv_iswork = false;
						if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
							get_errors = 0;
							ping = (new Date) - newping;
							f(xhr2.responseText, iii, jjj, kkk);
						} else {
							get_errors++;
							if (get_errors > 10) {
								document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
								//alert('Неверный логин или пароль (связь с сервером потеряна)');
								//location.reload();
							}
							var timerId3546356 = setTimeout(function f567567() {
								Serv_Command(a, f, iii, jjj, kkk)
							}, Math.random() * 10);
						}
					} else
						xhr2.onerror();
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(1.2).');
					console.log('Сервер не ответил(1.2).');
				}
				xhr2.send();
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(1.1).');
			console.log('Сервер не ответил(1.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}


function Serv_SendPost( prog,a /*string*/, f) {
	if (GameLogin != '') {
		if (Serv_iswork == true) {
			var timerId3546356 = setTimeout(function f567567() {
				Serv_SendPost(prog,a /*string*/, f)
			}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' +GameLogin + '/' + a + '.txt', true); // /upload;res;10%;A1;.txt
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				//xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Отправляем кодировку
				xhr2.onreadystatechange = function () {
					if (xhr2.readyState == 4) {
						if (xhr2.status == 200) {
							Serv_iswork = false;
							if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
								get_errors = 0;
								f(xhr2.responseText);
							} else {
								get_errors++;
								if (get_errors > 10) {
									document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
									//alert('Неверный логин или пароль (связь с сервером потеряна)');
									//location.reload();
								}
								Serv_SendPost(prog,a, f);
							}
						} else
							xhr2.onerror();
					}
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(2.2).');
					console.log('Сервер не ответил(2.2).');
				}
				xhr2.send(encodeURIComponent(prog).replace(/%20/g, "+")); // Отправляем POST-запрос
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(2.1).');
			console.log('Сервер не ответил(2.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress) {
	if (leng == undefined) {
		leng = 'kumir';
	}
	if (progress == undefined) {
		progress = '';
	}

	if (GameLogin != '') {
		if (Serv_iswork == true) {
			var timerId3546356 = setTimeout(function f567567() {
				Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress)
			}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/upload;' + leng + ';' + Task + ';' + progress + ';.txt', true); // /upload;res;10%;A1;.txt
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				//xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Отправляем кодировку
				xhr2.onreadystatechange = function () {
					if (xhr2.readyState == 4) {
						if (xhr2.status == 200) {
							Serv_iswork = false;
							if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
								get_errors = 0;
								f(xhr2.responseText);
							} else {
								get_errors++;
								if (get_errors > 10) {
									document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
									//alert('Неверный логин или пароль (связь с сервером потеряна)');
									//location.reload();
								}
								Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress);
							}
						} else
							xhr2.onerror();
					}
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(2.2).');
					console.log('Сервер не ответил(2.2).');
				}
				xhr2.send(encodeURIComponent(Progr).replace(/%20/g, "+")); // Отправляем POST-запрос
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(2.1).');
			console.log('Сервер не ответил(2.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_login(Login, Password, func) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', 'commands/' + Login + '/login.txt', true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
			var xhr2 = new XHR();
			xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, Password) + '.txt', true);
			xhr2.onload = function () {
				if (xhr2.status == 200) {
					if (this.responseText == 'OK' || this.responseText == 'OKADMINOFADMIN' || this.responseText == 'OKADMIN') {}
					else {
						alert('Ошибка в логине или пароле');
						localStorage.clear();
						document.location.href = "/login.html";
					}
					GameLogin = Login;
					GamePassword = Password;
					if (this.responseText == 'OK')
						func(0);
					if (this.responseText == 'OKADMIN')
						func(1);
					if (this.responseText == 'OKADMINOFADMIN')
						func(2);
				} else
					xhr2.onerror();
			}
			xhr2.onerror = function () {
				alert('Ошибка в логине или пароле(!).');
				localStorage.clear();
				document.location.href = "/login.html";
			}
			xhr2.send();
		} else {
			xhr.onerror();
		}
	}

	xhr.onerror = function () {
		alert('Ошибка в логине(!) или пароле.');
		localStorage.clear();
		document.location.href = "/login.html";
	}
	xhr.send();
}

function Serv_LoadFile(url /*string*/, f, iii, kkk) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', url, true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			if (this.status == 200) {
				f(this.responseText, iii, kkk);
			}
		} else
			xhr.onerror();
	}

	xhr.onerror = function () {
		document.writeln('Сервер не ответил(3.1).');
		console.log('Сервер не ответил(3.1).');
	}
	xhr.send();
}





function ImageToMap(map_base64) {
	var image = new Image();
	image.onload = function () {
		var canvas = document.createElement('canvas');
		canvas.width = image.width;
		canvas.height = image.height;
		var context = canvas.getContext('2d');
		context.drawImage(image, 0, 0);
		var imageData = context.getImageData(0, 0, canvas.width, canvas.height);
		var map = [];
		var arr_dollars = [];
		var ppoint = [-10000, -10000];
		for (var y = 0; y < canvas.height; y++) {
			map[y] = [];
			for (var x = 0; x < canvas.width; x++) {
				map[y][x] = '_';
				var index = (y * imageData.width + x) * 4;
				var red = imageData.data[index];
				var green = imageData.data[index + 1];
				var blue = imageData.data[index + 2];
				var alpha = imageData.data[index + 3];
				if (alpha < 128) {
					red = 255;
					green = 255;
					blue = 255;
					imageData.data[index] = red;
					imageData.data[index + 1] = green;
					imageData.data[index + 2] = blue;
				}
				if (red > 200 && green > 200 && blue > 200) {
					continue; //белый
				}
				if (red < 50 && green < 50 && blue < 50) {
					red = 0; //чёрный, доллар
					green = 255;
					blue = 0;
					imageData.data[index] = red;
					imageData.data[index + 1] = green;
					imageData.data[index + 2] = blue;
					arr_dollars.push([x, y]);
				}
				if (red < 50 && green < 50 && blue > 200) {
					red = 0; //синий, дверь
					green = 255;
					blue = 0;
					imageData.data[index] = red;
					imageData.data[index + 1] = green;
					imageData.data[index + 2] = blue;
					map[y][x] = 'D';
				}
				if (red > 200 && green < 50 && blue < 50) {
					red = 0; //красный, нулевая точка
					green = 255;
					blue = 0;
					imageData.data[index] = red;
					imageData.data[index + 1] = green;
					imageData.data[index + 2] = blue;
					if (ppoint[0] == -10000 && ppoint[1] == -10000)
						ppoint = [x, y];
					else
						console.log('Есть две точки входа!!!');
				}
				//console.log([index, red, green, blue, alpha]);
			}
		}
		for (var y = 0; y < canvas.height; y++)
			for (var x = 0; x < canvas.width; x++) {
				var index = (y * imageData.width + x) * 4;
				var red = imageData.data[index];
				var green = imageData.data[index + 1];
				var blue = imageData.data[index + 2];
				if (red < 50 && green > 200 && blue < 50) {
					//зелёный, комната или дорога
					var summ = 0;
					var index = (y * imageData.width + (x - 1)) * 4;
					if (x - 1 >= 0 && (imageData.data[index] < 50 && imageData.data[index + 1] > 200 && imageData.data[index + 2] < 50))
						summ += 1000;
					var index = ((y - 1) * imageData.width + x) * 4;
					if (y - 1 >= 0 && (imageData.data[index] < 50 && imageData.data[index + 1] > 200 && imageData.data[index + 2] < 50))
						summ += 100;
					var index = (y * imageData.width + (x + 1)) * 4;
					if (x + 1 < canvas.width && (imageData.data[index] < 50 && imageData.data[index + 1] > 200 && imageData.data[index + 2] < 50))
						summ += 10;
					var index = ((y + 1) * imageData.width + x) * 4;
					if (y + 1 < canvas.height && (imageData.data[index] < 50 && imageData.data[index + 1] > 200 && imageData.data[index + 2] < 50))
						summ += 1;
					if (summ == 101) {
						if (map[y][x] != 'D')
							map[y][x] = 'V';
						else
							map[y][x] = 'DV';
					} else
						if (summ == 1010) {
							if (map[y][x] != 'D')
								map[y][x] = 'H';
							else
								map[y][x] = 'DH';

						} else {
							map[y][x] = 'R';
						}
					continue;
				}
			}
		var dbl_arr = [];
		for (var y = 0; y < canvas.height; y++) {
			dbl_arr[y] = [];
			for (var x = 0; x < canvas.width; x++)
				if (map[y][x] == '_')
					dbl_arr[y][x] = 1000000000;
				else
					dbl_arr[y][x] = 0;
		}
		var oth = [ppoint];
		//oth.shift
		while (oth.length > 0) {
			var el_x = oth[0][0],
			el_y = oth[0][1];
			oth.shift();
			if (el_x + 1 < canvas.width && dbl_arr[el_y][el_x + 1] != 0)
				dbl_arr[el_y][el_x] = Math.min(dbl_arr[el_y][el_x], dbl_arr[el_y][el_x + 1] + 1);
			if (el_y + 1 < canvas.height && dbl_arr[el_y + 1][el_x] != 0)
				dbl_arr[el_y][el_x] = Math.min(dbl_arr[el_y][el_x], dbl_arr[el_y + 1][el_x] + 1);
			if (el_x - 1 >= 0 && dbl_arr[el_y][el_x - 1] != 0)
				dbl_arr[el_y][el_x] = Math.min(dbl_arr[el_y][el_x], dbl_arr[el_y][el_x - 1] + 1);
			if (el_y - 1 >= 0 && dbl_arr[el_y - 1][el_x] != 0)
				dbl_arr[el_y][el_x] = Math.min(dbl_arr[el_y][el_x], dbl_arr[el_y - 1][el_x] + 1);
			if (el_x + 1 < canvas.width && dbl_arr[el_y][el_x + 1] == 0) {
				dbl_arr[el_y][el_x + 1] = dbl_arr[el_y][el_x] + 1;
				oth.push([el_x + 1, el_y]);
			}
			if (el_y + 1 < canvas.height && dbl_arr[el_y + 1][el_x] == 0) {
				dbl_arr[el_y + 1][el_x] = dbl_arr[el_y][el_x] + 1;
				oth.push([el_x, el_y + 1]);
			}
			if (el_x - 1 >= 0 && dbl_arr[el_y][el_x - 1] == 0) {
				dbl_arr[el_y][el_x - 1] = dbl_arr[el_y][el_x] + 1;
				oth.push([el_x - 1, el_y]);
			}
			if (el_y - 1 >= 0 && dbl_arr[el_y - 1][el_x] == 0) {
				dbl_arr[el_y - 1][el_x] = dbl_arr[el_y][el_x] + 1;
				oth.push([el_x, el_y - 1]);
			}
		}
		var ret_map = {};
		ret_map["RH"] = [];
		for (var y = 0; y < canvas.height; y++)
			for (var x = 0; x < canvas.width; x++)
				if (map[y][x] == 'H' || map[y][x] == 'DH') {
					var x2 = x;
					var isdor = '';
					while (x2 < canvas.width && (map[y][x2] == 'H' || map[y][x2] == 'DH'))
						if (map[y][x2] == 'H')
							x2++;
						else {
							isdor = 'open_' + dbl_arr[y][x2] + '_blocks';
							x2++;
						}
					x2--;
					for (var x3 = Math.max(x, 0); x3 <= Math.min(x2, canvas.width - 1); x3++) {
						map[Math.min(Math.max(y - 1, 0), canvas.height - 1)][x3] = '_';
						map[Math.min(Math.max(y, 0), canvas.height - 1)][x3] = '_';
						map[Math.min(Math.max(y + 1, 0), canvas.height - 1)][x3] = '_';
					}
					ret_map["RH"].push([y - ppoint[1], x - ppoint[0], x2 - ppoint[0], isdor]);
				}
		ret_map["RV"] = [];
		for (var y = 0; y < canvas.height; y++)
			for (var x = 0; x < canvas.width; x++)
				if (map[y][x] == 'V' || map[y][x] == 'DV') {
					var y2 = y;
					var isdor = '';
					while (y2 < canvas.height && (map[y2][x] == 'V' || map[y2][x] == 'DV'))
						if (map[y2][x] == 'V')
							y2++;
						else {
							isdor = 'open_' + dbl_arr[y2][x] + '_blocks';
							y2++;
						}
					y2--;
					for (var y3 = Math.max(y, 0); y3 <= Math.min(y2, canvas.height - 1); y3++) {
						map[y3][Math.min(Math.max(x - 1, 0), canvas.width - 1)] = '_';
						map[y3][Math.min(Math.max(x, 0), canvas.width - 1)] = '_';
						map[y3][Math.min(Math.max(x + 1, 0), canvas.width - 1)] = '_';
					}
					ret_map["RV"].push([x - ppoint[0], y - ppoint[1], y2 - ppoint[1], isdor]);
				}
		ret_map["room"] = [];
		for (var y = 0; y < canvas.height; y++)
			for (var x = 0; x < canvas.width; x++)
				if (map[y][x] == 'R') {
					var x2 = x;
					while (x2 < canvas.width && map[y][x2] == 'R')
						x2++;
					x2--;
					var y2 = y;
					while (y2 < canvas.height && map[y2][x] == 'R')
						y2++;
					y2--;
					for (var y3 = Math.max(y - 1, 0); y3 <= Math.min(y2 + 1, canvas.height - 1); y3++)
						for (var x3 = Math.max(x - 1, 0); x3 <= Math.min(x2 + 1, canvas.width - 1); x3++)
							map[y3][x3] = '_';
					ret_map["room"].push([x - 1 - ppoint[0], y - 1 - ppoint[1], x2 + 1 - ppoint[0], y2 + 1 - ppoint[1]]);
				}
		ret_map["dollar"] = [];
		for (var i = 0; i < arr_dollars.length; i++)
			ret_map["dollar"].push([arr_dollars[i][0] - ppoint[0], arr_dollars[i][1] - ppoint[1]]);
		var s = '';
		s += '[Count]\r\n';
		s += 'Room=' + ret_map["room"].length + '\r\n';
		s += 'road vertical=' + ret_map["RV"].length + '\r\n';
		s += 'road horizontal=' + ret_map["RH"].length + '\r\n';
		s += 'dollar=' + ret_map["dollar"].length + '\r\n\r\n';
		for (var i = 0; i < ret_map["room"].length; i++) {
			s += '[Room:' + i + ']\r\nPos1=' + ret_map["room"][i][0] + '\r\nPos2=' + ret_map["room"][i][1] + '\r\nPos3=' + ret_map["room"][i][2] + '\r\nPos4=' + ret_map["room"][i][3] + '\r\n\r\n';
		}
		for (var i = 0; i < ret_map["RV"].length; i++) {
			if (ret_map["RV"][i][3] == '')
				s += '[RV:' + i + ']\r\nPos1=' + ret_map["RV"][i][0] + '\r\nPos2=' + ret_map["RV"][i][1] + '\r\nPos3=' + ret_map["RV"][i][2] + '\r\n\r\n';
			else
				s += '[RV:' + i + ']\r\nPos1=' + ret_map["RV"][i][0] + '\r\nPos2=' + ret_map["RV"][i][1] + '\r\nPos3=' + ret_map["RV"][i][2] + '\r\ndor=' + ret_map["RV"][i][3] + '\r\n\r\n';
		}
		for (var i = 0; i < ret_map["RH"].length; i++) {
			if (ret_map["RH"][i][3] == '')
				s += '[RH:' + i + ']\r\nPos1=' + ret_map["RH"][i][0] + '\r\nPos2=' + ret_map["RH"][i][1] + '\r\nPos3=' + ret_map["RH"][i][2] + '\r\n\r\n';
			else
				s += '[RH:' + i + ']\r\nPos1=' + ret_map["RH"][i][0] + '\r\nPos2=' + ret_map["RH"][i][1] + '\r\nPos3=' + ret_map["RH"][i][2] + '\r\ndor=' + ret_map["RH"][i][3] + '\r\n\r\n';
		}
		for (var i = 0; i < ret_map["dollar"].length; i++) {
			s += '[D:' + i + ']\r\nPos1=' + ret_map["dollar"][i][0] + '\r\nPos2=' + ret_map["dollar"][i][1] + '\r\n\r\n';
		}
		console.log(s);
		return s;
	};
	image.src = map_base64;
}
//exemple: ImageToMap("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAbCAYAAABvCO8sAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEBSURBVEhLxY5RFoMwCAS9/6XbZMOmY0A/WrUz70VZMLhtr4ftx1P8f6GCQsLcEubWqMqBzp1kppgjn7QZM2Zka3BkG0OVPekbVSmw8XddMtOzPnpdoyoFhYS5JcytUbUGV1Hdde/C4qq88Lp95c/nhcuQBkLDzBLm1qhaAzIGdEZy9cK4vD3GU+/jaSLtw/Nd8pvu2rf9MHzvjAGdkSyXhoS5NarWgGggNMwsYW6Nql2w//YneK/JC4uhb6l+/t6FxV3lwkrC3BLm1qhKgVVnSGZ61keva1Sl4Mg2hip70jeqcqBzJ5kp5sgnbcaMGdkaFBLmljC3RhWDu/nfwufcXm9rydaaOBOgjgAAAABJRU5ErkJggg==");
/*function parseXml(xml){var dom=null;if(window.DOMParser){try{dom=(new DOMParser()).parseFromString(xml,"text/xml");}
catch(e){dom=null;}}
else if(window.ActiveXObject){try{dom=new ActiveXObject('Microsoft.XMLDOM');dom.async=false;if(!dom.loadXML(xml))
alert("Err: "+dom.parseError.reason+dom.parseError.srcText);}
catch(e){dom=null;}}
else
alert("cannot parse xml string!");return dom;}
function esc(s){return s.replace(/[\"]/g, '\\"').replace(/[\\]/g, '\\\\').replace(/[\/]/g, '\\/').replace(/[\b]/g, '\\b').replace(/[\f]/g, '\\f').replace(/[\n]/g, '\\n').replace(/[\r]/g, '\\r').replace(/[\t]/g, '\\t')}
var dom = parseXml(xml);

var s='[Count]\r\n';
s+='tasks='+dom.getElementsByTagName('T').length+'\r\n\r\n';
for (var i=0;i<dom.getElementsByTagName('T').length;i++)
{
    var elm=dom.getElementsByTagName('T')[i];
    s+='[Task:'+i+']\r\n';
    s+='URLDefaultProgram='+elm.getElementsByTagName('PROGRAM')[0].textContent+'\r\n';
    s+='name='+esc(elm.getAttribute('xml:name').trim())+'\r\n';
//__secret_information__
    var count=Math.min(elm.getElementsByTagName('ENV').length-Math.floor(elm.getElementsByTagName('ENV').length/2),3);
    s+='tab_count='+(count+3)+'\r\n';
    s+='tab_0_name=Условие\r\n';
    s+='tab_0_type=text\r\n';
    s+='tab_0_text='+esc(Array.from(elm.getElementsByTagName('DESC')[0].textContent.split('\n'),function (w){return w.trim()}).join('\n'))+'\r\n';
    s+='tab_1_name=Топ\r\n';
    s+='tab_1_type=site\r\n';
    s+='tab_1_url=\\top.html\r\n';
    for (var j=0;j<count;j++)
    {
        s+='tab_'+(j+2)+'_name=Тест '+(j+1)+'\r\n';
        s+='tab_'+(j+2)+'_type=fil\r\n';
        s+='tab_'+(j+2)+'_url='+esc(elm.getElementsByTagName('ENV')[j].textContent.trim())+'\r\n';
    }
    s+='tab_'+(count+2)+'_name=Загрузить\r\n';
    s+='tab_'+(count+2)+'_type=load\r\n';
    s+='test_count='+elm.getElementsByTagName('ENV').length+'\r\n';

    for (var j=0;j<elm.getElementsByTagName('ENV').length;j++)
        s+='test_'+j+'='+esc(elm.getElementsByTagName('ENV')[j].textContent.trim())+'\r\n';
     s+='\r\n';
}
console.log(s);*/
var xml = `<?xml version='1.0' encoding='UTF-8'?>
<KURS root="true" xml:id="0" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="ОСНОВНОЙ ТУР - КУМИР-2020">
	<T root="false" xml:id="1" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Черный ход">
		<DESC>Принцесса Египта Нефертити была похоронена вместе
			с ключом от Великого Равновесия в огромной пирамиде,
			в которой находится вход в подземный город.
			Ключ от Великого Равновесия ей вручил Дед Мороз
			3000 лет назад, когда она ещё была маленькая.
			Разбудить её можно только поцелуем.
			Три богатыря добрались до пирамиды. Теперь им
			необходимо найти черный ход (клетку, отмеченную буквой &lt;b&gt;Б&lt;/b&gt;),
			который расположен с противоположной стороны пирамиды
			прямо напротив них. &lt;br/&gt;
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>back_door/4.fil</ENV>
			<ENV>back_door/3.fil</ENV>
			<ENV>back_door/2.fil</ENV>
			<ENV>back_door/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>back_door/back_door.kum</PROGRAM>
	</T>
	<T root="false" xml:id="2" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Часовые">
		<DESC>Мудрый и сильный, но строгий богатырь Добрыня Никитич,
			сотрудник пограничной службы, предложил оптимизировать
			охрану границы и по новому расставить часовых (закрасить клетки).
			По окончанию разводящий должен вернуться в позицию,
			отмеченную буквой &lt;b&gt;Б&lt;/b&gt;.
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>sentry/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>sentry/sentry.kum</PROGRAM>
	</T>
	<T root="false" xml:id="3" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Поиск оленя">
		<DESC>Всем известно что Дурило - младший брат Деда Мороза,
			13-ый запасной месяц, который реальным месяцем так и
			не стал. Зато он стал коварным и решил сделать себя
			самым главным месяцем в году и установить вечное лето.
			Для этого он  украл оленя у Деда Мороза и спрятал его.
			Помогите Деду Морозу, который стоит где-то на поле,
			закрасить все отмеченные клетки и найти оленя,
			спрятанного в клетке &lt;b&gt;Б&lt;/b&gt;.
			(Длина границы и размеры государства считайте неизвестными).
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>border/4.fil</ENV>
			<ENV>border/3.fil</ENV>
			<ENV>border/2.fil</ENV>
			<ENV>border/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>border/border.kum</PROGRAM>
	</T>
	<T root="false" xml:id="4" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Шум-гора">
		<DESC>Самый младший богатырь Алёша Попович родом из Ростова.
			Весёлый и честный парень решил жениться на Любаве — его
			лучшей подруге с самого детства. Долго ли, коротко ли,
			но оказался Алеша совсем рядом с Любавой, которая ждет
			его у подножия горы с другой стороны. Осталось совсем
			чуть-чуть. Подскажите Алеше дорогу до Любавы, закрасив
			все клетки на его пути. Высота горы не известна.
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>shaft/4.fil</ENV>
			<ENV>shaft/1.fil</ENV>
			<ENV>shaft/3.fil</ENV>
			<ENV>shaft/2.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>shaft/shaft.kum</PROGRAM>
	</T>
	<T root="false" xml:id="5" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Великий Новгород">
		<DESC>Юлий - конь Алёши Поповича, единственный конь на свете,
			который умеет говорить. Решил Юлий посетить свой родной
			город — Новгород, вокруг которого много болот. Глубина
			болота неизвестна, да и  насколько оно простирается тоже.
			Помогите коняшке добраться до родного края, преодолеть
			болото и пометить свой путь (закрасить клетки),
			чтобы потом по нему вернуться обратно.
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>ditch/1.fil</ENV>
			<ENV>ditch/2.fil</ENV>
			<ENV>ditch/3.fil</ENV>
			<ENV>ditch/4.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>ditch/ditch.kum</PROGRAM>
	</T>
	<T root="false" xml:id="6" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Дед Мороз">
		<DESC>Главный новогодний волшебник Дед Мороз еще тот дизайнер.
			В некоторые места не может ездить без своего оленя,
			например, в Египет. Пока до Нового года еще есть время,
			решил он съездить отдохнуть. А по пути оставить за собой
			волшебный след закрашивая все отмеченные клетки.
			Пока не покрасит - Новый год не наступит!
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>2020/4.fil</ENV>
			<ENV>2020/2.fil</ENV>
			<ENV>2020/3.fil</ENV>
			<ENV>2020/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>2020/2020.kum</PROGRAM>
	</T>
	<T root="false" xml:id="7" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Т-ри">
		<DESC>Великий Князь, правитель Киева,  — прямое начальство богатырей.
			Решил он увековечить свое имя, для чего велел нарисовать свой
			собственный герб, состоящий из трех букв «Т».
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>3T/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>3T/3T.kum</PROGRAM>
	</T>
	<T root="false" xml:id="8" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Баба-Яга">
		<DESC>Баба-Яга потомственная колдунья в шестом поколении,
			знающая толк в древней тёмной магии.
			Живет на болоте в избушке на курьих ножках.
			Считает свое болото самым экологически чистым местом,
			но не прочь переехать поближе к стольному граду и жить
			в более комфортных условиях.
			Помогите Бабе-Яге перебраться в стольный град и
			отметить там свое присутствие.
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>baba_yaga/3.fil</ENV>
			<ENV>baba_yaga/2.fil</ENV>
			<ENV>baba_yaga/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>baba_yaga/baba.kum</PROGRAM>
	</T>
	<T root="false" xml:id="9" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Дырявый лабиринт">
		<DESC>Илья Муромец самый сильный из трёх богатырей.
			Очень суеверный и наблюдательный. Илья незаметно
			для себя влюбился в Алёнушку и поспешил навстречу
			ей. Но на пути его встретился неведомый лабиринт,
			наполненный нечистью. Необходимо пройти извилистый
			путь и избавиться от темных сил, осветив (закрасив)
			места, отмеченные точками.
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>labirint/3.fil</ENV>
			<ENV>labirint/2.fil</ENV>
			<ENV>labirint/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>labirint/labirint.kum</PROGRAM>
	</T>
	<T root="false" xml:id="10" xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:name="Задача - Частокол">
		<DESC>Вождь тугарского войска Тугарин Змей — огромный,
			сильный, охочий до золота. Ограбил Ростов, после
			чего Алеша, который не смог это предотвратить
			построил усиленный забор.
			Нужно покрасить все отмеченные клетки&lt;br/&gt;
		</DESC>
		<CS>Кумир</CS>
		<ISP xml:ispname="Robot" xmlns:xml="http://www.w3.org/XML/1998/namespace">
			<ENV>fence/1.fil</ENV>
		</ISP>
		<READY>false</READY>
		<PROGRAM>fence/fence.kum</PROGRAM>
	</T>
</KURS>
`;
