function SaveVal(a, b) {
	localStorage.setItem(a, b);
}
function GetVal(a, b) {
	if (null != localStorage.getItem(a))
		return localStorage.getItem(a);
	else
		return b;
}
var ___login = GetVal("login", '');
var ___password = GetVal("password", '');
Serv_login(___login, ___password, game_onlogin);
var players_mode_g=0;
function game_onlogin(g) {
	if (g == 1) {
		var now = new Date();
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_run_tur.html") {
			update_tab(0);
			setInterval(run_tur_interv, 100);
			document.getElementsByName('u')[2].value = new Date(Math.floor((now.getTime() - now.getTimezoneOffset() * 60000) / 60000 / 5 + 1.3) * 60000 * 5).toISOString().substring(0, 16);
			Serv_Command('_proj_list_', parse__proj_list);
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_add_in_group.html") {
			players_mode_g=0;
			Serv_Command('_get_players_no_group_', parse_players_list);
			Serv_Command('_get_stat_players_', parse_stat_list);
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_del_from_group.html") {
			players_mode_g=1;
			Serv_Command('_get_players_in_group_', parse_players_list);
			Serv_Command('_get_stat_players_', parse_stat_list);
		}

	} else {
		localStorage.clear();
		document.location.href = "/login.html";
	}
	//Serv_LoadFile('\\task\\all.json', ParseTabs);
}
function parse_stat_list(s)
{
	document.getElementsByName('r2')[0].innerHTML = 'У вас в группе: '+s.split('\n')[0].trim();
	document.getElementsByName('r2')[1].innerHTML = 'Зарегистрировано без группы: '+s.split('\n')[1].trim();
	document.getElementsByName('r2')[2].innerHTML = 'Всего игроков: '+s.split('\n')[2].trim();
}
function parse_players_list(s)
{
	var s2='<tr><th>Логин</th><th>Имя</th><th style="width: 100px;">Добавить</th></tr>';
	if (players_mode_g!=0)
		s2='<tr><th>Логин</th><th>Имя</th><th style="width: 100px;">Удалить</th></tr>'
	for (var i=1;i<s.split('\n').length;i++)
	if (s.split('\n')[i].trim()!='')
	{
		var v = MD5(Math.random() + '').slice(0, 10);
		if (players_mode_g==0)
		s2+='<tr><td id="id_login_'+v+'">'+s.split('\n')[i].split(';')[0]+'</td><td id="id_name_'+v+'">'+s.split('\n')[i].split(';')[1]+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+v+'" onclick="add_player(\''+s.split('\n')[i].split(';')[0]+'\',\''+v+'\');">Добавить</button></td></tr>';
		else
		s2+='<tr><td id="id_login_'+v+'">'+s.split('\n')[i].split(';')[0]+'</td><td id="id_name_'+v+'">'+s.split('\n')[i].split(';')[1]+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+v+'" onclick="del_player(\''+s.split('\n')[i].split(';')[0]+'\',\''+v+'\');">Удалить</button></td></tr>';

	}
	document.getElementById('top_tabl').innerHTML = s2;
	Serv_Command('_get_stat_players_', parse_stat_list);
}
function add_player(s,id)
{
	document.getElementById('id_login_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_name_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_btn_'+id).style.display = 'none';
	Serv_Command('_player_add_group_'+s+'_', parse_players_group);
	
}
function del_player(s,id)
{
	document.getElementById('id_login_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_name_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_btn_'+id).style.display = 'none';
	Serv_Command('_player_del_group_'+s+'_', parse_players_group);
}
function parse_players_group(s)
{
	if (s!='OK')
		alert(s);
	if (players_mode_g==0)
		Serv_Command('_get_players_no_group_', parse_players_list);
	else
		Serv_Command('_get_players_in_group_', parse_players_list);
}
function parse__proj_list(s)
{
	var obj = [];
	for (var i = 1; i < s.split('\n').length; i++)
		if (s.split('\n')[i].trim() != '') {
			obj[i - 1] = {};
			obj[i - 1]['folder'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[0];
			obj[i - 1]['name'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[1];
			obj[i - 1]['tasks'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[2];
		}
	var s2='';
	for (var i = 0; i < obj.length; i++) {
		s2 += '<option value="'+i+'">'+obj[i].name+' ('+obj[i].folder+')</option> ';
	}
	document.getElementsByName('u')[0].innerHTML = s2;
	
}
var select_tab = 0, select_tab_arr = [];

var del_proj_f=0;
function del_proj()
{
	del_proj_f++;
	if (del_proj_f==2)
	{
		del_proj_f=0;
		document.getElementsByName('del_p')[0].innerHTML = 'Удалить';
		if (select_tab != 0)
		{
			Serv_Command('del_proj_'+select_tab_arr[1]+'_',del_proj_parse);
			SelectIt(0);
		}
	}else
		document.getElementsByName('del_p')[0].innerHTML = 'Нажмите ещё раз';
}
function del_proj_parse(s)
{
	if (s!='OK')
	{
		alert(s);
	}
	update_tab(0);
}


function SelectIt(ii, gg) {
	console.log([ii, gg]);
	del_proj_f=0;
	document.getElementsByName('del_p')[0].innerHTML = 'Удалить';
	select_tab_arr = gg;
	if (ii == 0) {
		document.getElementById('id_new_tur').style.display = '';
		document.getElementById('id_edit_tur').style.display = 'none';
		select_tab = 0;
	} else {
		document.getElementById('id_new_tur').style.display = 'none';
		document.getElementById('id_edit_tur').style.display = '';
		select_tab = ii;
		update_top_interv();
	}
}

function parse_update_tab(s, ii) {
	var obj = [];
	for (var i = 1; i < s.split('\n').length; i++)
		if (s.split('\n')[i].trim() != '') {
			obj[i - 1] = {};
			obj[i - 1]['name'] = s.split('\n')[i].split(';')[0];
			obj[i - 1]['can'] = s.split('\n')[i].split(';')[1];
			obj[i - 1]['start'] = s.split('\n')[i].split(';')[2];
			obj[i - 1]['freez'] = s.split('\n')[i].split(';')[3];
			obj[i - 1]['end'] = s.split('\n')[i].split(';')[4];
			obj[i - 1]['uniID'] = s.split('\n')[i].split(';')[5];
		}
	var s2 = '<button onclick="SelectIt(0)">Новый</button>';
	for (var i = 0; i < obj.length; i++) {
		if (obj[i].can == 'NOOK')
			s2 += '<button style="color:rgba(255,70,70,1)" title="Не доступен"';
		else
		if (obj[i].can == 'ONLY_YOU')
			s2 += '<button style="color:rgba(88,88,88,1)" title="Только администраторы"';
		else
		if (obj[i].can == 'YOU_AND_YOUR_GRUOP')
			s2 += '<button style="color:rgba(255,255,0,1)" title="Моя группа" ';
		else
			s2 += '<button  title="Все" ';
		s2 += 'onclick="SelectIt(' + (i + 1) + ',[\'' + obj[i].name + '\',\'' + obj[i].uniID + '\',' + obj[i].start + ',' + obj[i].freez + ',' + obj[i].end + '])">P' + (i + 1) + '</button>'
	}
	document.getElementById('id_tab').innerHTML = s2;
	if (ii >= 0)
		SelectIt(ii);
	else {
		var i = obj.length + ii;
		SelectIt(i + 1, [obj[i].name, obj[i].uniID, parseInt(obj[i].start), parseInt(obj[i].freez), parseInt(obj[i].end)]);
	}
}

function update_top_interv() {
	if (select_tab != 0)
		Serv_Command('_get_top_proj_'+select_tab_arr[1]+'_',ParseData);
}
setInterval(update_top_interv,10000);

function update_tab(ii) {
	Serv_Command('_my_server_list_', parse_update_tab, ii);
}

function run_tur_interv() {
	if (select_tab != 0) {
		var now = new Date();
		var ansv=[];
		ansv[0] = 'Название: ' + select_tab_arr[0] + ' (uniID: ' + select_tab_arr[1] + ')';
		if (select_tab_arr[2] - now.getTime() / 1000 >= 0)
			ansv[1] = 'Старт: ' + new Date(select_tab_arr[2] * 1000 - now.getTimezoneOffset() * 60000).toMyISOString() + ' (через ' + ToText(select_tab_arr[2] - now.getTime() / 1000) + ')';
		else
			ansv[1] = 'Старт: ' + new Date(select_tab_arr[2] * 1000 - now.getTimezoneOffset() * 60000).toMyISOString() + ' (было ' + ToText(now.getTime() / 1000 - select_tab_arr[2]) + ' назад)';
		
		
		if (select_tab_arr[3] < 0)
			ansv[2] =  'Заморозка: не замораживать';
		else
			if (select_tab_arr[3] > 2 * 365 * 24 * 60 * 60)
				ansv[2] = 'Заморозка: сразу';
			else
			{
				ansv[2] = 'Заморозка: за ' + ToText(select_tab_arr[3]) + ' до конца ';
				if (select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 - select_tab_arr[3] >= 0)
					ansv[2] += '(через ' + ToText(select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 - select_tab_arr[3])+')';
				else
					ansv[2] += '(было ' + ToText(0-select_tab_arr[4] - select_tab_arr[2] + now.getTime() / 1000 + select_tab_arr[3])+')';
			}
		
		
		ansv[3] = 'Продолжительность: ' + ToText(select_tab_arr[4])+' ';
		if (select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 >= 0)
			ansv[3] += '(Конец через ' + ToText(select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000)+')';
		else
			ansv[3] += '(Конец был ' + ToText(0-select_tab_arr[4] - select_tab_arr[2] + now.getTime() / 1000)+' назад)';
		if (document.getElementsByName('r')[0].innerHTML!=ansv[0])
			document.getElementsByName('r')[0].innerHTML=ansv[0];
		if (document.getElementsByName('r')[1].innerHTML!=ansv[1])
			document.getElementsByName('r')[1].innerHTML=ansv[1];
		if (document.getElementsByName('r')[2].innerHTML!=ansv[2])
			document.getElementsByName('r')[2].innerHTML=ansv[2];
		if (document.getElementsByName('r')[3].innerHTML!=ansv[3])
			document.getElementsByName('r')[3].innerHTML=ansv[3];
		return;
	}
	var select_proj = parseInt(document.getElementsByName('u')[0].value);
	var name_tur = document.getElementsByName('u')[1].value;
	var start_tur = (new Date(document.getElementsByName('u')[2].value)) - 0;
	var end_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60;
	var freez_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60 - parseInt(document.getElementsByName('u')[4].value) * 60;
	var group_tur = document.getElementsByName('u')[5].value;
	var return_code = '';

	if (name_tur.length < 3)
		return_code = 'Поле с именем проекта содержит слишком мало символов';
	if (name_tur.length >= 32)
		return_code = 'Поле с именем проекта содержит слишком много символов';
	for (var i = 0; i < name_tur.length; i++)
		if (!('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZабвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ0123456789. '.indexOf(name_tur[i]) + 1))
			return_code = 'Поле с именем проекта содержит запрещёный символ (' + name_tur[i] + ')';
	if (start_tur > end_tur)
		return_code = 'Тур должен длиться положительное число минут';
	if (start_tur != start_tur)
		return_code = 'Cтарт isNAN';
	if (freez_tur != freez_tur)
		return_code = 'Заморозка isNAN';
	if (end_tur != end_tur)
		return_code = 'Продолжительность isNAN';
	if (document.getElementById('out_return_code').innerHTML != return_code)
		document.getElementById('out_return_code').innerHTML = return_code;
}

function run_tur() {
	if (select_tab != 0)
		return;
	run_tur_interv();
	if (document.getElementById('out_return_code').innerHTML != '') {
		alert(document.getElementById('out_return_code').innerHTML);
		return;
	}
	var select_proj = parseInt(document.getElementsByName('u')[0].value);
	var name_tur = document.getElementsByName('u')[1].value;
	var start_tur = (new Date(document.getElementsByName('u')[2].value)) - 0;
	var end_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60000;
	var freez_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60000 - parseInt(document.getElementsByName('u')[4].value) * 60000;
	var group_tur = document.getElementsByName('u')[5].value;
	var v = MD5(Math.random() + '').slice(0, 10);
	//(proj parent)_(visib name)_(time_start)_(time_freeze)_(time_end)_(group)_(uniID)_
	Serv_Command('create_proj_' + select_proj + '_' + name_tur + '_' + Math.floor(start_tur / 1) + '_' + Math.floor(freez_tur / 1) + '_' + Math.floor(end_tur / 1) + '_' + group_tur + '_' + v + '_', add_proj_acc);
}
function add_proj_acc(s) {
	if (s != 'OK') {
		alert(s);
		return;
	}
	update_tab(-1);

}
//Server---Server---Server---Server---Server---Server---Server
function swap(items, firstIndex, secondIndex){
    var temp = items[firstIndex];
    items[firstIndex] = items[secondIndex];
    items[secondIndex] = temp;
}
function partition(items, left, right) {
    var pivot,pivot_s
        i       = left,
        j       = right;
	pivot = -(parseFloat(items[Math.floor((right + left) / 2)][2])*1000000-parseFloat(items[Math.floor((right + left) / 2)][3]));
	pivot_s = items[Math.floor((right + left) / 2)][1];
    while (i <= j) {
        while ((-(parseFloat(items[i][2])*1000000-parseFloat(items[i][3])) < pivot)||((-(parseFloat(items[i][2])*1000000-parseFloat(items[i][3])) == pivot)&&(items[i][1]<pivot_s))) {
            i++;
        }
        while ((-(parseFloat(items[j][2])*1000000-parseFloat(items[j][3])) > pivot)||((-(parseFloat(items[j][2])*1000000-parseFloat(items[j][3])) == pivot)&&(items[j][1]>pivot_s))) {
            j--;
        }
        if (i <= j) {
            swap(items, i, j);
            i++;
            j--;
        }
    }
    return i;
}
function QSORT(items, left, right) {
    var index;
    if (items.length > 1) {
        index = partition(items, left, right);
        if (left < index - 1) {
            QSORT(items, left, index - 1);
        }
        if (index < right) {
            QSORT(items, index, right);
        }
    }
    return items;
}
function ParseData(s)
{
	if (select_tab == 0 || select_tab_arr.length < 2)
		return;
	console.log(s);
	var arr=[];
	if (s.length==0)
		return;
	//debugger;
	for (var i=0;i<s.split('\n').length;i++)
		if (s.split('\n')[i].trim()!='')
		{
			arr[i]=[];
			if (i==0)
				arr[i][0]='Номер';
			else
			{
				arr[i][0]=i;
				for (var j=0;j<arr[0].length-1;j++)
					arr[i][arr[i].length]='0';
			}
			var __index=0;
			for (var j=0;j<s.split('\n')[i].split(';').length;j++)
				if (s.split('\n')[i].split(';')[j].trim()!='')
				{
					if (i==0)
					{
						if (s.split('\n')[i].split(';')[j].trim()=='names')
						{
							arr[i][arr[i].length]='Кто';
						}else
						if (s.split('\n')[i].split(';')[j].trim()=='scores')
						{
							arr[i][arr[i].length]='=';
						}else
						if (s.split('\n')[i].split(';')[j].trim()=='fine')
						{
							arr[i][arr[i].length]='штраф';
						}else
							arr[i][arr[i].length]=s.split('\n')[i].split(';')[j].trim();
					}
					else
					{
						__index++;
						if (__index<4)
						{
							arr[i][__index]=s.split('\n')[i].split(';')[j].trim();
						}
						else
						{
							for (var k=4;k<arr[0].length;k++)
							if (s.split('\n')[i].split(';')[j].trim().slice(1,-1)==arr[0][k])
							arr[i][k] = '100';
						}
					}
				}
		}
	//console.log(arr);
	arr=QSORT(arr, 1, arr.length - 1);
	//console.log(arr);
	var out_s='<tbody>';
	for (var i=0;i<arr.length;i++)
		{
			out_s+='<tr>';
			if (i==0)
				out_s+='<th>'+arr[i][0]+'</th>';
			else
				out_s+='<td>'+i+'</td>';
			for (var j=1;j<arr[i].length;j++)
				{
					if (i==0)
					{
						if (j<4)
							out_s+='<th>'+arr[i][j]+'</th>';
						else
						//if (my_access.indexOf(arr[i][j])<0)
						//	out_s+='<th title="'+arr[i][j]+'" style="color: #000000;text-decoration: underline;">'+GetName(j-3)+'</th>';
						//else
						out_s+='<th title="'+arr[i][j]+'" style="">'+arr[i][j]+'</th>';
					}
					else
					{
						if ((arr[i][j]==100)&&(j>2))
							out_s+='<td style="color: #0a0;">';
						else
							out_s+='<td>';
						out_s+=arr[i][j];
						out_s+='</td>';
					}
				}
			out_s+='</tr>';
		}
	out_s+='</tbody>';
	console.log(out_s);
	if (document.getElementById("top_tabl").innerHTML!=out_s)
		document.getElementById("top_tabl").innerHTML=out_s;
}


//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
function pad(number) {
	if (number < 10) {
		return '0' + number;
	}
	return number;
}
Date.prototype.toMyISOString = function () {
	return pad(this.getUTCHours()) +
	':' + pad(this.getUTCMinutes())+
	' ' + pad(this.getUTCDate()) +
	'.' + pad(this.getUTCMonth() + 1) +
	'.' + this.getUTCFullYear();
};
function ToText(seconds) {
	interval = seconds / 31536000;
	if (interval > 1) {
		if (Math.floor(seconds / 2592000) % 12 != 0)
			return Math.floor(interval) + " г. и " + (Math.floor(seconds / 2592000) % 12) + " м.";
		else
			return Math.floor(interval) + " г.";
	}
	interval = seconds / 2592000;
	if (interval > 1) {
		if (Math.floor(seconds / 86400) % 30 != 0)
			return Math.floor(interval) + " м. и " + (Math.floor(seconds / 86400) % 30) + " д.";
		else
			return Math.floor(interval) + " м.";
	}

	interval = seconds / 86400;
	if (interval > 1) {
		if (Math.floor(seconds / 3600) % 24 != 0)
			return Math.floor(interval) + " д. и " + (Math.floor(seconds / 3600) % 24) + " ч.";
		else
			return Math.floor(interval) + " д.";
	}

	interval = seconds / 3600;
	if (interval > 1) {
		if (Math.floor(seconds / 60) % 60 != 0)
			return Math.floor(interval) + " ч. и " + (Math.floor(seconds / 60) % 60) + " м.";
		else
			return Math.floor(interval) + " ч.";
	}

	interval = seconds / 60;
	if (interval > 1) {
		if (Math.floor(seconds % 60) != 0)
			return Math.floor(interval) + " м. и " + Math.floor(seconds % 60) + " с.";
		else
			return Math.floor(interval) + " м.";
	}
	return Math.floor(seconds) + " с.";
}
var MD5 = function (r) {
	function i(r, n) {
		return r << n | r >>> 32 - n
	}
	function c(r, n) {
		var t,
		o,
		e,
		u,
		a;
		return e = 2147483648 & r,
		u = 2147483648 & n,
		a = (1073741823 & r) + (1073741823 & n),
		(t = 1073741824 & r) & (o = 1073741824 & n) ? 2147483648 ^ a ^ e ^ u : t | o ? 1073741824 & a ? 3221225472 ^ a ^ e ^ u : 1073741824 ^ a ^ e ^ u : a ^ e ^ u
	}
	function n(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c((f = n) & t | ~f & o, e), a)),
		c(i(r, u), n)
	}
	function t(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c(n & (f = o) | t & ~f, e), a)),
		c(i(r, u), n)
	}
	function o(r, n, t, o, e, u, a) {
		return r = c(r, c(c(n ^ t ^ o, e), a)),
		c(i(r, u), n)
	}
	function e(r, n, t, o, e, u, a) {
		return r = c(r, c(c(t ^ (n | ~o), e), a)),
		c(i(r, u), n)
	}
	function u(r) {
		var n,
		t = "",
		o = "";
		for (n = 0; n <= 3; n++)
			t += (o = "0" + (r >>> 8 * n & 255).toString(16)).substr(o.length - 2, 2);
		return t
	}
	var a,
	f,
	C,
	g,
	h,
	v,
	d,
	S,
	l,
	m = Array();
	for (m = function (r) {
		for (var n, t = r.length, o = t + 8, e = 16 * (1 + (o - o % 64) / 64), u = Array(e - 1), a = 0, f = 0; f < t; )
			a = f % 4 * 8, u[n = (f - f % 4) / 4] = u[n] | r.charCodeAt(f) << a, f++;
		return a = f % 4 * 8,
		u[n = (f - f % 4) / 4] = u[n] | 128 << a,
		u[e - 2] = t << 3,
		u[e - 1] = t >>> 29,
		u
	}
		(r = function (r) {
			r = r.replace(/\r\n/g, "\n");
			for (var n = "", t = 0; t < r.length; t++) {
				var o = r.charCodeAt(t);
				o < 128 ? n += String.fromCharCode(o) : (127 < o && o < 2048 ? n += String.fromCharCode(o >> 6 | 192) : (n += String.fromCharCode(o >> 12 | 224), n += String.fromCharCode(o >> 6 & 63 | 128)), n += String.fromCharCode(63 & o | 128))
			}
			return n
		}
			(r)), v = 1732584193, d = 4023233417, S = 2562383102, l = 271733878, a = 0; a < m.length; a += 16)
		v = n(f = v, C = d, g = S, h = l, m[a + 0], 7, 3614090360), l = n(l, v, d, S, m[a + 1], 12, 3905402710), S = n(S, l, v, d, m[a + 2], 17, 606105819), d = n(d, S, l, v, m[a + 3], 22, 3250441966), v = n(v, d, S, l, m[a + 4], 7, 4118548399), l = n(l, v, d, S, m[a + 5], 12, 1200080426), S = n(S, l, v, d, m[a + 6], 17, 2821735955), d = n(d, S, l, v, m[a + 7], 22, 4249261313), v = n(v, d, S, l, m[a + 8], 7, 1770035416), l = n(l, v, d, S, m[a + 9], 12, 2336552879), S = n(S, l, v, d, m[a + 10], 17, 4294925233), d = n(d, S, l, v, m[a + 11], 22, 2304563134), v = n(v, d, S, l, m[a + 12], 7, 1804603682), l = n(l, v, d, S, m[a + 13], 12, 4254626195), S = n(S, l, v, d, m[a + 14], 17, 2792965006), v = t(v, d = n(d, S, l, v, m[a + 15], 22, 1236535329), S, l, m[a + 1], 5, 4129170786), l = t(l, v, d, S, m[a + 6], 9, 3225465664), S = t(S, l, v, d, m[a + 11], 14, 643717713), d = t(d, S, l, v, m[a + 0], 20, 3921069994), v = t(v, d, S, l, m[a + 5], 5, 3593408605), l = t(l, v, d, S, m[a + 10], 9, 38016083), S = t(S, l, v, d, m[a + 15], 14, 3634488961), d = t(d, S, l, v, m[a + 4], 20, 3889429448), v = t(v, d, S, l, m[a + 9], 5, 568446438), l = t(l, v, d, S, m[a + 14], 9, 3275163606), S = t(S, l, v, d, m[a + 3], 14, 4107603335), d = t(d, S, l, v, m[a + 8], 20, 1163531501), v = t(v, d, S, l, m[a + 13], 5, 2850285829), l = t(l, v, d, S, m[a + 2], 9, 4243563512), S = t(S, l, v, d, m[a + 7], 14, 1735328473), v = o(v, d = t(d, S, l, v, m[a + 12], 20, 2368359562), S, l, m[a + 5], 4, 4294588738), l = o(l, v, d, S, m[a + 8], 11, 2272392833), S = o(S, l, v, d, m[a + 11], 16, 1839030562), d = o(d, S, l, v, m[a + 14], 23, 4259657740), v = o(v, d, S, l, m[a + 1], 4, 2763975236), l = o(l, v, d, S, m[a + 4], 11, 1272893353), S = o(S, l, v, d, m[a + 7], 16, 4139469664), d = o(d, S, l, v, m[a + 10], 23, 3200236656), v = o(v, d, S, l, m[a + 13], 4, 681279174), l = o(l, v, d, S, m[a + 0], 11, 3936430074), S = o(S, l, v, d, m[a + 3], 16, 3572445317), d = o(d, S, l, v, m[a + 6], 23, 76029189), v = o(v, d, S, l, m[a + 9], 4, 3654602809), l = o(l, v, d, S, m[a + 12], 11, 3873151461), S = o(S, l, v, d, m[a + 15], 16, 530742520), v = e(v, d = o(d, S, l, v, m[a + 2], 23, 3299628645), S, l, m[a + 0], 6, 4096336452), l = e(l, v, d, S, m[a + 7], 10, 1126891415), S = e(S, l, v, d, m[a + 14], 15, 2878612391), d = e(d, S, l, v, m[a + 5], 21, 4237533241), v = e(v, d, S, l, m[a + 12], 6, 1700485571), l = e(l, v, d, S, m[a + 3], 10, 2399980690), S = e(S, l, v, d, m[a + 10], 15, 4293915773), d = e(d, S, l, v, m[a + 1], 21, 2240044497), v = e(v, d, S, l, m[a + 8], 6, 1873313359), l = e(l, v, d, S, m[a + 15], 10, 4264355552), S = e(S, l, v, d, m[a + 6], 15, 2734768916), d = e(d, S, l, v, m[a + 13], 21, 1309151649), v = e(v, d, S, l, m[a + 4], 6, 4149444226), l = e(l, v, d, S, m[a + 11], 10, 3174756917), S = e(S, l, v, d, m[a + 2], 15, 718787259), d = e(d, S, l, v, m[a + 9], 21, 3951481745), v = c(v, f), d = c(d, C), S = c(S, g), l = c(l, h);
	return (u(v) + u(d) + u(S) + u(l)).toLowerCase()
};

var RegistrationHash = function (h, p) {
	return MD5('Hash:' + h + ';Password:' + p + ';');
};
var GameLogin = '';
var GamePassword = '';
var Serv_iswork = false;
var newping = 0;
var get_errors = 0;
function Serv_Command(a /*string*/, f, iii, kkk) {
	if (GameLogin != '') {
		if (Serv_iswork == true) {
			if (a != "getpos")
				var timerId3546356 = setTimeout(function f567567() {
					Serv_Command(a, f, iii, kkk)
				}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/' + a + '.txt', true);
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				var xhr2 = new XHR2();
				xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				xhr2.onload = function () {
					if (xhr2.status == 200) {
						Serv_iswork = false;
						if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
							get_errors = 0;
							ping = (new Date) - newping;
							f(xhr2.responseText, iii, kkk);
						} else {
							get_errors++;
							if (get_errors > 10) {
								document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
								//alert('Неверный логин или пароль (связь с сервером потеряна)');
								//location.reload();
							}
							Serv_Command(a, f, iii, kkk);
						}
					} else
						xhr2.onerror();
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(1.2).');
					console.log('Сервер не ответил(1.2).');
				}
				xhr2.send();
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(1.1).');
			console.log('Сервер не ответил(1.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress) {
	if (leng == undefined) {
		leng = 'kumir';
	}
	if (progress == undefined) {
		progress = '';
	}

	if (GameLogin != '') {
		if (Serv_iswork == true) {
			var timerId3546356 = setTimeout(function f567567() {
				Serv_SendProgramm(Progr, Task, f)
			}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/upload;' + leng + ';' + Task + ';' + progress + ';.txt', true); // /upload;res;10%;A1;.txt
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				//xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Отправляем кодировку
				xhr2.onreadystatechange = function () {
					if (xhr2.readyState == 4) {
						if (xhr2.status == 200) {
							Serv_iswork = false;
							if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
								get_errors = 0;
								f(xhr2.responseText);
							} else {
								get_errors++;
								if (get_errors > 10) {
									document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
									//alert('Неверный логин или пароль (связь с сервером потеряна)');
									//location.reload();
								}
								Serv_SendProgramm(Progr, Task, f, leng, progress);
							}
						} else
							xhr2.onerror();
					}
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(2.2).');
					console.log('Сервер не ответил(2.2).');
				}
				xhr2.send(encodeURIComponent(Progr).replace(/%20/g, "+")); // Отправляем POST-запрос
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(2.1).');
			console.log('Сервер не ответил(2.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_LoadFile(url /*string*/, f, iii, kkk) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', url, true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			if (this.status == 200) {
				f(this.responseText, iii, kkk);
			}
		} else
			xhr.onerror();
	}

	xhr.onerror = function () {
		document.writeln('Сервер не ответил(3.1).');
		console.log('Сервер не ответил(3.1).');
	}
	xhr.send();
}

function Serv_login(Login, Password, func) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', 'commands/' + Login + '/login.txt', true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
			var xhr2 = new XHR();
			xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, Password) + '.txt', true);
			xhr2.onload = function () {
				if (xhr2.status == 200) {
					if (this.responseText == 'OK' || this.responseText == 'OKADMINOFADMIN' || this.responseText == 'OKADMIN') {}
					else {
						alert('Ошибка в логине или пароле');
						localStorage.clear();
						document.location.href = "/login.html";
					}
					GameLogin = Login;
					GamePassword = Password;
					if (this.responseText == 'OK')
						func(0);
					if (this.responseText == 'OKADMIN')
						func(1);
					if (this.responseText == 'OKADMINOFADMIN')
						func(2);
				} else
					xhr2.onerror();
			}
			xhr2.onerror = function () {
				alert('Ошибка в логине или пароле(!).');
				localStorage.clear();
				document.location.href = "/login.html";
			}
			xhr2.send();
		} else {
			xhr.onerror();
		}
	}

	xhr.onerror = function () {
		alert('Ошибка в логине(!) или пароле.');
		localStorage.clear();
		document.location.href = "/login.html";
	}
	xhr.send();
}
