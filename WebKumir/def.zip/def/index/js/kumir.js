//old school from dim0n4eg
var debug=false;

var kumir_helper = '';
var steps = []; //str0 // влево // вправо // вниз // вверх
var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
var xhr = new XHR();
xhr.open('GET', 'js/kumir_helper.js', true);
xhr.onload = function () {
	if (xhr.status == 200) {
		if (this.status == 200) {
			kumir_helper = (this.responseText);
		}
	} else
		xhr.onerror();
}
xhr.onerror = function () {
	if (debug)
		console.log('Сервер не ответил(5.1).');
}
xhr.send();

if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function (searchElement, fromIndex) {
		var k;
		if (this == null) {
			throw new TypeError('"this" is null or not defined');
		}
		var O = Object(this);
		var len = O.length >>> 0;
		if (len === 0) {
			return -1;
		}
		var n = +fromIndex || 0;
		if (Math.abs(n) === Infinity) {
			n = 0;
		}
		if (n >= len) {
			return -1;
		}
		k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
		while (k < len) {
			if (k in O && O[k] === searchElement) {
				return k;
			}
			k++;
		}
		return -1;
	};
}
String.prototype.trimLeft = String.prototype.trimLeft || function () {
	var start = -1;
	while (this.charCodeAt(++start) < 33);

	return this.slice(start, this.length);
};

function RanJsCode(s, map_text) {
	s = kumir_helper + s;
	var f = new Function('map_text', s);
	return f(map_text);
}

var ErrorKumir = []; //[step,'text',number of sring]
var TabInProgramm = {};
function formating(s, map) {
	RunKumir(s, map);
	if (!(TabInProgramm["work"] != undefined && TabInProgramm["work"] == true))
		return;
	var out_s = '';
	var noreturn = 0;
	for (var i = 0; i < s.split('\n').length; i++) {
		if (TabInProgramm[i] != undefined)
			out_s += '\t'.repeat(TabInProgramm[i]);
		else
		{
			out_s += '\t'.repeat();
			
			var line = s.split('\n')[i];
			var t = 0;
			var v = 0;
			while (t < line.length)
				if (line[t] == ' ') {
					t += 1;
					v += 1;
				} else
					if (line[t] == '\t') {
						t += 1;
						v += 2;
					} else
						break;
					
			out_s += ' '.repeat(v);
		}
		if (s.split('\n')[i].trimLeft() == '')
			noreturn++;
		else
			noreturn = 0;
		if (noreturn < 3)
			out_s += s.split('\n')[i].trimLeft() + '\n';
	}
	return out_s.trim();
}
function GetIn(a, b, c) {
	if (a.indexOf(b) == -1)
		return "";
	if (c == '')
		return a.substring(a.indexOf(b) + b.length, a.length);
	if (a.substring(a.indexOf(b) + b.length, a.length).indexOf(c) == -1)
		return "";
	return a.substring(a.indexOf(b) + b.length, a.substring(a.indexOf(b) + b.length, a.length).indexOf(c) + a.indexOf(b) + b.length);
}
var KOI8 = ["\0", "", "", "", "", "", "", "\a", "\b", "\t", "\n", "\v", "\f", "\r", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "S", "!", '"', "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ":", ";", "<", "=", ">", "?", "@", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "[", "\\", "]", "^", "_", "`", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~", "", "─", "│", "┌", "┐", "└", "┘", "├", "┤", "┬", "┴", "┼", "▀", "▄", "█", "▌", "▐", "░", "▒", "▓", "⌠", "■", "∙", "√", "≈", "≤", "≥", "N", "⌡", "°", "²", "·", "÷", "═", "║", "╒", "ё", "╓", "╔", "╕", "╖", "╗", "╘", "╙", "╚", "╛", "╜", "╝", "╞", "╟", "╠", "╡", "Ё", "╢", "╣", "╤", "╥", "╦", "╧", "╨", "╩", "╪", "╫", "╬", "©", "ю", "а", "б", "ц", "д", "е", "ф", "г", "х", "и", "й", "к", "л", "м", "н", "о", "п", "я", "р", "с", "т", "у", "ж", "в", "ь", "ы", "з", "ш", "э", "щ", "ч", "ъ", "Ю", "А", "Б", "Ц", "Д", "Е", "Ф", "Г", "Х", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Я", "Р", "С", "Т", "У", "Ж", "В", "Ь", "Ы", "З", "Ш", "Э", "Щ", "Ч"];

var ru = {
	a: 'Е61',
	b: 'Е62',
	c: 'Е63',
	d: 'Е64',
	e: 'Е65',
	f: 'Е66',
	g: 'Е67',
	h: 'Е68',
	i: 'Е69',
	j: 'Е6А',
	k: 'Е6Б',
	l: 'Е6С',
	m: 'Е6Д',
	n: 'Е6Е',
	o: 'Е6Ф',
	p: 'Е70',
	q: 'Е71',
	r: 'Е72',
	s: 'Е73',
	t: 'Е74',
	u: 'Е75',
	v: 'Е76',
	w: 'Е77',
	x: 'Е78',
	y: 'Е79',
	z: 'Е8А'
};

function LatinToRus(str) {
	var acc='';
	for (var i=0;i<str.length;i++)
	{
		var lowLetter = str[i].toLowerCase();
		var en;
		if (ru[lowLetter] == undefined)
		{
			en=str[i];
		}
		else
		{
			en=ru[lowLetter];
		}
		var enNormalized;
		if (lowLetter === str[i])
		{
			enNormalized=en;
		}else
		{
			enNormalized = en.toUpperCase();
		}
		 acc += enNormalized;
	}
	return acc;
}
var persing_log = "";
function NameToNameVal(str) {
	var str2 = str.trim().replace(new RegExp('  ', 'gi'), ' ');
	while (str2 != str2.replace(new RegExp('  ', 'gi'), ' '))
		str2 = str2.replace(new RegExp('  ', 'gi'), ' ');
	str2 = str2.replace(new RegExp(' ', 'gi'), '_');
	return str2;
}

function parseFormula(a, use_f, use_v) {
	//console.log(a);
	a = '((' + a + '))';
	var slu = ['не', 'или', 'и'];
	var slu2 = ['!', '||', '&&'];
	var simvols = [' ', '\\(', '\\)'];
	var simvols2 = [' ', '(', ')'];
	function KumReplace3(s) {
		var Result = s;
		for (var i = 0; i < simvols.length; i++)
			for (var j = 0; j < simvols.length; j++)
				for (var k = 0; k < slu.length; k++) {
					Result = Result.replace(new RegExp(simvols[i] + slu[k] + simvols[j], 'gi'), simvols2[i] + slu2[k] + simvols2[j]);
					//console.log([new RegExp(simvols[i] + slu[k] + simvols[j],'gi') , simvols2[i] + 'kumiralg_' + slu[k] + '_kumiralg' + simvols2[j]]);
				}
		return Result;
	}
	a = KumReplace3(' ' + a + ' ').trim();
	var token,
	outFormula,
	stack,
	operators;
	operators = ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>', '&&', '||'];
	ParseOperators = [['!'], ['!', '**'], ['!', '**', '*', '/'], ['!', '**', '*', '/'], ['!', '**', '*', '/', '+', '-'], ['!', '**', '*', '/', '+', '-'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>', '&&', '||'], ['!', '**', '*', '/', '+', '-', '<=', '>=', '<>', '=', '<', '>', '&&', '||']];
	outFormula = [];
	stack = [];
	function ItisName(s) {

		var dop = false,
		i = 0;
		s = s.trim();
		for (i = 0; i < s.length; i++) {
			dop = true;
			if ((s[i] >= 'а') && (s[i] <= 'я'))
				dop = false;
			if ((s[i] >= 'А') && (s[i] <= 'Я'))
				dop = false;
			if ((s[i] >= 'a') && (s[i] <= 'z'))
				dop = false;
			if ((s[i] >= 'A') && (s[i] <= 'Z'))
				dop = false;
			if ((i > 0) && (s[i] >= '0') && (s[i] <= '9'))
				dop = false;
			if (s[i] == ' ')
				dop = false;
			if (s[i] == '_')
				dop = false;
			if (dop == true)
				return false;
		}
		if (s.length == 0)
			return false;
		return true;
	}
	//operators.indexOf(token[0]) != -1
	function readtoken(b) {
		b = b.trim();
		if (b == '')
			return [-1, -1];
		if (b.length > 1 && operators.indexOf(b[0] + b[1]) != -1)
			return [b[0] + b[1], 'O'];
		if (operators.indexOf(b[0]) != -1)
			return [b[0], 'O'];
		if ([','].indexOf(b[0]) != -1)
			return [',', 'Z'];
		if (['('].indexOf(b[0]) != -1)
			return ['(', '('];
		if ([')'].indexOf(b[0]) != -1)
			return [')', ')'];
		if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'].indexOf(b[0]) != -1) {
			var out = '';
			var i = 0;
			while (i < b.length && ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'].indexOf(b[i]) != -1) {
				out += b[i];
				i++;
			}
			return [out, 'N'];
		}
		var i = 1;
		while (i <= b.length && ItisName(b.substring(0, i)))
			i++;
		if (b.substring(0, i - 1).trim() == "")
			return [-1, -1];
		if (b.substring(i - 1, b.length - 1).trim()[0] == '(')
			return [b.substring(0, i - 1).trim(), 'F'];
		return [b.substring(0, i - 1).trim(), 'V'];
	}
	var iii = 0;
	persing_log = "";
	while (a.length > 0) {
		iii++;
		if (iii > 1000) {
			persing_log += 'Превышено время анализа данного выражения.\r\n'
			persing_log += 'Анализ завершён на "' + a + '". \r\n';
			return;
		}
		if (token != undefined && token[1] == '(' && readtoken(a)[1] == ')') {
			persing_log += 'Выражение либо пустое, либо после "(" идёт ")".\r\n'
			persing_log += 'Анализ завершён на "' + a + '". \r\n';
			return;
		}
		token = readtoken(a);

		if (token[0] == -1) {
			persing_log += 'Не удалось прочитать токен\r\n'
			persing_log += 'Анализ завершён на "' + a + '". \r\n';
			return;
		}
		a = a.substring(a.indexOf(token[0]) + token[0].length, a.length);
		if (token[1] == 'V') //value
		{
			if ((use_f == undefined) || (use_v == undefined))
				outFormula.push(NameToNameVal(token[0]));
			else {
				var trans_v = NameToNameVal(token[0]);
				if (use_v.indexOf(trans_v) != -1) {
					outFormula.push(trans_v);
				} else
					if (use_f.indexOf(trans_v) != -1) {
						stack.push([NameToNameVal(trans_v) + '(', 'F']);
					} else {
						persing_log += 'Данное(' + trans_v + ') имя не обявленно \r\n'
						persing_log += 'Анализ завершён на "' + a + '". \r\n';
						return;
					}
			}
		} else
			if (token[1] == 'N') //number
			{
				outFormula.push(token[0]);
			} else
				if (token[1] == 'F') //function
				{
					stack.push([NameToNameVal(token[0]) + '$', token[1]]);
				} else
					if (token[1] == 'Z') //,
					{
						while (stack[stack.length - 1][1] != '(') {
							outFormula.push(stack.pop()[0]);
							if (stack.length == 0) {
								persing_log += 'В выражении пропущена запятая или(и) открывающая скобка.\r\n'
								persing_log += 'Анализ завершён на "' + a + '". \r\n';
								return;
							}
						}
						if (stack.length > 1 && stack[stack.length - 2][1] == 'F')
							stack[stack.length - 2][0] += '$'; //для последующего использования || кол во аргументов
					} else
						if (token[1] == 'O') //operators 'и','или','<=','>=','<>','**','*','/','+','-']
						{
							while (stack.length > 0 && ((stack[stack.length - 1][1] == 'O' && ParseOperators[operators.indexOf(token[0])].indexOf(stack[stack.length - 1][0]) != -1)||(stack[stack.length - 1][1] == 'F'))) {
								outFormula.push(stack.pop()[0]);
								if (stack.length == 0) {
									break;
								}
							}
							stack.push(token);
						} else
							if (token[1] == '(') //(
							{
								stack.push(token);
							} else
								if (token[1] == ')') //)
								{
									if (stack.length == 0) {
										persing_log += 'В выражении пропущена открывающая скобка.\r\n'
										persing_log += 'Анализ завершён на "' + a + '". \r\n';
										return;
									}
									while (stack[stack.length - 1][1] != '(') {
										outFormula.push(stack.pop()[0]);
										if (stack.length == 0) {
											persing_log += 'В выражении пропущена запятая или(и) открывающая скобка.\r\n'
											persing_log += 'Анализ завершён на "' + a + '". \r\n';
											return;
										}
									}
									stack.pop();
									if (stack.length > 0 && stack[stack.length - 1][1] == 'F')
										outFormula.push(stack.pop()[0] + '(');
								}

	}
	while ((stack.length != 0)) {
		outFormula.push(stack.pop()[0]);
	}
	//перевод в функциональную запись
	stack = [];
	for (var i = 0; i < outFormula.length; i++) {
		if (!isNaN(parseFloat(outFormula[i]))) {
			stack.push(outFormula[i]);
		} else
			if (outFormula[i] == '!') {
				if (stack.length < 1) {
					persing_log += 'Неправельное использование оператора "не". \r\n'
					return;
				}
				var v1 = stack.pop();
				stack.push('Not(' + v1 + ')');
			} else
				if (outFormula[i] == '**') {
					if (stack.length < 2) {
						persing_log += 'Неправельное использование оператора "**". \r\n'
						return;
					}
					var v1 = stack.pop();
					var v2 = stack.pop();
					stack.push('Power(' + v2 + ',' + v1 + ')');
				} else
					if (outFormula[i] == '*') {
						if (stack.length < 2) {
							persing_log += 'Неправельное использование оператора "*". \r\n'
							return;
						}
						var v1 = stack.pop();
						var v2 = stack.pop();
						stack.push('Mul(' + v2 + ',' + v1 + ')');
					} else
						if (outFormula[i] == '/') {
							if (stack.length < 2) {
								persing_log += 'Неправельное использование оператора "/". \r\n'
								return;
							}
							var v1 = stack.pop();
							var v2 = stack.pop();
							stack.push('Del(' + v2 + ',' + v1 + ')');
						} else
							if (outFormula[i] == '+') {
								if (stack.length < 2) {
									persing_log += 'Неправельное использование оператора "+". \r\n'
									return;
								}
								var v1 = stack.pop();
								var v2 = stack.pop();
								stack.push('Sum(' + v2 + ',' + v1 + ')');
							} else
								if (outFormula[i] == '-') {
									if (stack.length < 2) {
										persing_log += 'Неправельное использование оператора "-". \r\n'
										return;
									}
									var v1 = stack.pop();
									var v2 = stack.pop();
									stack.push('Min(' + v2 + ',' + v1 + ')');
								} else
									if (['<=', '>=', '<>', '=', '<', '>', '&&', '||'].indexOf(outFormula[i]) != -1) {
										if (stack.length < 2) {
											persing_log += 'Неправельное использование оператора "' + outFormula[i] + '". \r\n'
											return;
										}
										var v1 = stack.pop();
										var v2 = stack.pop();
										stack.push('Srav("' + outFormula[i] + '",' + v2 + ',' + v1 + ')');
									} else
										if (ItisName(outFormula[i])) {
											stack.push('v_' + outFormula[i].trim().replace(new RegExp(" ", 'gi'), "_"));
										} else
											if (outFormula[i].indexOf('(') == outFormula[i].length - 1) {
												if (stack.length < outFormula[i].split('$').length - 1) {
													persing_log += 'Очень странная ошибка... kek \r\n'
													return;
												}
												var s = "";
												for (var k = outFormula[i].split('$').length - 1; k > 1; k--)
													s += stack[stack.length - k] + ',';
												if (outFormula[i].split('$').length - 1 > 0)
													s += stack[stack.length - 1];
												for (var k = outFormula[i].split('$').length - 1; k > 0; k--)
													stack.pop();
												stack.push('f_' + outFormula[i].split('(')[0].split('$')[0] + '(' + s + ")");
											} else {
												persing_log += 'Неизвестная команда "' + outFormula[i] + '". \r\n'
												return;
											}
		//return [b[0], 'O'];)
	}
	if (stack.length != 1) {
		persing_log += 'Что то не то в данной формуле.\r\nCтек:\r\n' + stack.join();
		return;
	}
	//console.log(stack[0]);
	return stack[0];
}

function RunKumir(s, map) {
	s=s.replace(new RegExp('ё', 'gi'), 'е');
	var damp_program = s;
	var start = new Date;
	TabInProgramm = {};
	var k_split = [];
	var k_split2 = [];
	steps = [];
	ErrorKumir = [];
	//step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1
	for (var i = 0; i < s.split('\n').length; i++) {
		if (s.split('\n')[i].trim().split('|')[0] != '') {
			k_split.push([i, s.split('\n')[i].trim().split('|')[0]]);
		}
	}
	if (k_split.length == 0) {
		ErrorKumir.push([1, 'Программа пуста', 0]);
		return;
	}
	if (k_split[0][1].toLowerCase() != 'использовать робот' && k_split[0][1].toLowerCase() != 'использовать робот;') {
		ErrorKumir.push([1, 'Не найден "использовать Робот"', k_split[0][0]]);
		return;
	}
	//step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1 step 1
	//step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2
	//---------string coding
	//, 

	var names = [["вправо", "вниз", "влево", "вверх", "закрасить"], ["цел в лит", "вещ в лит", "лит в цел", "лит в вещ", "sqrt", "abs", "sin", "cos", "tg", "ctg", "arcsin", "arccos", "arctg", "arcctg", "ln", "lg", "exp", "min", "max", "mod", "div", "int", "rnd", "длин", "код", "символ", "юникод", "символ2",'слева_свободно', 'справа_свободно', 'сверху_свободно', 'снизу_свободно', 'слева_стена', 'справа_стена', 'сверху_стена', 'снизу_стена', 'клетка_закрашена', 'клетка_чистая','температура','радиация'], ["МЦЕЛ", "МВЕЩ", "да", "нет", "нс"]];
	k_split.shift();
	var string_split = [];
	var num = 1;
	for (var k = 0; k < k_split.length; k++) {
		var fl = 0;
		var kodingstr = '';
		var s = '';
		var s2 = '';
		for (var i = 0; i < k_split[k][1].length; i++) {
			if (k_split[k][1][i] != '"' && fl == 1)
				s2 += k_split[k][1][i];
			if (k_split[k][1][i] != "'" && fl == 2)
				s2 += k_split[k][1][i];
			if (k_split[k][1][i] == '"' && fl == 0) {
				kodingstr = 'КОД_СТРОКА_НУМ_' + (num++) + '_НУМ_';
				s2 = '';
				s += kodingstr;
				fl = 1;
			} else
				if (k_split[k][1][i] == "'" && fl == 0) {
					kodingstr = 'КОД_СТРОКА_НУМ_' + (num++) + '_НУМ_';
					s2 = '';
					s += kodingstr;
					fl = 2;
				} else
					if ((k_split[k][1][i] == '"' && fl == 1) || (k_split[k][1][i] == "'" && fl == 2)) {
						fl = 0;
						string_split.push([kodingstr, s2]);
						names[2].push(kodingstr);
					} else
						if (fl == 0)
							s += k_split[k][1][i];
		}
		k_split[k][1] = s;
		if (fl == 1) {
			ErrorKumir.push([2, 'Не найден закрывающий символ строки(")', k_split[k][0]]);
			return;
		}
		if (fl == 2) {
			ErrorKumir.push([2, "Не найден закрывающий символ строки(')", k_split[k][0]]);
			return;
		}
	}
	k_split.unshift([0, 'использовать Робот']);
	//---------string coding
	//---------LatinToRus
	for (var k = 0; k < k_split.length; k++)
		if (LatinToRus(k_split[k][1]) != k_split[k][1]) {
			//ErrorKumir.push([100, 'Не следует использовать английский язык', k_split[k][0]]);
			k_split[k][1] = LatinToRus(k_split[k][1]);
		}
	//---------LatinToRus
	//step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2 step 2
	//step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3
	var k_split_algo = []; //[[kommand befo alg] [procedure or function,"name",[parametr1,.....],дано,надо, ........] , [""] ]
	//k_split_algo.push([k_split[0][1], ]);
	//---------replase all
//, 'getmap(1,1)', 'getmap(1,2)', 'getmap(1,3)', 'getmap(1,4)', 'getmap(2,1)', 'getmap(2,2)', 'getmap(2,3)', 'getmap(2,4)', 'getmap(3,1)', 'getmap(3,2)', 'getmap(4,1)', 'getmap(4,2)'
	var slu = ['алг', 'нач', 'кон', 'дано', 'надо', 'цел таб', 'вещ таб', 'лог таб', 'сим таб', 'лит таб', 'то', 'иначе', 'при', 'все', 'арг рез'];
	var slu2 = ['kumiralg_алг_kumiralg', '\r\nkumiralg_нач_kumiralg\r\n', '\r\nkumiralg_кон_kumiralg\r\n', '\r\nkumiralg_дано_kumiralg', '\r\nkumiralg_надо_kumiralg', 'целтаб', 'вещтаб', 'логтаб', 'симтаб', 'литтаб', '\r\n', '\r\nиначе\r\n', '\r\nпри', '\r\nвсе\r\n', 'аргрез'];
	var simvols = [',', ' ', '\\(', '\\)'];
	var simvols2 = [',', ' ', '(', ')'];
	function KumReplace2(s) {
		var Result = s;
		for (var i = 0; i < simvols.length; i++)
			for (var j = 0; j < simvols.length; j++)
				for (var k = 0; k < slu.length; k++) {
					Result = Result.replace(new RegExp(simvols[i] + slu[k] + simvols[j], 'gi'), simvols2[i] + slu2[k] + simvols2[j]);
					//console.log([new RegExp(simvols[i] + slu[k] + simvols[j],'gi') , simvols2[i] + 'kumiralg_' + slu[k] + '_kumiralg' + simvols2[j]]);
				}
		Result = Result.replace(new RegExp(";", 'gi'), "\r\n");
		return Result;
	}
	k_split2 = [];
	for (var i = 0; i < k_split.length; i++) {
		k_split[i][1] = KumReplace2(' ' + k_split[i][1] + ' ').trim();
		for (var j = 0; j < k_split[i][1].split('\n').length; j++)
			if (k_split[i][1].split('\n')[j].trim() != '') {
				k_split2.push([k_split[i][0], k_split[i][1].split('\n')[j].trim()]);
			}
	}
	k_split = [];
	for (var i = 0; i < k_split2.length; i++) {
		k_split.push(k_split2[i]);
	}
	var algo_flag_num = 0;

	// ->'использовать Робот'
	// ->вступление===команды вне
	// ->алгоритм
	// ->->функция===алг->Тип величины->!имя!->
	// ->->процедура===алг->имя*->
	function kumir_isType(s_in) {
		var s = s_in.trim();
		if (s == 'цел')
			return true;
		if (s == 'вещ')
			return true;
		if (s == 'лог')
			return true;
		if (s == 'сим')
			return true;
		if (s == 'лит')
			return true;

		if (s == 'целтаб')
			return true;
		if (s == 'вещтаб')
			return true;
		if (s == 'логтаб')
			return true;
		if (s == 'симтаб')
			return true;
		if (s == 'литтаб')
			return true;
		return false;
	}
	function ItisName(s) {
		var dop = false,
		i = 0;
		s = s.trim();
		for (i = 0; i < s.length; i++) {
			dop = true;
			if ((s[i] >= 'а') && (s[i] <= 'я'))
				dop = false;
			if ((s[i] >= 'А') && (s[i] <= 'Я'))
				dop = false;
			if ((s[i] >= 'a') && (s[i] <= 'z'))
				dop = false;
			if ((s[i] >= 'A') && (s[i] <= 'Z'))
				dop = false;
			if ((i > 0) && (s[i] >= '0') && (s[i] <= '9'))
				dop = false;
			if (s[i] == ' ')
				dop = false;
			if (s[i] == '_')
				dop = false;
			if (dop == true)
				return false;
		}
		if (s.length == 0)
			return false;
		return true;
	}

	function kumir_proceduraorprocedura(ind, k) {
		var alg_s = k[ind][1].trim().replace(/ {1,}/g, " ").split(' ');
		var result = [];

		function ParseArgumets(s) {
			if (s.trim()=='')
				return [];
			
			return s.split(',');
		}
		if ((alg_s.length > 1) && kumir_isType(alg_s[1])) {
			result.push('function');
			if (algo_flag_num == 1) {
				ErrorKumir.push([3, 'Основным алгоритмом не может являться алгоритм-функция', k[ind][0]]);
				return;
			}
			if (k[ind][1].trim().indexOf('(') == -1) {
				if (k[ind][1].trim().substring(k[ind][1].trim().indexOf(alg_s[1]) + alg_s[1].length, k[ind][1].trim().length - 1).length < 1) {
					ErrorKumir.push([3, 'Мне кажеться у название алгоритма-функции должно быть название', k[ind][0]]);
					return;
				} else
					if (!ItisName(k[ind][1].trim().substring(k[ind][1].trim().indexOf(alg_s[1]) + alg_s[1].length, k[ind][1].trim().length))) {
						ErrorKumir.push([3, 'Какое-то ненормальное название алгоритма-функции', k[ind][0]]);
						return;
					} else {
						result.push(alg_s[1] + ' ' + k[ind][1].trim().substring(k[ind][1].trim().indexOf(alg_s[1]) + alg_s[1].length, k[ind][1].trim().length).trim());
						result.push([]);
					}
			} else {
				if (GetIn(k[ind][1].trim(), alg_s[1], '(').trim() == "") {
					ErrorKumir.push([3, 'Мне кажеться у название алгоритма-функции должно быть название', k[ind][0]]);
					return;
				} else
					if (!ItisName(GetIn(k[ind][1].trim(), alg_s[1], '(').trim())) {
						ErrorKumir.push([3, 'Какое-то ненормальное название алгоритма-функции', k[ind][0]]);
						return;
					} else {
						result.push(alg_s[1] + ' ' + GetIn(k[ind][1].trim(), alg_s[1], '(').trim());
						result.push(ParseArgumets(GetIn(k[ind][1], GetIn(k[ind][1].trim(), alg_s[1], '(') + '(', ')')));
					}
			}
		} else {
			result.push('procedure');
			if (algo_flag_num == 1) {
				if (k[ind][1].trim().indexOf('(') != -1) {
					ErrorKumir.push([3, 'У основного алгоритма не должно быть паратметров (неожиданый символ "(")', k[ind][0]]);
					return;
				}
				if (k[ind][1].trim().indexOf(')') != -1) {
					ErrorKumir.push([3, 'У основного алгоритма не должно быть паратметров (неожиданый символ ")")', k[ind][0]]);
					return;
				}
				result.push('main');
				result.push([]);
			} else
				if (k[ind][1].trim().indexOf('(') == -1) {
					if (k[ind][1].trim().substring(k[ind][1].trim().indexOf("kumiralg_алг_kumiralg") + ("kumiralg_алг_kumiralg").length + 1, k[ind][1].trim().length).length < 1) {
						ErrorKumir.push([3, 'Мне кажеться у алгоритма-процедуры должно быть название', k[ind][0]]);
						return;
					} else
						if (!ItisName(k[ind][1].trim().substring(k[ind][1].trim().indexOf("kumiralg_алг_kumiralg") + ("kumiralg_алг_kumiralg").length + 1, k[ind][1].trim().length))) {
							ErrorKumir.push([3, 'Какое-то ненормальное название алгоритма-процедуры', k[ind][0]]);
							return;
						} else {
							result.push(k[ind][1].trim().substring(k[ind][1].trim().indexOf("kumiralg_алг_kumiralg") + ("kumiralg_алг_kumiralg").length + 1, k[ind][1].trim().length));
							result.push([]);
						}
				} else {
					if (k[ind][1].trim().indexOf(')') == -1) {
						ErrorKumir.push([3, 'Не найдена закрывающейся скобка', k[ind][0]]);
						return;
					}
					if (GetIn(k[ind][1].trim(), ("kumiralg_алг_kumiralg"), '(').trim() == "") {
						ErrorKumir.push([3, 'Мне кажеться у алгоритма-процедуры должно быть название', k[ind][0]]);
						return;
					} else
						if (!ItisName(GetIn(k[ind][1].trim(), ("kumiralg_алг_kumiralg"), '(').trim())) {
							ErrorKumir.push([3, 'Какое-то ненормальное название алгоритма-процедуры', k[ind][0]]);
							return;
						} else {
							result.push(GetIn(k[ind][1].trim(), ("kumiralg_алг_kumiralg"), '(').trim());
							result.push(ParseArgumets(GetIn(k[ind][1].trim(), GetIn(k[ind][1].trim(), ("kumiralg_алг_kumiralg"), '(') + '(', ')')));
						}
				}
		}
		//[[kommand befo alg] [procedure or function,"name",[parametr1,.....],дано,надо, [........]] , [""] ]
		var _ind = ind + 1;
		if (_ind >= k.length) {
			ErrorKumir.push([3, 'Не найдено начало алгоритма', k[ind][0]]);
			return;
		}
		result.push('');
		result.push('');
		while (_ind < k.length && k[_ind][1].split(' ')[0] != 'kumiralg_нач_kumiralg') {
			if (k[_ind][1].split(' ')[0] == "kumiralg_дано_kumiralg") {
				result[3] = (k[_ind][1].substring(k[_ind][1].indexOf("kumiralg_дано_kumiralg") + ("kumiralg_дано_kumiralg").length + 1, k[_ind][1].length));
			} else
				if (k[_ind][1].split(' ')[0] == "kumiralg_надо_kumiralg") {
					result[4] = (k[_ind][1].substring(k[_ind][1].indexOf("kumiralg_надо_kumiralg") + ("kumiralg_надо_kumiralg").length + 1, k[_ind][1].length));
				} else {
					ErrorKumir.push([3, 'Какая-то неизвестная команда до начала алгоритма (мусор)', k[_ind][0]]);
					return;
				}
			_ind++;
		}
		if (_ind >= k.length) {
			ErrorKumir.push([3, 'Не найдено начало алгоритма', k[ind][0]]);
			return;
		}
		_ind++;
		var _arr = [];
		while (_ind < k.length && k[_ind][1].split(' ')[0] != 'kumiralg_кон_kumiralg') {
			_arr.push(k[_ind]);
			_ind++;
		}
		if (_ind >= k.length) {
			ErrorKumir.push([3, 'Не найден конец алгоритма', k[ind][0]]);
			return;
		}
		result.push(_arr);
		result.push(ind);
		if (result[0] == 'function') {
			result.push(result[1].split(' ')[0]);
			result[1] = GetIn(result[1], " ", "");
		}
		return result;
	}
	for (var i = 0; i < k_split.length; i++) {
		if (k_split[i][1].indexOf("kumiralg_алг_kumiralg") != -1) {
			if (algo_flag_num == 0) {
				var copyofk = [];
				for (var j = 1; j < i; j++) {
					copyofk.push(k_split[j]);
				}
				k_split_algo.push(copyofk);
				algo_flag_num++;
			}
			k_split_algo.push(kumir_proceduraorprocedura(i, k_split));
			if (k_split_algo[k_split_algo.length - 1] == undefined)
				return;
			algo_flag_num++;
		}
	}
	//Запоминаем все названия для последующей проверки
	for (var i = 1; i < k_split_algo.length; i++) {
		if (k_split_algo[i][0] == "procedure")
			names[0].push(parseFormula(LatinToRus(k_split_algo[i][1])).slice(2).trim());
		else
			if (k_split_algo[i][0] == "function")
				names[1].push(parseFormula(LatinToRus(k_split_algo[i][1])).slice(2).trim());
			else {
				ErrorKumir.push([4, 'Случился бред)))', 0]);
				return;
			}
	}
	//Запоминаем все названия для последующей проверки
	//step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3 step 3
	/*
	все
	кц
	кц_при

	нач
	выбор
	раз

	то
	иначе
	при

	имя:= выражение                                     ["_val",имя,[выражение]]

	вывод выражение - 1,                                ["_out",[[выражение - 1],....,[выражение - N]]]
	...,
	выражение - N

	ввод имя - 1,                                       ["_inp",[[выражение - 1],....,[выражение - N]]]
	...,
	имя - N

	имя_алгоритма - процедуры                           ["__pr","имя_алгоритма - процедуры",[]]

	имя_алгоритма - процедуры(список_параметров_вызова) ["__pr","имя_алгоритма - процедуры",[список_параметров_вызова]]

	выход                                               ["_bre"]

	если условие                                        ["__if",[условие]]
	то серия1                                           серия1
	иначе серия2                                        ["_els"]
	все                                                 ["_end"]

	если условие                                        ["__if",[условие]]
	то серия1                                           серия1
	все                                                 ["_els"]["_end"]

	выбор
	при условие 1: серия 1                              ["__if",[условие 1]]серия 1["_els"]
	при условие 2: серия 2                              ["__if",[условие 2]]серия 2["_els"]
	...
	при условие n: серия n                              ["__if",[условие n]]серия n["_els"]
	иначе серия n + 1                                   серия n + 1
	все                                                 ["_end"]*кол во при

	выбор
	при условие_1: серия_1                              ["__if",[условие 1]]серия 1["_els"]
	при условие_2: серия_2                              ["__if",[условие 2]]серия 2["_els"]
	...
	при условие_n: серия_n                              ["__if",[условие n]]серия n["_els"]
	все                                                 ["_end"]*кол во при


	нц
	|
	|-->для
	|   |
	|   |-->i от i1 до i2
	|   |
	|   |-->i от i1 до i2 шаг i3
	|
	|-->пока условие
	|
	|-->формула раз
	|
	|-->тело_цикла


	i-переменная
	i1, i2, i3 - формула

	нц для i от i1 до i2 ----------------------- for (i=i1;i<=i2;i+=1)                                               ["_for","i",[i1],[i2],[1]]
	тело_цикла                                                                                                       [тело_цикла]
	кц или кц_при условие ---------------------- if (условие){break}                                                 ["_end"]

	нц для i от i1 до i2 шаг i3 ---------------- for (i=i1;i<=i2;i+=i3)                                              ["_for","i",[i1],[i2],[i3],[тело_цикла],[false] или [условие]]
	тело_цикла
	кц или кц_при условие ---------------------- if (false){break} или if (условие){break}                           ["_end"]

	нц пока условие ---------------------------- while (условие)                                                     ["_whi",[условие],[тело_цикла],[false] или [условие]]
	тело_цикла
	кц или кц_при условие ---------------------- if (условие){break}

	нц формула раз ----------------------------- var raz=формула; for (var n(Math.randon(10000))=1;i<=raz;i+=1)      ["_for",[формула],[тело_цикла],[false] или [условие]]
	тело_цикла
	кц или кц_при условие ---------------------- if (условие){break}

	нц ---------------------------------------- while (true) {                                                       ["_whi",[true],[тело_цикла],[false] или [условие]]
	тело_цикла
	кц или кц_при условие ---------------------- if (условие){break}
	 */
	//step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4 step 4
	function ItisType(s) {
		s = s.trim();
		if (s == 'цел')
			return true;
		if (s == 'вещ')
			return true;
		if (s == 'лог')
			return true;
		if (s == 'сим')
			return true;
		if (s == 'лит')
			return true;

		if (s == 'целтаб')
			return true;
		if (s == 'вещтаб')
			return true;
		if (s == 'логтаб')
			return true;
		if (s == 'симтаб')
			return true;
		if (s == 'литтаб')
			return true;
		return false;
	}
	var exe_str = 0;
	var exe_stack_length = 0;
	var nc_v = 0;
	for (var i = 0; i < k_split_algo.length; i++) {
		var my_stack = [];
		var my_exe = [];
		if (i == 0) {
			while (k_split_algo[i].length > 0) {
				k_split_algo[i][0][1] = k_split_algo[i][0][1].trim() + '        ';
				exe_str = k_split_algo[i][0][1];
				my_exe.push(["_str", k_split_algo[i][0][0]]);
				if (ItisType(k_split_algo[i][0][1].split(" ")[0])) {
					var my_type = "";
					for (var k = 0; k < k_split_algo[i][0][1].split(",").length; k++) {
						if (ItisType(k_split_algo[i][0][1].split(",")[k].split(" ")[0])) {
							my_type = k_split_algo[i][0][1].split(",")[k].split(" ")[0];
							if (!ItisName(GetIn(k_split_algo[i][0][1].split(",")[k].trim(), ' ', ''))) {
								ErrorKumir.push([4, GetIn(k_split_algo[i][0][1].split(",")[k], ' ', '').trim() + ' не имя! ', k_split_algo[i][0][1]]);
								return;
							}
							names[2].push(GetIn(k_split_algo[i][0][1].split(",")[k].trim(), ' ', ''));
							my_exe.push(["_var", my_type, GetIn(k_split_algo[i][0][1].split(",")[k].trim(), ' ', '')]);
						} else {
							if (!ItisName(k_split_algo[i][0][1].split(",")[k])) {
								ErrorKumir.push([4, k_split_algo[i][0][1].split(",")[k].trim() + ' не имя! ', k_split_algo[i][0][1]]);
								return;
							}
							names[2].push(k_split_algo[i][0][1].split(",")[k].trim());
							my_exe.push(["_var", my_type, k_split_algo[i][0][1].split(",")[k].trim()]);
						}
					}
					k_split_algo[i].shift();
				} else
					if (GetIn(" " + k_split_algo[i][0][1], " ", ":=") != "" && ItisName(GetIn(" " + k_split_algo[i][0][1], " ", ":="))) //имя:=выражение
					{
						if (parseFormula('(' + GetIn(k_split_algo[i][0][1], ":=", "") + ')', names[1], names[2]) == undefined) {
							ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][0][1]]);
							return;
						}
						my_exe.push(["_val", GetIn(" " + k_split_algo[i][0][1], " ", ":=").trim(), parseFormula('(' + GetIn(k_split_algo[i][0][1], ":=", "") + ')', names[1], names[2])]);
						k_split_algo[i].shift();
					} else {
						ErrorKumir.push([4, 'Неизвестная команда', k_split_algo[i][0][1]]);
						return;
					}
			}
			if (my_stack.length == 0)
				k_split_algo[i] = my_exe;
			else {
				ErrorKumir.push([4, 'В начале ошибка. Какие-то из условных инструкций не закрыты.\r\nСтек команд:\r\n' + my_stack.join(), 0]);
				return;
			}
			continue;
		}

		var iiii = 0;
		while (iiii < names[2].length) {
			if (names[2][iiii] == "знач") {
				names[2].splice(iiii, 1);
			} else {
				iiii++;
			}
		}
		var ex = ParsArguments2(k_split_algo[i][2]);
		for (var j = 0; j < ex[3].length; j++) {
			names[2].push(ex[3][j]);

		}
		if (k_split_algo[i][0] == 'function')
			names[2].push("знач");
		while (k_split_algo[i][5].length > 0) {
			k_split_algo[i][5][0][1] = k_split_algo[i][5][0][1].trim() + '        ';
			exe_str = k_split_algo[i][5][0][0];
			exe_stack_length = my_stack.length + 1;
			my_exe.push(["_str", k_split_algo[i][5][0][0]]);
			if (k_split_algo[i][5][0][1] == "") {}
			else
				if (k_split_algo[i][5][0][1].indexOf("нц ") == 0 || k_split_algo[i][5][0][1].indexOf("нц(") == 0) {
					var end = '';
					if (k_split_algo[i][5][0][1].indexOf("нц для ") == 0) { //нц для с несколькими пробелами не работает
						if (GetIn(k_split_algo[i][5][0][1], "нц для", "от").trim() == '') {
							ErrorKumir.push([4, 'Мне кажеться между "нц для" и "от" должно быть имя', k_split_algo[i][5][0][0]]);
							return;
						}
						if (!ItisName(GetIn(k_split_algo[i][5][0][1], "нц для", "от").trim())) {
							ErrorKumir.push([4, 'Это не имя... (между "нц для" и "от")', k_split_algo[i][5][0][0]]);
							return;
						}
						if (parseFormula('(' + GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", "до").trim() + ')', names[1], names[2]) == undefined) {
							ErrorKumir.push([4, 'Неверная формула(между "от" и "до").\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
							return;
						}
						if (GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", "").indexOf("шаг") == -1) {
							if (parseFormula('(' + GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", "").trim() + ')', names[1], names[2]) == undefined) {
								ErrorKumir.push([4, 'Неверная формула(после "до").\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
								return;
							}
							my_exe.push(["_for", GetIn(k_split_algo[i][5][0][1], "нц для", "от").trim(), parseFormula('(' + GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", "до").trim() + ')', names[1], names[2]), parseFormula('(' + GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", "").trim() + ')', names[1], names[2]), parseFormula('(1)', names[1], names[2])]);
						} else {
							if (parseFormula('(' + GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", "шаг").trim() + ')', names[1], names[2]) == undefined) {
								ErrorKumir.push([4, 'Неверная формула(между "до" и "шаг").\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
								return;
							}
							if (parseFormula('(' + GetIn(GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", ""), "шаг", "").trim() + ')', names[1], names[2]) == undefined) {
								ErrorKumir.push([4, 'Неверная формула(после "шаг").\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
								return;
							}
							my_exe.push(["_for", GetIn(k_split_algo[i][5][0][1], "нц для", "от").trim(), parseFormula('(' + GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", "до").trim() + ')', names[1], names[2]), parseFormula('(' + GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", "шаг").trim() + ')', names[1], names[2]), parseFormula('(' + GetIn(GetIn(GetIn(GetIn(k_split_algo[i][5][0][1], "нц для", ""), "от", ""), "до", ""), "шаг", "").trim() + ')', names[1], names[2])]);
						}
					} else
						if (k_split_algo[i][5][0][1].indexOf("нц пока(") == 0 || k_split_algo[i][5][0][1].indexOf("нц пока ") == 0) {
							if (parseFormula('(' + GetIn(k_split_algo[i][5][0][1], "нц пока", "") + ')', names[1], names[2]) == undefined) {
								ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
								return;
							}
							my_exe.push(["_whi", parseFormula('(' + GetIn(k_split_algo[i][5][0][1], "нц пока", "") + ')', names[1], names[2])]);
						} else
							if ((k_split_algo[i][5][0][1].indexOf(")раз") != -1 || k_split_algo[i][5][0][1].indexOf(" раз") != -1) && (parseFormula('(' + GetIn(k_split_algo[i][5][0][1], "нц", "раз") + ')', names[1], names[2]) != undefined)) {
								//nc_v++;
								//var rendom_name = 'v_r_' + Math.floor(Math.random() * 100000) + '_' + nc_v + '_r_';
								//my_exe.push(["_var", "цел", rendom_name]);
								my_exe.push(["_for", undefined, 1, parseFormula('((' + GetIn(k_split_algo[i][5][0][1], "нц", "раз") + '))', names[1], names[2]), 1]);
								end = GetIn(k_split_algo[i][5][0][1], "раз", "");
							} else {
								my_exe.push(["_whi", parseFormula('(да)', names[1], names[2])]);
								end = GetIn(k_split_algo[i][5][0][1], "нц", "");
							}
					my_stack.push("нц");
					if (end.trim() != '') {
						k_split_algo[i][5][0][1] = end.trim();
					} else
						k_split_algo[i][5].shift();
				} else
					if (k_split_algo[i][5][0][1].indexOf("кц ") == 0) {
						if (my_stack.length == 0) {
							ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
							return;
						}
						if (!(my_stack[my_stack.length - 1] == "нц")) {
							ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
							return;
						}
						my_exe.push(["_end"]);
						my_stack.pop();
						k_split_algo[i][5][0][1] = GetIn(k_split_algo[i][5][0][1], 'кц', '').trim();
						if (k_split_algo[i][5][0][1] == "")
							k_split_algo[i][5].shift();
					} else
						if (k_split_algo[i][5][0][1].indexOf("кц_при ") == 0) {
							if (my_stack.length == 0) {
								ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
								return;
							}
							if (!(my_stack[my_stack.length - 1] == "нц")) {
								ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
								return;
							}
							if (parseFormula('(' + GetIn(k_split_algo[i][5][0][1], "кц_при", "") + ')', names[1], names[2]) == undefined) {
								ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
								return;
							}
							my_exe.push(["__if", '(' + parseFormula(GetIn(k_split_algo[i][5][0][1], "кц_при", ""), names[1], names[2]) + ')']);
							my_exe.push(["_bre"]);
							my_exe.push(["_els"]);
							my_exe.push(["_end"]);
							my_exe.push(["_end"]);
							my_stack.pop();
							k_split_algo[i][5].shift();
						} else
							if (ItisType(k_split_algo[i][5][0][1].split(" ")[0])) {
								var my_type = "";
								for (var k = 0; k < k_split_algo[i][5][0][1].split(",").length; k++) {
									if (ItisType(k_split_algo[i][5][0][1].split(",")[k].trim().split(" ")[0].trim())) {
										my_type = k_split_algo[i][5][0][1].split(",")[k].trim().split(" ")[0];
										if (!ItisName(GetIn(k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim(), ' ', ''))) {
											ErrorKumir.push([4, GetIn(k_split_algo[i][5][0][1].split(",")[k].split("=")[0], ' ', '').trim() + ' не имя! ', k_split_algo[i][5][0][0]]);
											return;
										}
										names[2].push(GetIn(k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim(), ' ', ''));
										my_exe.push(["_var", my_type, GetIn(k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim(), ' ', '')]);
										if (k_split_algo[i][5][0][1].split(",")[k].split("=").length>=2)
										{
											if (parseFormula('(' + GetIn(k_split_algo[i][5][0][1].split(",")[k], "=", "") + ')', names[1], names[2]) == undefined) {
												ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
												return;
											}
											my_exe.push(["_val", GetIn(k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim(), ' ', ''),parseFormula('(' + GetIn(k_split_algo[i][5][0][1].split(",")[k], "=", "") + ')', names[1], names[2])]);
										}
									} else {
										if (!ItisName(k_split_algo[i][5][0][1].split(",")[k].split("=")[0])) {
											ErrorKumir.push([4, k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim() + ' не имя! ', k_split_algo[i][5][0][0]]);
											return;
										}
										names[2].push(k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim());
										my_exe.push(["_var", my_type, k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim()]);
										if (k_split_algo[i][5][0][1].split(",")[k].split("=").length>=2)
										{
											if (parseFormula('(' + GetIn(k_split_algo[i][5][0][1].split(",")[k], "=", "") + ')', names[1], names[2]) == undefined) {
												ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
												return;
											}
											my_exe.push(["_val", k_split_algo[i][5][0][1].split(",")[k].split("=")[0].trim(),parseFormula('(' + GetIn(k_split_algo[i][5][0][1].split(",")[k], "=", "") + ')', names[1], names[2])]);
										}
										
									}
								}
								k_split_algo[i][5].shift();
							} else
								if (GetIn(" " + k_split_algo[i][5][0][1], " ", ":=") != "" && ItisName(GetIn(" " + k_split_algo[i][5][0][1], " ", ":="))) //имя:=выражение
								{
									if (parseFormula('(' + GetIn(k_split_algo[i][5][0][1], ":=", "") + ')', names[1], names[2]) == undefined) {
										ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
										return;
									}
									my_exe.push(["_val", GetIn(" " + k_split_algo[i][5][0][1], " ", ":=").trim(), parseFormula('(' + GetIn(k_split_algo[i][5][0][1], ":=", "") + ')', names[1], names[2])]);
									k_split_algo[i][5].shift();
								} else
									if (k_split_algo[i][5][0][1].indexOf("вывод ") == 0) {
										if (parseFormula('f(' + GetIn(k_split_algo[i][5][0][1], "вывод ", "") + ')', names[1], names[2]) == undefined) {
											ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
											return;
										}
										my_exe.push(["_out", parseFormula('f(' + GetIn(k_split_algo[i][5][0][1], "вывод ", "") + ')', names[1], names[2])]);
										k_split_algo[i][5].shift();
									} else
										if (k_split_algo[i][5][0][1].indexOf("ввод ") == 0) {
											var param_split = GetIn(k_split_algo[i][5][0][1], "ввод ", "").split(',');
											for (var k = 0; k < param_split.length; k++)
												if (!ItisName(param_split[k])) {
													ErrorKumir.push([4, 'Найден параметр ввода который не может является названием переменной', k_split_algo[i][5][0][0]]);
													return;
												}
											if (parseFormula('f(' + GetIn(k_split_algo[i][5][0][1], "ввод ", "") + ')', names[1], names[2]) == undefined) {
												ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
												return;
											}
											my_exe.push(["_inp", parseFormula('f(' + GetIn(k_split_algo[i][5][0][1], "ввод ", "") + ')', names[1], names[2])]);
											k_split_algo[i][5].shift();
										} else
											if (k_split_algo[i][5][0][1].indexOf("при ") == 0) {
												if (parseFormula(GetIn(k_split_algo[i][5][0][1], "при", ":"), names[1], names[2]) == undefined) {
													ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
													return;
												}
												if (my_stack.length == 0) {
													ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
													return;
												}
												if (my_stack[my_stack.length - 1].indexOf("выбор") != 0) {
													ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
													return;
												}
												if (parseInt(GetIn(my_stack[my_stack.length - 1], "выбор", "").trim()) > 1) {
													my_exe.push(["_els"]);
												}
												my_stack[my_stack.length - 1] = "выбор" + (parseInt(GetIn(my_stack[my_stack.length - 1], "выбор", "").trim()) + 1);
												my_exe.push(["__if", parseFormula(GetIn(k_split_algo[i][5][0][1], "при", ":"), names[1], names[2])]);
												k_split_algo[i][5][0][1] = GetIn(GetIn(k_split_algo[i][5][0][1], "при", ""), ":", "").trim();
												if (k_split_algo[i][5][0][1] == "")
													k_split_algo[i][5].shift();
											} else
												if (k_split_algo[i][5][0][1].indexOf("выбор ") == 0) {
													my_stack.push("выбор1");
													//my_exe.push(["__if", 'v_да']);
													k_split_algo[i][5][0][1] = GetIn(k_split_algo[i][5][0][1], "выбор ", "").trim();
													if (k_split_algo[i][5][0][1] == "")
														k_split_algo[i][5].shift();
												} else
													if (k_split_algo[i][5][0][1].indexOf("все ") == 0) {
														if (my_stack.length == 0) {
															ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
															return;
														}
														if (!(my_stack[my_stack.length - 1] == "если иначе" || my_stack[my_stack.length - 1] == "если" || my_stack[my_stack.length - 1].indexOf("иначе_выбор") == 0 || my_stack[my_stack.length - 1].indexOf("выбор") == 0)) {
															ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
															return;
														}
														if (my_stack[my_stack.length - 1] == "если") {
															my_exe.push(["_els"]);
															my_exe.push(["_end"]);
														}
														if (my_stack[my_stack.length - 1] == "если иначе")
															my_exe.push(["_end"]);
														if (my_stack[my_stack.length - 1].indexOf("выбор") == 0)
															for (var k = 1; k < parseInt(GetIn(my_stack[my_stack.length - 1], "выбор", "").trim()); k++)
																my_exe.push(["_end"]);
														if (my_stack[my_stack.length - 1].indexOf("иначе_выбор") == 0)
															for (var k = 1; k < parseInt(GetIn(my_stack[my_stack.length - 1], "иначе_выбор", "").trim()); k++)
																my_exe.push(["_end"]);
														my_stack.pop();
														k_split_algo[i][5].shift();
													} else
														if (k_split_algo[i][5][0][1].indexOf("иначе ") == 0) {
															if (my_stack.length == 0) {
																ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
																return;
															}
															if (!(my_stack[my_stack.length - 1] == "если" || my_stack[my_stack.length - 1].indexOf("выбор") == 0)) {
																ErrorKumir.push([4, 'Неожиданная команда. Мне кажеться ей тут не место.', k_split_algo[i][5][0][0]]);
																return;
															}
															if (my_stack[my_stack.length - 1] == "если") {
																my_exe.push(["_els"]);
																my_stack[my_stack.length - 1] = "если иначе";
															}
															if (my_stack[my_stack.length - 1].indexOf("выбор") == 0) {
																if (parseInt(GetIn(my_stack[my_stack.length - 1], "выбор", "").trim())!='1')
																	my_exe.push(["_els"]);
																my_stack[my_stack.length - 1] = "иначе_выбор" + parseInt(GetIn(my_stack[my_stack.length - 1], "выбор", "").trim());
																
															}
															k_split_algo[i][5][0][1] = GetIn(k_split_algo[i][5][0][1], "иначе ", "").trim();
															if (k_split_algo[i][5][0][1] == "")
																k_split_algo[i][5].shift();
														} else
															if (k_split_algo[i][5][0][1].indexOf("утв ") == 0 || k_split_algo[i][5][0][1].indexOf("утв(") == 0) {
																if (parseFormula(GetIn(k_split_algo[i][5][0][1], "утв", "", names[1], names[2])) == undefined) {
																	ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
																	return;
																}
																my_exe.push(["__if", parseFormula(GetIn(k_split_algo[i][5][0][1], "утв", ""), names[1], names[2])]);
																my_exe.push(["_err", k_split_algo[i][5][0][0], "Утверждение ложно"]);
																my_exe.push(["_els"]);
																my_exe.push(["_end"]);
																k_split_algo[i][5].shift();
															} else
																if (k_split_algo[i][5][0][1].indexOf("если ") == 0 || k_split_algo[i][5][0][1].indexOf("если(") == 0) {
																	if (parseFormula(GetIn(k_split_algo[i][5][0][1], "если", ""), names[1], names[2]) == undefined) {
																		ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
																		return;
																	}
																	my_stack.push("если");
																	my_exe.push(["__if", parseFormula(GetIn(k_split_algo[i][5][0][1], "если", ""), names[1], names[2])]);
																	k_split_algo[i][5].shift();
																} else
																	if (k_split_algo[i][5][0][1].indexOf("выход ") == 0) {
																		k_split_algo[i][5][0][1] = GetIn(k_split_algo[i][5][0][1], "выход", "").trim();
																		my_exe.push(["_bre"]);
																		if (k_split_algo[i][5][0][1] == "")
																			k_split_algo[i][5].shift();
																	} else
																		if (ItisName(k_split_algo[i][5][0][1])) {
																			if (names[0].indexOf(parseFormula(k_split_algo[i][5][0][1].trim()).slice(2)) == -1) {
																				ErrorKumir.push([4, 'Не найден данный алгоритм(' + k_split_algo[i][5][0][1].trim() + ').', k_split_algo[i][5][0][0]]);
																				return;
																			}
																			my_exe.push(["__pr", k_split_algo[i][5][0][1].trim(), []]);
																			k_split_algo[i][5].shift();
																		} else
																			if (ItisName(k_split_algo[i][5][0][1].split('(')[0]) && GetIn(k_split_algo[i][5][0][1], "(", ")") != "") {
																				if (names[0].indexOf(parseFormula(GetIn(' ' + k_split_algo[i][5][0][1], ' ', "(").trim()).slice(2)) == -1) {
																					ErrorKumir.push([4, 'Не найден данный алгоритм(' + GetIn(' ' + k_split_algo[i][5][0][1], ' ', "(").trim() + ').', k_split_algo[i][5][0][0]]);
																					return;
																				}
																				if (parseFormula("f(" + GetIn(k_split_algo[i][5][0][1], "(", ""), names[1], names[2]) == undefined) {
																					ErrorKumir.push([4, 'Неверная формула.\r\nЛоги:\r\n' + persing_log, k_split_algo[i][5][0][0]]);
																					return;
																				}
																				my_exe.push(["__pr", GetIn(' ' + k_split_algo[i][5][0][1], ' ', "(").trim(), parseFormula("f(" + GetIn(k_split_algo[i][5][0][1], "(", ""), names[1], names[2])]);
																				k_split_algo[i][5].shift();
																			} else {
																				ErrorKumir.push([4, 'Неизвестная команда', k_split_algo[i][5][0][0]]);
																				return;
																			}
			if (TabInProgramm[exe_str] == undefined)
				TabInProgramm[exe_str] = Math.min(my_stack.length + 1, exe_stack_length);
		}
		if (my_stack.length == 0)
			k_split_algo[i][5] = my_exe;
		else {
			ErrorKumir.push([4, 'В алгоритме ' + k_split_algo[i][1] + ' ошибка. Какие-то из условных инструкций не закрыты.\r\nСтек команд:\r\n' + my_stack.join(), 0]);
			return;
		}
	}
	function ParsArguments2(a) {
		var type_arg = 'арг';
		var type_inp = '';
		var out = ["", "", "", []];
		for (var k = 0; k < a.length; k++) {
			a[k] = a[k].trim();
			if (ItisType(a[k].split(' ')[0])) {
				type_inp = a[k].split(' ')[0];
				out[0] += parseFormula(GetIn(a[k], a[k].split(' ')[0], "").trim()) + ',';
				out[1] += '"' + type_arg + '",';
				out[2] += '"' + type_inp + '",';
				out[3].push("" + GetIn(a[k], a[k].split(' ')[0], "").trim() + "");
			} else
				if (['арг', 'рез', 'аргрез'].indexOf(a[k].split(' ')[0]) != -1) {
					type_arg = a[k].split(' ')[0];
					if (ItisType(a[k].split(' ')[1])) {
						type_inp = a[k].split(' ')[1];
						out[0] += parseFormula(GetIn(a[k], a[k].split(' ')[1], "").trim()) + ',';
						out[1] += '"' + type_arg + '",';
						out[2] += '"' + type_inp + '",';
						out[3].push("" + GetIn(a[k], a[k].split(' ')[1], "").trim() + "");
					} else
						if (type_inp != "") {
							out[0] += parseFormula(GetIn(a[k], a[k].split(' ')[0], "").trim()) + ',';
							out[1] += '"' + type_arg + '",';
							out[2] += '"' + type_inp + '",';
							out[3].push("" + GetIn(a[k], a[k].split(' ')[0], "").trim() + "");
						} else {
							return;
						}
				} else {
					if (type_inp != "") {
						out[0] += parseFormula(a[k].split(' ')[0].trim()) + ',';
						out[1] += '"' + type_arg + '",';
						out[2] += '"' + type_inp + '",';
						out[3].push("" + a[k].split(' ')[0].trim() + "");
					} else {
						return;
					}
				}
		}
		out[0] = out[0].substring(0, out[0].length - 1);
		out[1] = out[1].substring(0, out[1].length - 1);
		out[2] = out[2].substring(0, out[2].length - 1);
		return out;
	}
	var exe_s = "try{\r\n\r\n";
	//var exe_s = "\r\np_main();\r\n";
	for (var i = 0; i < string_split.length; i++) {
		exe_s += "var v_" + string_split[i][0] + "='" + string_split[i][1] + "';\r\n";
	}
	var __i;
	___i = 0;
	for (var i = 0; i < k_split_algo.length; i++) {
		var exe_no = 0;
		//[[kommand befo alg] [procedure or function,"name",[parametr1,.....],дано,надо, [........]] , [""] ]
		if (i==0)
		{
			for (var k = 0; k < k_split_algo[i].length; k++)
				switch (k_split_algo[i][k][0]) {
					case "_str":
						exe_no = k_split_algo[i][k][1];
						exe_s += "if (SetStr(" + (k_split_algo[i][k][1]) + ")){return;}\r\n";
					break;
					case "_val":
						if (parseFormula(k_split_algo[i][k][1], names[1], names[2]) == undefined) {
							ErrorKumir.push([6, "Необъявленное имя(" + k_split_algo[i][k][1] + ")", exe_no]);
							return;
						}
						exe_s += "Val(" + parseFormula(k_split_algo[i][k][1], names[1], names[2]) + "," + k_split_algo[i][k][2] + ")\r\n";
						break;
					case "_var":
						exe_s += "var " + parseFormula(k_split_algo[i][k][2], names[1], names[2]) + "=NewType('" + k_split_algo[i][k][1] + "')\r\n";
						break;
					default:
						ErrorKumir.push([6, "Неизвестная команда при трансляции " + k_split_algo[i][k][0], exe_no]); //Такое не может произойти правда........
						//exe_s += "out_array.push([10, 'Неизвестная команда при трансляции " + k_split_algo[i][5][k][0] + "', GetStr()]);\r\n";
						return
				}
			continue;
		}
		var out = ParsArguments2(k_split_algo[i][2])
			if (out == undefined) {
				ErrorKumir.push([6, "Не удалось распарсить аргументы функции " + k_split_algo[i][1], 0]);
				return;
			}

			var iiii = 0;
		while (iiii < names[2].length) {
			if (names[2][iiii] == "знач") {
				names[2].splice(iiii, 1);
			} else {
				iiii++;
			}
		}
		if (k_split_algo[i][0] == "procedure")
			exe_s += "function p_" + parseFormula(k_split_algo[i][1]).slice(2) + "(" + out[0] + ") {\r\n";
		else
			if (k_split_algo[i][0] == "function") {
				exe_s += "function f_" + parseFormula(k_split_algo[i][1]).slice(2) + "(" + out[0] + ")\r\n{\r\nvar " + parseFormula('знач') + '=NewType("' + k_split_algo[i][7] + '");\r\n';
				names[2].push("знач");
			} else {
				ErrorKumir.push([4, 'Случился бред)))', 0]);
				return;
			}
		exe_s += "ParseArgument({'a1':[" + out[0] + "],'a2':[" + out[1] + "],'a3':[" + out[2] + "]})\r\n";
		if (k_split_algo[i][3].trim() == '')
			k_split_algo[i][3] = parseFormula('да', names[1], names[2]);
		else
			k_split_algo[i][3] = parseFormula(k_split_algo[i][3], names[1], names[2]);
		if (k_split_algo[i][4].trim() == '')
			k_split_algo[i][4] = parseFormula('да', names[1], names[2]);
		else
			k_split_algo[i][4] = parseFormula(k_split_algo[i][4], names[1], names[2]);
		exe_s += "if (" + (k_split_algo[i][3]) + "){for (kekv=1;kekv<2;kekv++){\r\n\r\n";
		for (var k = 0; k < k_split_algo[i][5].length; k++) {
			switch (k_split_algo[i][5][k][0]) {
			case "_bre":
				exe_s += "prog_write('завершено');break;\r\n";
				break;
			case "_str":
				exe_no = k_split_algo[i][5][k][1];
				exe_s += "if (SetStr(" + (k_split_algo[i][5][k][1]) + ")){return;}\r\n";
				break;
			case "__if":
				___i++;
				var random_name_ot = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				exe_s += "var "+random_name_ot+"="+k_split_algo[i][5][k][1]+";if ("+random_name_ot+"){prog_write('да')}else{prog_write('нет')} if ("+random_name_ot+"){\r\n";
				break;
			case "_els":
				exe_s += "}\r\nelse\r\n{\r\n";
				break;
			case "_end":
				exe_s += "}\r\n";
				break;
			case "__pr":
				___i++;
				var random_name_str = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				if (k_split_algo[i][5][k][2].length == 0)
					exe_s += "var "+random_name_str+"=GetStr(); prog_write('запущено',"+random_name_str+");p_" + parseFormula(k_split_algo[i][5][k][1].trim()).slice(2) + "();prog_write('выполнено',"+random_name_str+");\r\n";
				else
					exe_s += "var "+random_name_str+"=GetStr(); prog_write('запущено',"+random_name_str+");p_" + parseFormula(k_split_algo[i][5][k][1].trim()).slice(2) + "" + k_split_algo[i][5][k][2].slice(3) + ";prog_write('выполнено',"+random_name_str+");\r\n";
				break;
			case "_err":
				exe_s += "out_array.push([10, 'Ошибка при исполнение: " + k_split_algo[i][5][k][1] + "', GetStr()]);\r\n";
				break;
			case "_for":
				___i++;
				var random_name_ot = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				___i++;
				var random_name2_do = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				___i++;
				var random_name3_for = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				___i++;
				var random_name3_shag = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				___i++;
				var random_name4_name = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				___i++;
				var random_name_str = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				exe_s += "var "+random_name_str+"=GetStr();";
				if ((k_split_algo[i][5][k][1]==undefined) || (parseFormula(k_split_algo[i][5][k][1], names[1], names[2])==undefined))
				{
					exe_s += "var " + random_name_ot + "=" + k_split_algo[i][5][k][2] + ";var " + random_name2_do + "=" + k_split_algo[i][5][k][3] + ";var " + random_name3_shag + "=" + k_split_algo[i][5][k][4] + "; for (var " + random_name3_for + "=" + random_name_ot + ";Srav('<='," + random_name3_for + "," + random_name2_do + ");" + random_name3_for + "+=" + random_name3_shag + "){\r\n";
					exe_s += "prog_write('= '+"+random_name3_for+","+random_name_str+");\r\n";
				}
				else
				{
					exe_s += "var " + random_name_ot + "=" + k_split_algo[i][5][k][2] + ";var " + random_name2_do + "=" + k_split_algo[i][5][k][3] + ";var " + random_name3_shag + "=" + k_split_algo[i][5][k][4] + "; for (var " + random_name3_for + "=" + random_name_ot + ";Srav('<='," + random_name3_for + "," + random_name2_do + ");" + random_name3_for + "+=" + random_name3_shag + "){\r\n";
					exe_s += "Val(" + parseFormula(k_split_algo[i][5][k][1], names[1], names[2]) + "," + random_name3_for + ");prog_write('"+k_split_algo[i][5][k][1]+" = '+"+random_name3_for+","+random_name_str+");\r\n";
				}
				break;
			case "_val":
				if (parseFormula(k_split_algo[i][5][k][1], names[1], names[2]) == undefined) {
					ErrorKumir.push([6, "Необъявленное имя(" + k_split_algo[i][5][k][1] + ")", exe_no]);
					return;
				}
				exe_s += "Val(" + parseFormula(k_split_algo[i][5][k][1], names[1], names[2]) + "," + k_split_algo[i][5][k][2] + ");prog_write('"+k_split_algo[i][5][k][1] + " = '+ GetType("+parseFormula(k_split_algo[i][5][k][1], names[1], names[2]) + ")[1]);\r\n";
				break;
			case "_var":
				exe_s += "var " + parseFormula(k_split_algo[i][5][k][2], names[1], names[2]) + "=NewType('" + k_split_algo[i][5][k][1] + "')\r\n";
				break;
			case "_inp":
				exe_s += "Get_Inp({'inp':[" + k_split_algo[i][5][k][1].slice(3).substring(1, k_split_algo[i][5][k][1].slice(3).length - 1) + "]});\r\n";
				break;
			case "_out":
				exe_s += "out_array.push([-1,v([" + k_split_algo[i][5][k][1].slice(3).substring(1, k_split_algo[i][5][k][1].slice(3).length - 1) + "])]);program_output+=v([" + k_split_algo[i][5][k][1].slice(3).substring(1, k_split_algo[i][5][k][1].slice(3).length - 1) + "]).join('');\r\n";
				break;
			case "_whi":
				___i++;
				var random_name_str = "random_name_" + Math.floor(Math.random() * 100000) + "_" + ___i + "_";
				exe_s += "var "+random_name_str+"=GetStr(); while (prog_write('нет',"+random_name_str+")&&(" + k_split_algo[i][5][k][1] + ")){prog_write('да',"+random_name_str+");\r\n";
				break;
			default:
				ErrorKumir.push([6, "Неизвестная команда при трансляции " + k_split_algo[i][5][k][0], exe_no]); //Такое не может произойти правда........
				//exe_s += "out_array.push([10, 'Неизвестная команда при трансляции " + k_split_algo[i][5][k][0] + "', GetStr()]);\r\n";
				return;
			}
		}
		exe_s += "\r\n}\r\n}\r\nelse\r\n{\r\nout_array.push([10, 'Утверждение \"дано\" ложно', GetStr()]);\r\n}\r\nif (!" + k_split_algo[i][4] + "){\r\nout_array.push([10, 'Утверждение \"надо\" ложно', GetStr()]);\r\n}\r\n";
		if (k_split_algo[i][0] == "function")
			exe_s += "return " + parseFormula('знач') + ';\r\n';
		exe_s += "}\r\n\r\n";
	}
	exe_s += "\r\np_main();isall();\r\n}\r\ncatch (e) {\r\n return [-1,e]\r\n}return out_array;";
	//exe_s += "return out_array;";

	if (debug)
		console.log(exe_s);
	var returncode = [];
	if (map != '')
		returncode = RanJsCode(exe_s, map);
	if (returncode > 6000) {
		ErrorKumir.push([6, 'Слишком много команд было выполнено)))', 0]);
		return;
	}
	if (debug)
		console.log(returncode);
	if (returncode.length == 2)
		if (returncode[0] == -1) {
			function Damp(e, p) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', 'errordamp', true);
				xhr2.onreadystatechange = function () {}
				xhr2.onerror = function () {
					if (debug)
						console.log('Сервер не ответил(3.2).');
				}
				xhr2.send('errordamp+' + encodeURIComponent(p).replace(/%20/g, "+"));
			}
			Damp(returncode[1], damp_program);
			ErrorKumir.push([12, 'Неизвестная ошибка. Err: ' + returncode[1], 0]);
			return;
		}
	for (i = 0; i < returncode.length; i++) {
		switch (returncode[i][0]) {
		case 0:
			//шаг
			if (returncode[i][1] == 0)
				steps.push("шагвлево");
			if (returncode[i][1] == 1)
				steps.push("шагвправо");
			if (returncode[i][1] == 2)
				steps.push("шагвниз");
			if (returncode[i][1] == 3)
				steps.push("шагвверх");
			if (returncode[i][1] == 4)
				steps.push("закрасить");
			if (returncode[i][1] == 10)
				steps.push("Errorшагвлево");
			if (returncode[i][1] == 11)
				steps.push("Errorшагвправо");
			if (returncode[i][1] == 12)
				steps.push("Errorшагвниз");
			if (returncode[i][1] == 13)
				steps.push("Errorшагвверх");
			if (returncode[i][1] == 14)
				steps.push("закрасить");
			break;
		case -1:
			//вывод
			for (var k = 0; k < returncode[i][1].length; k++)
				steps.push("вывод" + returncode[i][1][k]);
			break;
		case -2:
			//новая строка
			steps.push("str" + returncode[i].slice(1));
			break;
		case -3:
			//вывод строки
			steps.push("write_prog" + returncode[i][1]+'_'+returncode[i][2]);
			break;
		case 10:
			//ошибка
			ErrorKumir.push([-5, returncode[i][1], returncode[i][2]]); //str0 // влево // вправо // вниз // вверх
			break;
		case 11:
			//предупреждение
			ErrorKumir.push([10, returncode[i][1], returncode[i][2]]); //str0 // влево // вправо // вниз // вверх
			break;
		default:
			ErrorKumir.push([6, "Неизвестная команда при обработке работы программы " + returncode[i][0], 0]);
		}
	}
	var end = new Date; // конец измерения
	if (debug)
		console.log(steps);
	TabInProgramm["work"] = true;
	return (end - start);

}
