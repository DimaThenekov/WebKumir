
function f_цел_в_лит(x) {
	return x.toString();
}
function f_вещ_в_лит(x) {
	return x.toString();
}
function f_лит_в_цел(x) {
	return x.parseInt();
}
function f_лит_в_вещ(x) {
	return x.parseInt();
}
function f_sqrt(x) {
	return Math.sqrt(x);
}
function f_abs(x) {
	return Math.abs(x);
}
function f_iabs(x) {
	return Math.abs(x);
}
function f_sign(x) {
	if (x < 0)
		return -1;
	if (x == 0)
		return 0;
	if (x > 0)
		return 1;
}
function f_sin(x) {
	return Math.sin(x);
}
function f_cos(x) {
	return Math.cos(x);
}
function f_tg(x) {
	return Math.tg(x);
}
function f_ctg(x) {
	return 1 / Math.tan(x); ;
}
function f_arcsin(x) {
	return Math.asin(x);
}
function f_arccos(x) {
	return Math.acos(x);
}
function f_arctg(x) {
	return Math.atan(x);
}
function f_arcctg(x) {
	return Math.PI / 2 - Math.atan(x);
}
function f_ln(x) {
	return Math.ln(x);
}
function f_lg(x) {
	return Math.log(x);
}
function f_exp(x) {
	return Math.exp(x);
}
function f_min(x, y) {
	return Math.min(x, y);
}
function f_max(x, y) {
	return Math.max(x, y);
}
function f_mod(x, y) {
	return x % y;
}
function f_div(x, y) {
	return (x - x % y) / y;
}
function f_int(x) {
	return Math.floor(x);
}
function f_rnd(x) {
	return Math.floor(Math.random() * x);
}
function f_длин(x) {
	return x.length;
}
function f_код(x) {
	return x.charCodeAt();
}
function f_символ(x) {
	return String.fromCharCode(x);
}
function f_юникод(x) {
	return x.charCodeAt();
}
function f_символ2(x) {
	return String.fromCharCode(x);
}

var str_timer = 0;
var start = new Date;
var out_array = [];
var on_error = false;
var str = 0;
//,'слевасвободно()','справасвободно()','сверхусвободно()','снизусвободно()','слевастена()','справастена()','сверхустена()','снизустена()','клетказакрашена()','клеткачистая()'

/*var map = new Array(4);
for (var i = 0; i < map.length; map[i++] = new Array(4));
for (var i = 0; i < map.length; i++) {
for (var j = 0; j < map.length; j++) {
map[i][j] = new Array(7);
map[i][j][0] = 0; //Wall
map[i][j][1] = 0; //Color
map[i][j][2] = 0; //Radiation
map[i][j][3] = 0; //Temperature
map[i][j][4] = "$"; //Symbol
map[i][j][5] = "$"; //Symbol1
map[i][j][6] = ""; //Point
}
}*/
var map = undefined;
var playerX = 0;
var playerY = 0;
function parsemap(inp_text) {
	var split_text = inp_text.split('\n');
	mapsizeX = parseInt(split_text[1].split(' ')[0]);
	mapsizeY = parseInt(split_text[1].split(' ')[1]);
	if (map.length != mapsizeX + 2)
		map = new Array(mapsizeX + 2);
	for (var i = 0; i < map.length; i++)
		if (map[i] == undefined || map[i].length != mapsizeY + 2)
			map[i] = new Array(mapsizeY + 2);
	for (var i = 0; i < map.length; i++) {
		for (var j = 0; j < map[i].length; j++) {
			if (map[i][j] == undefined || map[i][j].length != 7)
				map[i][j] = new Array(7);
			map[i][j][0] = 0; //Wall
			map[i][j][1] = 0; //Color
			map[i][j][2] = 0; //Radiation
			map[i][j][3] = 0; //Temperature
			map[i][j][4] = "$"; //Symbol
			map[i][j][5] = "$"; //Symbol1
			map[i][j][6] = ""; //Point
		}
	}
	playerX = parseInt(split_text[3].split(' ')[0]);
	playerY = parseInt(split_text[3].split(' ')[1]);
	for (var i = 0; i < mapsizeX + 1; i++) {
		for (var j = 0; j < mapsizeY + 1; j++) {
			map[i][j][0] = 0; //Wall
			map[i][j][1] = 0; //Color
			map[i][j][2] = 0; //Radiation
			map[i][j][3] = 0; //Temperature
			map[i][j][4] = "$"; //Symbol
			map[i][j][5] = "$"; //Symbol1
			map[i][j][6] = ""; //Point
			//}
		}
	}
	for (var j = 5; j < split_text.length - 2; j++) {
		//document.getElementById('area').value
		smapline = split_text[j].split(' ');
		if (smapline.length > 2) {
			map[smapline[0]][smapline[1]][0] = parseInt(smapline[2]); //Wall
			map[smapline[0]][smapline[1]][1] = parseFloat(smapline[3]); //Color
			map[smapline[0]][smapline[1]][2] = parseFloat(smapline[4]); //Radiation
			map[smapline[0]][smapline[1]][3] = parseFloat(smapline[5]); //Temperature
			map[smapline[0]][smapline[1]][4] = smapline[6].trim(); //Symbol
			map[smapline[0]][smapline[1]][5] = smapline[7].trim(); //Symbol1
			map[smapline[0]][smapline[1]][6] = smapline[8].trim(); //Point
		}
	}
}

if (map_text != undefined) {
	map = new Array(4);
	parsemap(map_text);
}
function p_вправо() {
	if (RQuWall(playerX, playerY, 1))
		out_array.push([0, 1]);
	else {
		out_array.push([0, 11]);
		console.log('Робот разбился');
		out_array.push([11, 'Робот разбился', GetStr()]);
		on_error = true;
		return [];
	}
	playerX++;
	return;
}
function p_вниз() {
	if (RQuWall(playerX, playerY, 3))
		out_array.push([0, 2]);
	else {
		out_array.push([0, 12]);
		console.log('Робот разбился');
		out_array.push([11, 'Робот разбился', GetStr()]);
		on_error = true;
		return [];
	}
	playerY++;
	return;
}
function p_влево() {
	if (RQuWall(playerX, playerY, 0))
		out_array.push([0, 0]);
	else {
		out_array.push([0, 10]);
		console.log('Робот разбился');
		out_array.push([11, 'Робот разбился', GetStr()]);
		on_error = true;
		return [];
	}
	playerX--;
	return;
}
function p_вверх() {
	if (RQuWall(playerX, playerY, 2))
		out_array.push([0, 3]);
	else {
		out_array.push([0, 13]);
		console.log('Робот разбился');
		out_array.push([11, 'Робот разбился', GetStr()]);
		on_error = true;
		return [];
	}
	playerY--;
	return;
}
function p_закрасить() {
	if (RQuWall(playerX, playerY, -1) == 0) {
		out_array.push([0, 4]);
		map[playerX][playerY][1] = 1;
	} else {
		out_array.push([0, 14]);
		console.log('Робот не может закрасить закрашенное');
		out_array.push([11, 'Робот не может закрасить закрашенное', GetStr()]);
		on_error = true;
		return [];
	}
	return;
}

//,'getmap(1,1)','getmap(1,2)','getmap(1,3)','getmap(1,4)','getmap(2,1)','getmap(2,2)','getmap(2,3)','getmap(2,4)','getmap(3,1)','getmap(3,2)','getmap(4,1)','getmap(4,2)
//,'слева свободно','справа свободно','сверху свободно','снизу свободно','слева стена','справа стена','сверху стена','снизу стена','клетка закрашена','клетка чистая','радиация','температура'
function f_getmap(x, y) {
	if (x == 1) {
		switch (y) {
		case 1:
			return RQuWall(playerX, playerY, 0);
			break;
		case 2:
			return RQuWall(playerX, playerY, 1);
			break;
		case 3:
			return RQuWall(playerX, playerY, 2);
			break;
		case 4:
			return RQuWall(playerX, playerY, 3);
			break;
		}
	}
	if (x == 2) {
		switch (y) {
		case 1:
			return !RQuWall(playerX, playerY, 0);
			break;
		case 2:
			return !RQuWall(playerX, playerY, 1);
			break;
		case 3:
			return !RQuWall(playerX, playerY, 2);
			break;
		case 4:
			return !RQuWall(playerX, playerY, 3);
			break;
		}
	}
	if (x == 3) {
		switch (y) {
		case 1:
			return RQuWall(playerX, playerY, -1) != 0;
			break;
		case 2:
			return RQuWall(playerX, playerY, -1) == 0;
			break;
		}
	}
	if (x == 4) {
		switch (y) {
		case 1:
			return RQuWall(playerX, playerY, -2) != 0;
			break;
		case 2:
			return RQuWall(playerX, playerY, -3) == 0;
			break;
		}
	}
}

function RQuWall(pos1, pos2, a) {
	if (!((pos1 >= 0) && (pos2 >= 0) && (pos1 < mapsizeX) && (pos2 < mapsizeY)))
		return false;
	if (a == -1) {
		return (map[pos1][pos2][1]); //Color
	}
	if (a == -2) {
		return (map[pos1][pos2][2]); //Radiation
	}
	if (a == -3) {
		return (map[pos1][pos2][3]); //Temperature
	}
	if (a == 0) {
		if (pos1 > 0)
			return (((map[pos1][pos2][0] >> 0) & 1) != 1) && (((map[pos1 - 1][pos2][0] >> 1) & 1) != 1);
		if (pos1 == 0)
			return false;
	}
	if (a == 1) {
		if (pos1 < mapsizeX - 1)
			return (((map[pos1][pos2][0] >> 3) & 1) != 1) && (((map[pos1 + 1][pos2][0] >> 2) & 1) != 1);
		if (pos1 == (mapsizeX - 1))
			return false;
	}
	if (a == 2) {
		if (pos2 > 0)
			return (((map[pos1][pos2][0] >> 1) & 1) != 1) && (((map[pos1][pos2 - 1][0] >> 0) & 1) != 1);
		if (pos2 == 0)
			return false;
	}
	if (a == 3) {
		if (pos2 < mapsizeY - 1)
			return (((map[pos1][pos2][0] >> 2) & 1) != 1) && (((map[pos1][pos2 + 1][0] >> 3) & 1) != 1);
		if (pos2 == mapsizeY - 1)
			return false;
	}
}

function GetStr() {
	str_timer++;
	return str;
}

function SetStr(x) {
	if (out_array.length > 5000) //big data
		return true;
	if (str_timer > 1000 && (end - start > 100))
		return true;
	//if (end - start > 1000)
	//	return true;
	if (on_error)
		return true;
	str_timer++;
	str = x;
	var end = new Date;
	out_array.push([-2, str]);
	return false;
}

function GetType(x) {
	if (typeof x == 'number') {
		if (x == 1)
			return [2, 1];
		if (x == 0)
			return [2, 0];
		if (Math.floor(x) == x)
			return [0, x];
		else
			return [1, x];
	} else
		if (typeof x == 'string') {
			if (x.length == 1)
				return [3, x];
			else
				return [4, x];
		} else
			if (x == true || x == false) {
				if (x == true)
					return [2, 1];
				else
					return [2, 0];
			} else
				if (typeof x == 'symbol') {
					return [3, x];
				} else
					if (x['type'] != undefined) {
						return [x['type'], x['value']];
					} else {
						console.log('Неизвестный тип: ' + x); //надеюсь этого не будет
						out_array.push([10, 'Неизвестный тип: ' + x, GetStr()]);
						on_error = true;
						return [];
					}
}

function Not(x) {
	return Calc(x, '!', 0);
}
function Power(x, y) {
	return Calc(x, '**', y);
}
function Mul(x, y) {
	return Calc(x, '*', y);
}
function Del(x, y) {
	return Calc(x, '/', y);
}
function Del(x, y) {
	return Calc(x, '/', y);
}
function Sum(x, y) {
	return Calc(x, '+', y);
}
function Min(x, y) {
	return Calc(x, '-', y);
}
function Srav(o, x, y) {
	return Calc(x, o, y);
}
function v(a) {
	var b = [];
	for (i = 0; i < a.length; i++) {
		var type1 = GetType(a[i]);
		b.push(type1[1]);
	}
	return b;
}
function Val(x, y) {
	debugger;
	var type1 = GetType(x);
	var type2 = GetType(y);
	var canit = [[1, 0, 1, 0, 0], [1, 1, 1, 0, 0], [0, 0, 1, 0, 0], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1]];
	if (canit[type1[0]][type2[0]] == 1) {
		x["value"] = type2[1];
	} else {
		console.log('Путаница с типами. Нельзя присваивать разные типы');
		out_array.push([10, 'Путаница с типами. Нельзя присваивать разные типы', GetStr()]);
		on_error = true;
		return 'kek';
	}
}
function ParseArgument(a1, a2, a3) {
	for (var i = 0; i < a2.length; i++) {
		switch (a2[i]) {
		case 'арг':
			a1[i] = NewType(a3[i]);
			a1[i]["const"] = true;
			break;
		case 'рез':
			a1[i] = NewType(a3[i]);
			break;
		case 'аргрез':
			break;
		}
	}
}

function Calc(x1, s, x2) {
	var type1 = GetType(x1);
	var type2 = GetType(x2);
	if (type1.length != 2 || (type1.length == 2 && type1[0] > 9)) {
		console.log('Бред какойто1: ' + type1 + ';' + x1 + ';' + s + ';' + x2);
		out_array.push([10, 'Бред какойто1: ' + type1 + ';' + x1 + ';' + s + ';' + x2, GetStr()]);
		on_error = true;
		return 'kek';
	}
	if (type2.length != 2 || (type2.length == 2 && type1[0] > 9)) {
		console.log('Бред какойто2: ' + type2 + ';' + x1 + ';' + s + ';' + x2);
		out_array.push([10, 'Бред какойто2: ' + type2 + ';' + x1 + ';' + s + ';' + x2, GetStr()]);
		on_error = true;
		return 'kek';
	}
	//var for_case = type1[0] * 100 + ['**', '*', '/', '+', '-'].indexOf(s) * 10 + type2[0];
	switch (s) {
	case '**':
		if ((type1[0] > 2) || (type2[0] > 2)) {
			console.log('Оператор ** Не может работать со строками');
			out_array.push([10, 'Оператор ** Не может работать со строками', GetStr()]);
			on_error = true;
			return 'kek';
		} else {
			return type1[1] * type2[1];
		}
		break;
	case '*':
		if ((type1[0] > 2) && (type2[0] > 2)) {
			console.log('Оператор * не может работать с двумя строками');
			out_array.push([10, 'Оператор * не может работать с двумя строками', GetStr()]);
			on_error = true;
			return 'kek';
		} else {
			if (type1[0] > 2) {
				if (type2[0] != 1 || type2[1] < 0) {
					console.log('Оператор * не может работать со строкой и не натуральным(включая ноль) числом');
					out_array.push([10, 'Оператор * не может работать со строкой и не натуральным(включая ноль) числом', GetStr()]);
					on_error = true;
					return 'kek';
				}
				return type1[1].repeat(type2[1]);
			}
			if (type2[0] > 2) {
				if (type1[0] != 1 || type1[1] < 0) {
					console.log('Оператор * не может работать со строкой и не натуральным(включая ноль) числом');
					out_array.push([10, 'Оператор * не может работать со строкой и не натуральным(включая ноль) числом', GetStr()]);
					on_error = true;
					return 'kek';
				}
				return type2[1].repeat(type1[1]);
			}
			return type1[1] * type2[1];
		}
		break;
	case '/':
		if ((type1[0] > 2) || (type2[0] > 2)) {
			console.log('Оператор / не может работать со стороками');
			out_array.push([10, 'Оператор / не может работать со стороками', GetStr()]);
			on_error = true;
			return 'kek';
		} else {
			if (type2[1] == 0) {
				console.log('Деление на 0!!! Бесконечности не будет)))');
				out_array.push([10, 'Деление на 0!!! Бесконечности не будет)))', GetStr()]);
				on_error = true;
				return 'kek';
			}
			return type1[1] / type2[1];
		}
		break;
	case '-':
		if ((type1[0] > 2) || (type2[0] > 2)) {
			console.log('оператор - не может работать со стороками');
			out_array.push([10, 'оператор - не может работать со стороками', GetStr()]);
			on_error = true;
			return 'kek';
		} else {
			return type1[1] - type2[1];
		}
		break;
	case '+':
		if ((type1[0] == 4 && type1[1].length == 0) || (type2[0] == 4 && type2[1].length == 0)) {
			if (type1[0] == 4 && type1[1].length == 0) {
				return type2[1];
			}
			if (type2[0] == 4 && type2[1].length == 0) {
				return type1[1];
			}
		}
		if ((type1[0] > 2) && (type2[0] > 2)) {
			return type1[1] + type2[1];
		} else {
			if (type1[0] > 2 || type2[0] > 2) {
				console.log('Оператор + не может работать со строкой и числом');
				out_array.push([10, 'Оператор + не может работать со строкой и числом', GetStr()]);
				on_error = true;
				return 'kek';
			}
			return type1[1] + type2[1];
		}
		break;
	case '!':
		if (type1[0] > 2) {
			console.log('Оператор "не" не может работать со стороками');
			out_array.push([10, 'Оператор "не" не может работать со стороками', GetStr()]);
			on_error = true;
			return 'kek';
		} else {
			if (type1[0] == 2)
				return 1 - type1[0];
			else {
				console.log('Оператор "не" не может работать с числами');
				out_array.push([10, 'Оператор "не" не может работать с числами', GetStr()]);
				on_error = true;
				return 'kek';
			}
		}
		break;
	default:
		console.log('Неизвестный оператор: ' + s);
		out_array.push([10, 'Неизвестный оператор: ' + s, GetStr()]);
		on_error = true;
		return 'kek';
	}
}
function NewType(s, x1, x2, y1, y2, z1, z2) {
	if (x1 == undefined)
		x1 = 0;
	if (x2 == undefined)
		x2 = 0;
	if (y1 == undefined)
		y1 = 0;
	if (y2 == undefined)
		y2 = 0;
	if (z1 == undefined)
		z1 = 0;
	if (z1 == undefined)
		z1 = 0;
	switch (s) {
	case 'цел':
		return {
			'value': 0,
			'type': 0,
			'd': 0,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'вещ':
		return {
			'value': 0.0,
			'type': 1,
			'd': 0,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'лог':
		return {
			'value': 0,
			'type': 2,
			'd': 0,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'сим':
		return {
			'value': ' ',
			'type': 3,
			'd': 0,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'лит':
		return {
			'value': '',
			'type': 4,
			'd': 1,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'целтаб':
		return {
			'value': {},
			'type': 10,
			'd': 3,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'вещтаб':
		return {
			'value': {},
			'type': 20,
			'd': 3,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'логтаб':
		return {
			'value': {},
			'type': 30,
			'd': 3,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'симтаб':
		return {
			'value': {},
			'type': 50,
			'd': 3,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	case 'литтаб':
		return {
			'value': {},
			'type': 40,
			'd': 4,
			'x1': x1,
			'x2': x2,
			'y1': y1,
			'y2': y2,
			'z1': z1,
			'z2': z2,
			'const': false
		};
		break;
	default:
		console.log('Неизвестный оператор: ' + s);
		out_array.push([10, 'Неизвестный оператор: ' + s, GetStr()]);
		on_error = true;
		return 'kek';
	}
}

var v_МЦЕЛ;
v_МЦЕЛ = 2147483647;
var v_МВЕЩ;
v_МВЕЩ = 2147483647;
var v_да;
v_да = 1;
var v_нет = 0;
v_нет = 0;
var v_нс;
v_нс = '\r\n';
function isall() {
	var v=0;
	for (var i = 0; i < map.length; i++)
		for (var j = 0; j < map[i].length; j++)
			if (((map[i][j][6]=='')!=(map[i][j][1]==0)))
			{
				if (v<3)
				{
					v++;
					console.log('Закрашеность не соотвествует метке (X:'+(i)+',Y:'+(j)+')');
					out_array.push([11, 'Закрашеность не соотвествует метке (X:'+(i)+',Y:'+(j)+')', GetStr()]);
					on_error = true;
				}else
				if (v==3)
				{
					v++;
					console.log('Закрашеность не соотвествует меткам');
					out_array.push([11, 'Закрашеность не соотвествует меткам', GetStr()]);
					on_error = true;
				}
			}
	for (var i = 0; i < map.length; i++)
		for (var j = 0; j < map[i].length; j++)
			if (map[i][j][5]!='$')
				if (((i!=playerX)||(j!=playerY))&&(v<5))
				{
					v++;
					console.log('Робот не вернулся в необходимую(точка '+map[i][j][5]+') позицию');
					out_array.push([11, 'Робот не вернулся в необходимую(точка '+map[i][j][5]+') позицию', GetStr()]);
					on_error = true;
				}
}
/*использовать Робот
алг
нач
цел к
к
кек(кек2(2,3),2)
кон
алг кек(цел а,б)
нач
вывод а*б
кон
алг цел кек2(цел а,б)
нач
знач:= а+б
кон

использовать Робот
алг
нач
если слева свободно
вывод "слева свободно"
все
если сверху свободно
вывод "сверху свободно"
все
если справа свободно
вывод "справа свободно"
все
если снизу свободно
вывод "снизу свободно"
все
если слева стена
вывод "слева стена"
все
если сверху стена
вывод "сверху стена"
все
если справа стена
вывод "справа стена"
все
если снизу стена
вывод "снизу стена"
все
если клетка закрашена
вывод "клетка закрашена"
все
если клетка чистая
вывод "клетка чистая"
все
вывод "радиация:",радиация
вывод "температура:",температура
вправо
вниз
влево
вверх
кон








использовать Робот
алг
нач
	закрасить
	вправо
	вправо
	закрасить
	вправо
	вправо
	закрасить
	вправо
	вправо
	закрасить
	вправо
	вправо
	закрасить
	вправо
	вправо
	закрасить
	вниз
	вниз
	закрасить
	вниз
	вниз
	закрасить
	вниз
	вниз
	закрасить
	влево
	влево
	закрасить
	влево
	влево
	закрасить
	влево
	влево
	закрасить
	влево
	влево
	закрасить
	влево
	влево
	закрасить
	вверх
	вверх
	закрасить
	вверх
	вверх
	закрасить
	вверх
	вверх
кон

использовать Робот
алг
нач
	нц пока справа свободно
		вправо
		вправо
		закрасить
	кц
	нц пока снизу свободно
		вниз
		вниз
		закрасить
	кц
	нц пока слева свободно
		влево
		влево
		закрасить
	кц
	нц пока сверху свободно
		вверх
		вверх
		закрасить
	кц
кон 
*/
