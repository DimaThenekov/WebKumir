var ___login = prompt("Введите логин", "admin");
var ___password = prompt("Введите пароль", "admin");
Serv_login(___login, ___password, game_onlogin);

function game_onlogin() {
	Serv_LoadFile('\\task\\all.json', ParseTabs);
};
var all_json = '';
var all_tests = [];
var max_v = 0;
var v = 0;
function ParseTabs(s) {
	all_json = JSON.parse(s);
	for (var i = 0; i < all_json.length; i++) {
		var name_task = all_json[i]['name'];
		all_tests[i] = all_json[i]['tests'];
		max_v++;
		for (var k = 0; k < all_tests[i].length; k++) {
			if (all_tests[i][k].indexOf('__secret_information__') >= 0)
				Serv_Command('GetFile' + all_tests[i][k].replace(new RegExp('/', 'gi'), '$').replace(new RegExp('\\\\', 'gi'), '$'), function f32092342(s, ii, kk) {
					all_tests[ii][kk] = s;
					v++;
					isall();
				}, i, k);
			else
				Serv_LoadFile(all_tests[i][k], function f32092342(s, ii, kk) {
					all_tests[ii][kk] = s;
					v++;
					isall();
				}, i, k);
		}
		all_tests[i]['name'] = name_task;
	}
}
function isall() {
	if (max_v == v) {
		setTimeout(testing, 1000);
	}
}
var programs = [];
function testing() {
	for (var j = 0; j < programs.length; j++) {
		//if (programs[j][3]!='')
		//{
		//}else{
		var index_k = -1;
		var otv_pler = 0;
		var rez = 0;
		for (var k = 0; k < all_tests.length; k++)
			if (programs[j][1].trim() == all_tests[k]['name'].trim())
				index_k = k;
		var out_text = ''; //programs[j][2].trim()+'\r\n; log:\r\n';
		for (var k in all_tests[index_k])
			if (k != 'name') {
				RunKumir(programs[j][2], all_tests[index_k][k]);
				otv_pler++;
				if (ErrorKumir.length > 0) {
					rez++;
					if (out_text == '')
						out_text += programs[j][2].trim() + '\r\n; log:\r\n';
					out_text += '; index:' + index_k + '.' + k + '\r\n';
					out_text += '; error: ' + JSON.stringify(ErrorKumir, null, '\t');
				}
			}
		programs[j][3] = ' ' + out_text;
		if (otv_pler == 0)
			programs[j][4] = 1234;
		else
			programs[j][4] = Math.floor((otv_pler - rez) / (otv_pler) * 100);
		//debugger;
		//Serv_Command('GetPrograms', testprog);
		Serv_SendProgramm(programs[j][3].trim(), programs[j][0], SendRes, 'res', programs[j][4]); // SendRes(programs[j][0],programs[j][3]);

		programs.splice(j, 1);
		//testing();
		return;
		//}
	}
	Serv_Command('GetPrograms', testprog);
}

function SendRes(s) {
	if (s = 'OK') {
		Serv_Command('GetPrograms', testprog);
	} else
		alert(s);
}

function testprog(s) {
	if (s.length > 0) {
		for (var k = 0; k < s.split(';').length; k++)
			if (s.split(';')[k].length > 0) {
				var prog_num = parseInt(s.split(';')[k]);
				var inarr = false
					for (var m = 0; m < programs.length; m++)
						if (programs[m][0] == prog_num)
							inarr = true;
					if (!inarr) {
						programs.push([prog_num, "", "", "", 0]);
						Serv_Command('GetProgram' + prog_num, function f32092342(s, prog_num2) {
							for (var m = 0; m < programs.length; m++)
								if (programs[m][0] == prog_num2) {
									s = s.trim();
									programs[m][1] = s.split('\n')[0];
									programs[m][2] = GetIn(s, "\n", "");
									break;
								}
						}, prog_num);
					}
			}

	}
	setTimeout(testing, 5000);
}
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
var MD5 = function (r) {
	function i(r, n) {
		return r << n | r >>> 32 - n
	}
	function c(r, n) {
		var t,
		o,
		e,
		u,
		a;
		return e = 2147483648 & r,
		u = 2147483648 & n,
		a = (1073741823 & r) + (1073741823 & n),
		(t = 1073741824 & r) & (o = 1073741824 & n) ? 2147483648 ^ a ^ e ^ u : t | o ? 1073741824 & a ? 3221225472 ^ a ^ e ^ u : 1073741824 ^ a ^ e ^ u : a ^ e ^ u
	}
	function n(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c((f = n) & t | ~f & o, e), a)),
		c(i(r, u), n)
	}
	function t(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c(n & (f = o) | t & ~f, e), a)),
		c(i(r, u), n)
	}
	function o(r, n, t, o, e, u, a) {
		return r = c(r, c(c(n ^ t ^ o, e), a)),
		c(i(r, u), n)
	}
	function e(r, n, t, o, e, u, a) {
		return r = c(r, c(c(t ^ (n | ~o), e), a)),
		c(i(r, u), n)
	}
	function u(r) {
		var n,
		t = "",
		o = "";
		for (n = 0; n <= 3; n++)
			t += (o = "0" + (r >>> 8 * n & 255).toString(16)).substr(o.length - 2, 2);
		return t
	}
	var a,
	f,
	C,
	g,
	h,
	v,
	d,
	S,
	l,
	m = Array();
	for (m = function (r) {
		for (var n, t = r.length, o = t + 8, e = 16 * (1 + (o - o % 64) / 64), u = Array(e - 1), a = 0, f = 0; f < t; )
			a = f % 4 * 8, u[n = (f - f % 4) / 4] = u[n] | r.charCodeAt(f) << a, f++;
		return a = f % 4 * 8,
		u[n = (f - f % 4) / 4] = u[n] | 128 << a,
		u[e - 2] = t << 3,
		u[e - 1] = t >>> 29,
		u
	}
		(r = function (r) {
			r = r.replace(/\r\n/g, "\n");
			for (var n = "", t = 0; t < r.length; t++) {
				var o = r.charCodeAt(t);
				o < 128 ? n += String.fromCharCode(o) : (127 < o && o < 2048 ? n += String.fromCharCode(o >> 6 | 192) : (n += String.fromCharCode(o >> 12 | 224), n += String.fromCharCode(o >> 6 & 63 | 128)), n += String.fromCharCode(63 & o | 128))
			}
			return n
		}
			(r)), v = 1732584193, d = 4023233417, S = 2562383102, l = 271733878, a = 0; a < m.length; a += 16)
		v = n(f = v, C = d, g = S, h = l, m[a + 0], 7, 3614090360), l = n(l, v, d, S, m[a + 1], 12, 3905402710), S = n(S, l, v, d, m[a + 2], 17, 606105819), d = n(d, S, l, v, m[a + 3], 22, 3250441966), v = n(v, d, S, l, m[a + 4], 7, 4118548399), l = n(l, v, d, S, m[a + 5], 12, 1200080426), S = n(S, l, v, d, m[a + 6], 17, 2821735955), d = n(d, S, l, v, m[a + 7], 22, 4249261313), v = n(v, d, S, l, m[a + 8], 7, 1770035416), l = n(l, v, d, S, m[a + 9], 12, 2336552879), S = n(S, l, v, d, m[a + 10], 17, 4294925233), d = n(d, S, l, v, m[a + 11], 22, 2304563134), v = n(v, d, S, l, m[a + 12], 7, 1804603682), l = n(l, v, d, S, m[a + 13], 12, 4254626195), S = n(S, l, v, d, m[a + 14], 17, 2792965006), v = t(v, d = n(d, S, l, v, m[a + 15], 22, 1236535329), S, l, m[a + 1], 5, 4129170786), l = t(l, v, d, S, m[a + 6], 9, 3225465664), S = t(S, l, v, d, m[a + 11], 14, 643717713), d = t(d, S, l, v, m[a + 0], 20, 3921069994), v = t(v, d, S, l, m[a + 5], 5, 3593408605), l = t(l, v, d, S, m[a + 10], 9, 38016083), S = t(S, l, v, d, m[a + 15], 14, 3634488961), d = t(d, S, l, v, m[a + 4], 20, 3889429448), v = t(v, d, S, l, m[a + 9], 5, 568446438), l = t(l, v, d, S, m[a + 14], 9, 3275163606), S = t(S, l, v, d, m[a + 3], 14, 4107603335), d = t(d, S, l, v, m[a + 8], 20, 1163531501), v = t(v, d, S, l, m[a + 13], 5, 2850285829), l = t(l, v, d, S, m[a + 2], 9, 4243563512), S = t(S, l, v, d, m[a + 7], 14, 1735328473), v = o(v, d = t(d, S, l, v, m[a + 12], 20, 2368359562), S, l, m[a + 5], 4, 4294588738), l = o(l, v, d, S, m[a + 8], 11, 2272392833), S = o(S, l, v, d, m[a + 11], 16, 1839030562), d = o(d, S, l, v, m[a + 14], 23, 4259657740), v = o(v, d, S, l, m[a + 1], 4, 2763975236), l = o(l, v, d, S, m[a + 4], 11, 1272893353), S = o(S, l, v, d, m[a + 7], 16, 4139469664), d = o(d, S, l, v, m[a + 10], 23, 3200236656), v = o(v, d, S, l, m[a + 13], 4, 681279174), l = o(l, v, d, S, m[a + 0], 11, 3936430074), S = o(S, l, v, d, m[a + 3], 16, 3572445317), d = o(d, S, l, v, m[a + 6], 23, 76029189), v = o(v, d, S, l, m[a + 9], 4, 3654602809), l = o(l, v, d, S, m[a + 12], 11, 3873151461), S = o(S, l, v, d, m[a + 15], 16, 530742520), v = e(v, d = o(d, S, l, v, m[a + 2], 23, 3299628645), S, l, m[a + 0], 6, 4096336452), l = e(l, v, d, S, m[a + 7], 10, 1126891415), S = e(S, l, v, d, m[a + 14], 15, 2878612391), d = e(d, S, l, v, m[a + 5], 21, 4237533241), v = e(v, d, S, l, m[a + 12], 6, 1700485571), l = e(l, v, d, S, m[a + 3], 10, 2399980690), S = e(S, l, v, d, m[a + 10], 15, 4293915773), d = e(d, S, l, v, m[a + 1], 21, 2240044497), v = e(v, d, S, l, m[a + 8], 6, 1873313359), l = e(l, v, d, S, m[a + 15], 10, 4264355552), S = e(S, l, v, d, m[a + 6], 15, 2734768916), d = e(d, S, l, v, m[a + 13], 21, 1309151649), v = e(v, d, S, l, m[a + 4], 6, 4149444226), l = e(l, v, d, S, m[a + 11], 10, 3174756917), S = e(S, l, v, d, m[a + 2], 15, 718787259), d = e(d, S, l, v, m[a + 9], 21, 3951481745), v = c(v, f), d = c(d, C), S = c(S, g), l = c(l, h);
	return (u(v) + u(d) + u(S) + u(l)).toLowerCase()
};

var RegistrationHash = function (h, p) {
	return MD5('Hash:' + h + ';Password:' + p + ';');
};
var GameLogin = '';
var GamePassword = '';
var Serv_iswork = false;
var newping = 0;
var get_errors = 0;
function Serv_Command(a /*string*/, f, iii, kkk) {
	if (GameLogin != '') {
		if (Serv_iswork == true) {
			if (a != "getpos")
				var timerId3546356 = setTimeout(function f567567() {
					Serv_Command(a, f, iii, kkk)
				}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/' + a + '.txt', true);
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				var xhr2 = new XHR2();
				xhr2.open('GET', 'protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				xhr2.onload = function () {
					if (xhr2.status == 200) {
						Serv_iswork = false;
						if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
							get_errors = 0;
							ping = (new Date) - newping;
							f(xhr2.responseText,iii, kkk);
						} else {
							get_errors++;
							if (get_errors > 10) {
								alert('Неверный логин или пароль (связь с сервером потеряна)');
								location.reload();
							}
							Serv_Command(a, f, iii, kkk);
						}
					} else
						xhr2.onerror();
				}
				xhr2.onerror = function () {
					console.log('Сервер не ответил(1.2).');
				}
				xhr2.send();
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			console.log('Сервер не ответил(1.1).');
		}
		xhr.send();
	} else {

		console.log('Пользователь не залогинен.');

	}
}

function Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress) {
	if (leng == undefined) {
		leng = 'kumir';
	}
	if (progress == undefined) {
		progress = '';
	}

	if (GameLogin != '') {
		if (Serv_iswork == true) {
			var timerId3546356 = setTimeout(function f567567() {
				Serv_SendProgramm(Progr, Task, f)
			}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/upload;' + leng + ';' + Task + ';' + progress + ';.txt', true); // /upload;res;10%;A1;.txt
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', 'protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				//xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Отправляем кодировку
				xhr2.onreadystatechange = function () {
					if (xhr2.readyState == 4) {
						if (xhr2.status == 200) {
							Serv_iswork = false;
							if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
								get_errors = 0;
								f(xhr2.responseText);
							} else {
								get_errors++;
								if (get_errors > 10) {
									alert('Неверный логин или пароль (связь с сервером потеряна)');
									location.reload();
								}
								Serv_SendProgramm(Progr, Task, f, leng, progress);
							}
						} else
							xhr2.onerror();
					}
				}
				xhr2.onerror = function () {
					console.log('Сервер не ответил(2.2).');
				}
				xhr2.send(encodeURIComponent(Progr).replace(/%20/g, "+")); // Отправляем POST-запрос
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			console.log('Сервер не ответил(2.1).');
		}
		xhr.send();
	} else {

		console.log('Пользователь не залогинен.');

	}
}

function Serv_LoadFile(url /*string*/, f, iii, kkk) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', url, true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			if (this.status == 200) {
				f(this.responseText, iii, kkk);
			}
		} else
			xhr.onerror();
	}

	xhr.onerror = function () {
		console.log('Сервер не ответил(3.1).');
	}
	xhr.send();
}

function Serv_login(Login, Password, func) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', 'commands/' + Login + '/login.txt', true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
			var xhr2 = new XHR();
			xhr2.open('GET', 'protect/' + RegistrationHash(this.responseText, Password) + '.txt', true);
			xhr2.onload = function () {
				if (xhr2.status == 200) {
					if (this.responseText == 'OK')
						alert('Удачно!!!');
					else {
						alert('Ошибка в логине или пароле');
						location.reload();
					}
					GameLogin = Login;
					GamePassword = Password;
					func();
				} else
					xhr2.onerror();
			}
			xhr2.onerror = function () {
				alert('Ошибка в логине или пароле(!).');
				location.reload()
			}
			xhr2.send();
		} else {
			xhr.onerror();
			location.reload()
		}
	}

	xhr.onerror = function () {
		alert('Ошибка в логине(!) или пароле.');
	}

	xhr.send();
}
