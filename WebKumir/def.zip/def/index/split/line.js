Element.prototype.sdrag = function (g, h, k) {
	function l(a) {
		var b = {};
		if (g && g(c, a.pageX, d, a.pageY, e, b), "vertical" !== k) {
			var f = "pageX" in b ? b.pageX : a.pageX;
			"startX" in b && (d = b.startX);
			0 == "skipX" in b && (c.style.left = f - d + "px")
		}
		"horizontal" !== k && (a = "pageY" in b ? b.pageY : a.pageY, "startY" in b && (e = b.startY), 0 == "skipY" in b && (c.style.top = a - e + "px"))
	}
	var d = 0,
	e = 0,
	c = this,
	f = !1;
	this.addEventListener("mousedown", function (a) {
		if (!(a.currentTarget instanceof HTMLElement || a.currentTarget instanceof SVGElement))
			throw Error("Your target must be an html element");
		f = !0;
		var b = c.style.left ? parseInt(c.style.left) : 0,
		g = c.style.top ? parseInt(c.style.top) : 0;
		d = a.pageX - b;
		e = a.pageY - g;
		window.addEventListener("mousemove", l)
	});
	window.addEventListener("mouseup", function (a) {
		!0 === f && (f = !1, window.removeEventListener("mousemove", l), h && h(c, a.pageX, d, a.pageY, e))
	});
};
